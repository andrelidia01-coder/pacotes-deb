"""LumiCore SETUP Web: the REAL existing web interface, without GPU approval.

Only read-only system/fan endpoints and authenticated fan settings are exposed
before hardware validation. Once approved, exec the existing full web server.
"""
from __future__ import annotations
import hmac
import json
import mimetypes
import os
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from hipervisor.core.config import load

DB = '/var/lib/lumicore/lhdb.dat'
FLAG = Path('/etc/lumicore/hardware-approved')
KEY_PATH = Path('/etc/lumicore/control-key')
CORE = 'http://127.0.0.1:8765'
ASSETS = Path('/opt/lumicore/hipervisor_web/static')


def ready():
    if not FLAG.is_file():
        return False
    try:
        cfg = load(DB)
        return Path(cfg['gpu']['adapter']).is_file()
    except (OSError, ValueError, KeyError, TypeError):
        return False


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def json_reply(self, obj, status=200):
        self.reply(json.dumps(obj, ensure_ascii=False).encode('utf-8'),
                   mime='application/json', status=status)

    def reply(self, data, mime='application/json', status=200):
        self.send_response(status)
        self.send_header('Content-Type', mime + '; charset=utf-8' if mime.startswith('text/') or mime == 'application/json' else mime)
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def authorized(self):
        try:
            expected = KEY_PATH.read_text().strip()
        except OSError:
            return False
        candidate = self.headers.get('X-Hipervisor-Key', '')
        return bool(expected) and hmac.compare_digest(candidate, expected)

    def static(self, name):
        base = ASSETS.resolve()
        p = (base / name).resolve()
        if not p.is_relative_to(base) or not p.is_file():
            return self.json_reply({'error': 'not_found'}, 404)
        data = p.read_bytes()
        content = mimetypes.guess_type(str(p))[0] or 'application/octet-stream'
        self.reply(data, mime=content)

    def proxy(self, path, *, method='GET'):
        headers = {}
        token = self.headers.get('X-Hipervisor-Key')
        if token:
            headers['X-Hipervisor-Key'] = token
        data = None
        if method == 'POST':
            try:
                n = int(self.headers.get('Content-Length', '0'))
                if not 0 < n <= 4096:
                    raise ValueError('bad body length')
                data = self.rfile.read(n)
                json.loads(data)
            except (ValueError, json.JSONDecodeError):
                return self.json_reply({'error': 'invalid_body'}, 400)
            headers['Content-Type'] = 'application/json'
        req = urllib.request.Request(CORE + path, headers=headers, data=data, method=method)
        try:
            with urllib.request.urlopen(req, timeout=5) as res:
                return self.reply(res.read(), status=res.status)
        except urllib.error.HTTPError as exc:
            return self.reply(exc.read(), status=exc.code)
        except (OSError, TimeoutError):
            return self.json_reply({'error': 'core_unavailable'}, 502)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path in ('/', '/admin'):
            return self.static('index.html')
        if path in ('/style.css', '/app.js'):
            return self.static(path[1:])
        if path.startswith('/icons/'):
            return self.static(path[1:])
        if path == '/health':
            return self.json_reply({'ok': True, 'version': '0.2.2',
                                    'state': 'SETUP', 'fans_independent': True,
                                    'interface': 'full'})
        if path == '/api/setup':
            return self.json_reply({'state': 'SETUP',
                                    'hardware_approved': False,
                                    'fans_independent': True})
        if path == '/api/auth':
            if not self.authorized():
                return self.json_reply({'error': 'unauthorized'}, 401)
            return self.json_reply({'authorized': True})
        if path == '/api/system':
            return self.proxy('/v1/system')
        if path == '/api/fans':
            return self.proxy('/v1/fans')
        if path == '/api/fans/settings':
            if not self.authorized():
                return self.json_reply({'error': 'unauthorized'}, 401)
            return self.proxy('/v1/fans/settings')
        # In SETUP no GPU profiles, energy/configuration writes, or legacy
        # telemetry endpoints are exposed. The approved panel remains visible.
        return self.json_reply({'error': 'setup_mode'}, 409)

    def do_POST(self):
        path = urlsplit(self.path).path
        if path not in ('/api/fans/settings', '/api/fans/preview'):
            return self.json_reply({'error': 'setup_mode'}, 409)
        if not self.authorized():
            return self.json_reply({'error': 'unauthorized'}, 401)
        origin = self.headers.get('Origin')
        host = self.headers.get('Host', '')
        if origin and origin not in ('http://' + host, 'https://' + host):
            return self.json_reply({'error': 'origin_rejected'}, 403)
        target = '/v1/fans/settings' if path.endswith('settings') else '/v1/fans/preview'
        return self.proxy(target, method='POST')


def main():
    if ready():
        os.execv('/usr/bin/python3', ['/usr/bin/python3', '-m',
                                     'hipervisor_web.app', '--config', DB])
    ThreadingHTTPServer(('0.0.0.0', 8766), Handler).serve_forever(poll_interval=0.5)


if __name__ == '__main__':
    main()
