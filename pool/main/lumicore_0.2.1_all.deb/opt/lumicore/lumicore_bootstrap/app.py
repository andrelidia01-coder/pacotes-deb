"""LumiCore first-boot setup: GPU approval separate from platform fans.

Fans are opt-in via H81 configuration and automatically fail safe to MAX.
No GPU power profiles are applied while the LHDB remains unapproved.
"""
from __future__ import annotations

import hmac
import json
import logging
import os
import signal
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from hipervisor.core.config import load
from hipervisor.identity import identity
from lumicore_fans import FanManager
from .gpu_fans import CachedProvider

DB = '/var/lib/lumicore/lhdb.dat'
APPROVED = Path('/etc/lumicore/hardware-approved')
CONTROL_KEY = Path('/etc/lumicore/control-key')
LOG = logging.getLogger('lumicore.setup')


def ready():
    if not APPROVED.is_file():
        return False, 'awaiting_hardware_approval'
    try:
        cfg = load(DB)
        for item in [cfg['gpu']['adapter'], *(
            cfg[f'gpu{i}']['adapter'] for i in (1, 2, 3)
            if cfg.get(f'gpu{i}', {}).get('enabled'))]:
            if not Path(item).is_file():
                return False, 'gpu_adapter_missing'
        return True, 'configured'
    except Exception:
        return False, 'configuration_invalid'


class FanWorker(threading.Thread):
    """One owner of fan PWM during SETUP, using the platform hwmon API."""
    def __init__(self, manager):
        super().__init__(name='lumicore-setup-fans', daemon=True)
        self.manager = manager
        self.stopping = threading.Event()
        self.lock = threading.RLock()
        self.gpu = CachedProvider(interval=3.0)

    def run(self):
        # No platform driver attached? Keep scanning, don't touch other PCs.
        while not self.stopping.is_set():
            with self.lock:
                try:
                    if self.manager.detected():
                        from lumicore_platforms.h81.sensors import cpu_package_temperature
                        try:
                            cpu = cpu_package_temperature()
                        except (ValueError, OSError, RuntimeError):
                            cpu = None
                        gpu_fans = self.gpu.get()
                        self.manager.update(cpu, [{'fan_pct': pct} for pct in gpu_fans]
                                            if gpu_fans is not None else None)
                    else:
                        self.manager.status()
                except Exception:
                    LOG.exception('H81 fan worker: sensor/control failure')
                    try:
                        self.manager.stop()
                    except Exception:
                        LOG.exception('H81 fan worker: MAX command failed')
            self.stopping.wait(1.0)

    def stop(self):
        self.stopping.set()
        self.join(timeout=3)
        with self.lock:
            self.manager.stop()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        LOG.info('%s ' + fmt, self.address_string(), *args)

    def _reply(self, code, obj):
        data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _authorized(self):
        try:
            expected = CONTROL_KEY.read_text().strip()
        except OSError:
            return False
        provided = self.headers.get('X-Hipervisor-Key', '')
        return bool(expected) and hmac.compare_digest(provided, expected)

    def do_GET(self):
        path = self.path.split('?', 1)[0]
        if path == '/v1/health':
            self._reply(200, {'ok': True, 'product': 'LumiCore', 'version': '0.2.1',
                              'state': 'SETUP', 'reason': self.server.reason,
                              'fans_independent': True})
        elif path == '/v1/system':
            data = identity({'instance_name': 'Setup'})
            data['state'] = 'SETUP'
            self._reply(200, data)
        elif path == '/v1/fans':
            with self.server.fans.lock:
                self._reply(200, self.server.fans.manager.status())
        elif path == '/v1/fans/settings':
            if not self._authorized():
                return self._reply(401, {'error': 'unauthorized'})
            with self.server.fans.lock:
                self._reply(200, self.server.fans.manager.settings())
        elif path == '/v1/commands':
            self._reply(409, {'error': 'setup_mode', 'reason': self.server.reason})
        else:
            self._reply(404, {'error': 'not_found'})

    def do_POST(self):
        if self.path not in ('/v1/fans/settings', '/v1/fans/preview'):
            return self._reply(404, {'error': 'not_found'})
        if not self._authorized():
            return self._reply(401, {'error': 'unauthorized'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 4096:
                raise ValueError('invalid_body')
            content = json.loads(self.rfile.read(size))
            with self.server.fans.lock:
                if self.path == '/v1/fans/settings':
                    saved = self.server.fans.manager.save(content)
                    self._reply(200, {'ok': True, 'platform': 'h81', 'settings': saved})
                else:
                    result = self.server.fans.manager.preview(content)
                    self._reply(200, result)
        except (ValueError, KeyError, TypeError) as exc:
            self._reply(400, {'error': str(exc)})
        except RuntimeError as exc:
            self._reply(409, {'error': str(exc)})
        except Exception:
            LOG.exception('Falha em /v1/fans')
            self._reply(500, {'error': 'internal_error'})


def main():
    yes, reason = ready()
    if yes:
        os.execv('/usr/bin/python3', ['/usr/bin/python3', '-m', 'hipervisor.app',
                                      '--database', DB])
    logging.basicConfig(level=logging.INFO, format='%(levelname)s %(message)s')
    fans = FanWorker(FanManager())
    fans.start()
    server = ThreadingHTTPServer(('0.0.0.0', 8765), Handler)
    server.reason = reason
    server.fans = fans

    def shutdown(_signum, _frame):
        # shutdown must run in a different thread from serve_forever.
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)
    print('LumiCore 0.2.1 SETUP: GPU em espera, ventoinhas independentes', flush=True)
    try:
        server.serve_forever(poll_interval=0.2)
    finally:
        server.server_close()
        fans.stop()


if __name__ == '__main__':
    main()
