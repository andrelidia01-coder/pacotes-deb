from pathlib import Path
import platform, socket, subprocess

def text(path):
    try: return Path(path).read_text().strip()
    except OSError: return None

def identity(cfg):
    os_name = platform.system()
    for line in (text('/etc/os-release') or '').splitlines():
        if line.startswith('PRETTY_NAME='): os_name = line.split('=', 1)[1].strip('"')
    interfaces=[]
    for p in sorted(Path('/sys/class/net').glob('*')):
        if p.name == 'lo': continue
        interfaces.append({'name':p.name, 'mac':text(p/'address'), 'state':text(p/'operstate')})
    return {'product':'LumiCore', 'version':'0.2.0', 'hostname':socket.gethostname(),
            'instance':cfg.get('instance_name'), 'os':os_name, 'kernel':platform.release(),
            'architecture':platform.machine(), 'board_vendor':text('/sys/class/dmi/id/board_vendor'),
            'board_name':text('/sys/class/dmi/id/board_name'), 'interfaces':interfaces}
