"""Contrato externo gpu0/gpu1; o núcleo não identifica nem controla placas."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any


class GpuCommand:
    def __init__(self, path: str, expected_uuid: str | None = None):
        self.path = Path(path)
        self.expected_uuid = expected_uuid
        if not self.path.is_file() or not self.path.stat().st_mode & 0o111:
            raise RuntimeError(f"Adaptador GPU indisponível: {path}")

    def call(self, *args: str) -> str:
        result = subprocess.run(
            [str(self.path), *args], check=True, text=True,
            capture_output=True, timeout=30,
        )
        return result.stdout.strip()

    def sample(self) -> dict[str, Any]:
        raw = json.loads(self.call("status", "--json"))
        if not isinstance(raw, dict):
            raise RuntimeError(f"Estado inválido de {self.path}")
        expected = {"name", "temp_c", "usage_pct", "power_w", "fan_pct"}
        if not expected.issubset(raw):
            raise RuntimeError(f"Campos em falta no estado de {self.path}")
        if self.expected_uuid and raw.get("uuid") != self.expected_uuid:
            raise RuntimeError(f"UUID incorreto no adaptador {self.path}")
        # Os nomes de campos são estáveis para a API existente. O adaptador
        # resolve por si qual é a placa física correspondente a gpu0/gpu1.
        return raw


class ExternalProfileController:
    def __init__(self, command: GpuCommand, profiles: dict[str, dict[str, Any]]):
        self.command = command
        self.profiles = profiles
        self.current: str | None = None

    def apply(self, name: str) -> str:
        if name not in self.profiles:
            raise ValueError(f"Perfil desconhecido: {name}")
        if self.command.expected_uuid:
            self.command.sample()  # não escreve na placa antes de confirmar a identidade
        self.command.call(name)  # preserva o contrato existente: gpu0 max
        self.current = name
        return name

    def describe(self) -> dict[str, Any]:
        return {"current": self.current, "available": self.profiles}


class ExternalFanController:
    def __init__(self, command: GpuCommand, enabled: bool):
        self.command = command
        self.enabled = enabled
        self.full_speed = False
        self.manual = False
        self.speed_percent: int | None = None

    def prepare(self) -> int:
        return 0

    def set_speed(self, percent: int) -> None:
        if not self.enabled:
            return
        if not 30 <= percent <= 100:
            raise ValueError("Ventoinha fora de 30..100%")
        if self.manual and self.speed_percent == percent:
            return
        self.command.call("fan", str(percent))
        self.manual = True
        self.speed_percent = percent
        self.full_speed = percent == 100

    def set_auto(self, force: bool = False) -> None:
        if not self.enabled or (not force and not self.manual):
            return
        self.command.call("fan", "auto")
        self.manual = False
        self.speed_percent = None
        self.full_speed = False
