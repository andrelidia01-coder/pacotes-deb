from __future__ import annotations

import json
import shutil
from collections.abc import Callable
from typing import Any

from hipervisor.core.command import run


AMD_SMI_VERSION = "1.5.0"
AMD_SMI_VERSION_OUTPUT = f"amd-smi {AMD_SMI_VERSION}"


class AmdSmiError(RuntimeError):
    """Falha no contrato entre o Hipervisor e o amd-smi."""


class AmdSmiClient:
    """Única fronteira do Hipervisor com GPUs AMD.

    O núcleo não conhece sysfs, hwmon ou detalhes do amdgpu. Toda a leitura e
    escrita AMD passa pelo protocolo de linha de comandos do amd-smi 1.5.0.
    """

    def __init__(
        self,
        binary: str | None = None,
        runner: Callable[..., str] = run,
    ):
        self.binary = binary or shutil.which("amd-smi") or "amd-smi"
        self.runner = runner

    def verify_version(self) -> str:
        try:
            output = self.runner([self.binary, "--version"], timeout=3.0).strip()
        except Exception as exc:
            raise AmdSmiError(
                f"amd-smi {AMD_SMI_VERSION} não está disponível em {self.binary}"
            ) from exc
        if output != AMD_SMI_VERSION_OUTPUT:
            found = output or "sem versão"
            raise AmdSmiError(
                f"amd-smi incompatível: esperado {AMD_SMI_VERSION_OUTPUT!r}, "
                f"encontrado {found!r}"
            )
        return AMD_SMI_VERSION

    def _json(self, arguments: list[str], timeout: float = 8.0) -> dict[str, Any]:
        try:
            output = self.runner(
                [self.binary, *arguments, "--json"], timeout=timeout
            )
        except Exception as exc:
            raise AmdSmiError(f"amd-smi falhou: {exc}") from exc
        try:
            payload = json.loads(output)
        except (TypeError, json.JSONDecodeError) as exc:
            raise AmdSmiError("amd-smi devolveu JSON inválido") from exc
        if isinstance(payload, list):
            if len(payload) != 1 or not isinstance(payload[0], dict):
                raise AmdSmiError("amd-smi devolveu um número inesperado de GPUs")
            payload = payload[0]
        if not isinstance(payload, dict):
            raise AmdSmiError("amd-smi devolveu uma estrutura JSON inválida")
        return payload

    def query(self, index: int) -> dict[str, Any]:
        return self._json(["-i", str(index)])

    def configure(
        self,
        index: int,
        *,
        power_limit_w: int | None = None,
        fan_percent: int | None = None,
        fan_auto: bool = False,
        dpm: str | None = None,
        sclk: int | None = None,
        mclk: int | None = None,
    ) -> dict[str, Any]:
        if fan_percent is not None and fan_auto:
            raise ValueError("fan_percent e fan_auto são mutuamente exclusivos")
        arguments = ["-i", str(index)]
        if power_limit_w is not None:
            arguments.extend(["--power-limit", str(power_limit_w)])
        if fan_percent is not None:
            arguments.extend(["--fan", str(fan_percent)])
        if fan_auto:
            arguments.append("--fan-auto")
        if dpm is not None:
            arguments.extend(["--dpm", dpm])
        if sclk is not None:
            arguments.extend(["--sclk", str(sclk)])
        if mclk is not None:
            arguments.extend(["--mclk", str(mclk)])
        return self._json(arguments, timeout=15.0)
