from __future__ import annotations

import hmac
import json
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlparse

from hipervisor.commands.registry import CommandError
from hipervisor.identity import identity



class ApiServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address: tuple[str, int], runtime: Any, control_key: str):
        self.runtime = runtime
        self.control_key = control_key
        super().__init__(address, ApiHandler)


class ApiHandler(BaseHTTPRequestHandler):
    server: ApiServer
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        if len(body) > 262_144:
            status = HTTPStatus.INTERNAL_SERVER_ERROR
            body = b'{"ok":false,"error":"response_too_large"}'
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            # O cliente pode desistir enquanto um comando GPU demorado está
            # em execução. Isso não é uma falha do hipervisor.
            return

    def _path(self) -> str:
        return urlparse(self.path).path.rstrip("/") or "/"

    def _authorized(self) -> bool:
        supplied = self.headers.get("X-Hipervisor-Key", "")
        return bool(self.server.control_key) and hmac.compare_digest(supplied, self.server.control_key)

    def do_GET(self) -> None:
        path = self._path()
        if path == "/v1/fans":
            self._json(HTTPStatus.OK, self.server.runtime.platform_fans.status())
        elif path == "/v1/fans/settings":
            if not self._authorized():
                self._json(HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"})
                return
            self._json(HTTPStatus.OK, self.server.runtime.platform_fans.settings())
        elif path == "/v1/system":
            self._json(HTTPStatus.OK, identity(self.server.runtime.cfg))
        elif path == "/v1/health":
            snapshot = self.server.runtime.state.get()
            self._json(HTTPStatus.OK, {
                "ok": snapshot["state"] != "FAULT",
                "version": snapshot["version"],
                "product": "LumiCore",
                "state": snapshot["state"],
            })
        elif path == "/v1/commands":
            self._json(HTTPStatus.OK, {
                "api": 1,
                "commands": self.server.runtime.commands.describe(),
            })
        else:
            self._json(HTTPStatus.NOT_FOUND, {"error": "not_found"})

    def do_POST(self) -> None:
        path = self._path()
        if path in ("/v1/fans/settings", "/v1/fans/preview"):
            if not self._authorized():
                self._json(HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"})
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 4096:
                    raise ValueError("invalid_body")
                payload = json.loads(self.rfile.read(length))
                if path == "/v1/fans/settings":
                    with self.server.runtime._sample_lock:
                        setting = self.server.runtime.platform_fans.save(payload)
                    self._json(HTTPStatus.OK, {"ok": True, "platform": "h81", "settings": setting})
                else:
                    result = self.server.runtime.platform_fans.preview(payload)
                    self._json(HTTPStatus.OK, result)
            except (ValueError, KeyError, TypeError) as exc:
                self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            except RuntimeError as exc:
                self._json(HTTPStatus.CONFLICT, {"error": str(exc)})
            except Exception as exc:
                self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})
            return
        if path != "/v1/run":
            self._json(HTTPStatus.NOT_FOUND, {"error": "not_found"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > 4096:
            self._json(HTTPStatus.BAD_REQUEST, {"error": "invalid_body"})
            return
        try:
            payload = json.loads(self.rfile.read(length))
            name = payload["command"]
            if not isinstance(name, str):
                raise ValueError("command")
            if self.server.runtime.commands.requires_auth(name) and not self._authorized():
                self._json(HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"})
                return
            args = payload.get("args", {})
            result = self.server.runtime.commands.execute(name, args)
        except (ValueError, CommandError) as exc:
            self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            return
        except RuntimeError as exc:
            self._json(HTTPStatus.CONFLICT, {"error": str(exc)})
            return
        except Exception as exc:
            self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})
            return
        self._json(HTTPStatus.OK, {"result": result})
