"""Histórico energético persistente."""
