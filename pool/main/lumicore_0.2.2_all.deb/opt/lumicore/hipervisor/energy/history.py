from __future__ import annotations

import sqlite3
import threading
import time
from pathlib import Path
from typing import Any


RANGES = {"1h": 3600, "6h": 21600, "24h": 86400, "7d": 604800, "30d": 2592000}


class EnergyHistory:
    def __init__(self, cfg: dict[str, Any]):
        self.enabled = bool(cfg["enabled"])
        self.path = Path(cfg["database"])
        self.interval = int(cfg["sample_interval_s"])
        self.retention = int(cfg["retention_days"]) * 86400
        self._last_sample = 0.0
        self._last_prune = 0.0
        self._lock = threading.Lock()
        if self.enabled:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=5.0)
        connection.execute("PRAGMA journal_mode=WAL")
        return connection

    def _initialize(self) -> None:
        with self._connect() as db:
            db.execute("""
                CREATE TABLE IF NOT EXISTS energy_samples (
                    timestamp REAL PRIMARY KEY,
                    cpu_w REAL, gpu_w REAL, total_w REAL,
                    wall_w REAL, load_pct REAL
                )
            """)
            db.execute("CREATE INDEX IF NOT EXISTS energy_samples_time ON energy_samples(timestamp)")

    def record(self, snapshot: dict[str, Any]) -> None:
        if not self.enabled:
            return
        now = float(snapshot.get("timestamp") or time.time())
        if now - self._last_sample < self.interval:
            return
        power = snapshot.get("power", {})
        cpu = snapshot.get("cpu", {})
        gpu_total = snapshot.get("power", {}).get("gpu_total_w")
        if gpu_total is None:
            gpu_total = (snapshot.get("gpu") or {}).get("power_w")
        row = (now, cpu.get("power_w"), gpu_total,
               power.get("estimated_total_w"), power.get("estimated_wall_w"),
               power.get("load_pct"))
        with self._lock, self._connect() as db:
            db.execute("INSERT OR REPLACE INTO energy_samples VALUES (?,?,?,?,?,?)", row)
            if now - self._last_prune >= 86400:
                db.execute("DELETE FROM energy_samples WHERE timestamp < ?", (now - self.retention,))
                self._last_prune = now
        self._last_sample = now

    def query(self, period: str, points: int = 240) -> dict[str, Any]:
        if period not in RANGES:
            raise ValueError("range permitido: 1h, 6h, 24h, 7d ou 30d")
        now = time.time()
        start = now - RANGES[period]
        bucket = max(1, RANGES[period] // points)
        if not self.enabled:
            return {"range": period, "from": start, "to": now, "points": []}
        sql = """
            SELECT CAST(timestamp / ? AS INTEGER) * ?,
                   AVG(cpu_w), AVG(gpu_w), AVG(total_w), AVG(wall_w), AVG(load_pct)
            FROM energy_samples WHERE timestamp >= ?
            GROUP BY CAST(timestamp / ? AS INTEGER) ORDER BY 1
        """
        with self._lock, self._connect() as db:
            rows = db.execute(sql, (bucket, bucket, start, bucket)).fetchall()
        data = [{
            "timestamp": row[0], "cpu_w": _round(row[1]), "gpu_w": _round(row[2]),
            "total_w": _round(row[3]), "wall_w": _round(row[4]),
            "load_pct": _round(row[5]),
        } for row in rows]
        return {"range": period, "from": start, "to": now, "points": data}


def _round(value: Any) -> float | None:
    return round(float(value), 2) if value is not None else None
