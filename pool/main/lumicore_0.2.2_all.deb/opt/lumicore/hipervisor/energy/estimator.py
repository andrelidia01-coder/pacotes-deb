from __future__ import annotations

from typing import Any


class WallPowerEstimator:
    """Converte potências observadas numa estimativa AC calibrada no wattímetro."""

    def __init__(self, cfg: dict[str, Any]):
        power = cfg["power"]
        raw = power.get("calibration_curve", [])
        self.points = sorted(
            (float(item["measured_w"]), float(item["wall_w"])) for item in raw
        )
        self.fallback_reserve = float(power.get("reserve_w", 0.0))
        self.fallback_efficiency = float(power.get("efficiency", 0.92))

    def estimate(self, measured_w: float | None) -> float | None:
        if measured_w is None:
            return None
        measured = max(0.0, float(measured_w))
        if len(self.points) < 2:
            return (measured + self.fallback_reserve) / self.fallback_efficiency

        if measured <= self.points[0][0]:
            # No regime de baixo consumo, mantém a componente base observada.
            x0, y0 = self.points[0]
            return max(measured, y0 - x0 + measured)

        for left, right in zip(self.points, self.points[1:]):
            if measured <= right[0]:
                return self._linear(measured, left, right)

        # Extrapolação conservadora usando o último segmento medido.
        return self._linear(measured, self.points[-2], self.points[-1])

    @staticmethod
    def _linear(value: float, left: tuple[float, float], right: tuple[float, float]) -> float:
        x0, y0 = left
        x1, y1 = right
        if x1 == x0:
            return y1
        return y0 + (value - x0) * (y1 - y0) / (x1 - x0)
