from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from hipervisor.core.command import run


class ServiceCommands:
    def __init__(self, allowed: Iterable[str]):
        self.allowed = frozenset(allowed)

    def _name(self, args: dict[str, Any]) -> str:
        name = args.pop("name", None)
        if args or not isinstance(name, str) or name not in self.allowed:
            raise ValueError("Serviço não autorizado")
        return name

    def status(self, args: dict[str, Any]) -> dict[str, Any]:
        name = self._name(args)
        output = run([
            "systemctl", "show", name,
            "--property=ActiveState,SubState,MainPID",
        ])
        values = dict(
            line.split("=", 1) for line in output.splitlines() if "=" in line
        )
        return {
            "name": name,
            "active_state": values.get("ActiveState"),
            "sub_state": values.get("SubState"),
            "main_pid": int(values["MainPID"])
            if values.get("MainPID", "").isdigit() else None,
        }

    def start(self, args: dict[str, Any]) -> dict[str, Any]:
        name = self._name(args)
        run(["systemctl", "start", name], timeout=15.0)
        return {"name": name, "action": "started"}

    def stop(self, args: dict[str, Any]) -> dict[str, Any]:
        name = self._name(args)
        run(["systemctl", "stop", name], timeout=15.0)
        return {"name": name, "action": "stopped"}
