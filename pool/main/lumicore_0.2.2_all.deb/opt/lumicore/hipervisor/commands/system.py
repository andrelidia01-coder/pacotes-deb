from __future__ import annotations

from typing import Any

from hipervisor.commands.registry_types import require_no_args


class SystemCommands:
    def __init__(self, runtime: Any):
        self.runtime = runtime

    def _snapshot(self, args: dict[str, Any]) -> dict[str, Any]:
        require_no_args(args)
        return self.runtime.state.get()

    def _cpu(self, args: dict[str, Any], field: str) -> Any:
        return self._snapshot(args).get("cpu", {}).get(field)

    def _gpu(self, args: dict[str, Any], field: str) -> Any:
        gpu = self._snapshot(args).get("gpu") or {}
        return gpu.get(field)

    def _gpu1(self, args: dict[str, Any], field: str) -> Any:
        gpu = self._snapshot(args).get("gpu1") or {}
        return gpu.get(field)

    def _ram(self, args: dict[str, Any], field: str) -> Any:
        return self._snapshot(args).get("memory", {}).get(field)

    def _power(self, args: dict[str, Any], field: str) -> Any:
        return self._snapshot(args).get("power", {}).get(field)

    def _case_fans(self, args: dict[str, Any]) -> dict[str, Any]:
        return self._snapshot(args).get("case_fans", {})

    def state(self, args: dict[str, Any]) -> Any:
        return self._snapshot(args).get("state")

    def cpu_temp(self, args: dict[str, Any]) -> Any:
        return self._cpu(args, "temp_c")

    def cpu_power(self, args: dict[str, Any]) -> Any:
        return self._cpu(args, "power_w")

    def cpu_usage(self, args: dict[str, Any]) -> Any:
        return self._cpu(args, "usage_pct")

    def cpu_clock(self, args: dict[str, Any]) -> Any:
        return self._cpu(args, "clock_mhz")

    def gpu_name(self, args: dict[str, Any]) -> Any:
        return self._gpu(args, "name")

    def gpu_temp(self, args: dict[str, Any]) -> Any:
        return self._gpu(args, "temp_c")

    def gpu_power(self, args: dict[str, Any]) -> Any:
        return self._gpu(args, "power_w")

    def gpu_usage(self, args: dict[str, Any]) -> Any:
        return self._gpu(args, "usage_pct")

    def gpu_clock(self, args: dict[str, Any]) -> Any:
        return self._gpu(args, "clock_mhz")

    def gpu_memory_clock(self, args: dict[str, Any]) -> Any:
        return self._gpu(args, "memory_clock_mhz")

    def gpu_vram_used(self, args: dict[str, Any]) -> Any:
        return self._gpu(args, "vram_used_mb")

    def gpu_vram_total(self, args: dict[str, Any]) -> Any:
        return self._gpu(args, "vram_total_mb")

    def gpu_fan(self, args: dict[str, Any]) -> Any:
        return self._gpu(args, "fan_pct")

    def profile_get(self, args: dict[str, Any]) -> Any:
        require_no_args(args)
        return self.runtime.profiles.current

    def profile_set(self, args: dict[str, Any]) -> Any:
        name = args.pop("name", None)
        if args or not isinstance(name, str):
            raise ValueError("O argumento name é obrigatório")
        return self.runtime.set_profile(name.lower())

    def gpu1_name(self, args: dict[str, Any]) -> Any:
        return self._gpu1(args, "name")

    def gpu1_temp(self, args: dict[str, Any]) -> Any:
        return self._gpu1(args, "temp_c")

    def gpu1_power(self, args: dict[str, Any]) -> Any:
        return self._gpu1(args, "power_w")

    def gpu1_usage(self, args: dict[str, Any]) -> Any:
        return self._gpu1(args, "usage_pct")

    def gpu1_clock(self, args: dict[str, Any]) -> Any:
        return self._gpu1(args, "clock_mhz")

    def gpu1_memory_clock(self, args: dict[str, Any]) -> Any:
        return self._gpu1(args, "memory_clock_mhz")

    def gpu1_fan(self, args: dict[str, Any]) -> Any:
        return self._gpu1(args, "fan_rpm")

    def case_fans_state(self, args: dict[str, Any]) -> Any:
        return self._case_fans(args)

    def case_fan_front(self, args: dict[str, Any]) -> Any:
        return self._case_fans(args).get("zones", {}).get("front")

    def case_fan_exhaust(self, args: dict[str, Any]) -> Any:
        return self._case_fans(args).get("zones", {}).get("exhaust")

    def profile1_get(self, args: dict[str, Any]) -> Any:
        require_no_args(args)
        return self.runtime.profiles1.current if self.runtime.gpu1_enabled else None

    def profile1_set(self, args: dict[str, Any]) -> Any:
        name = args.pop("name", None)
        if args or not isinstance(name, str):
            raise ValueError("O argumento name é obrigatório")
        return self.runtime.set_profile1(name.lower())

    def extra_profile_get(self, slot: int, args: dict[str, Any]) -> Any:
        require_no_args(args)
        item = self.runtime.extra_gpus.get(slot)
        return item["profiles"].current if item else None

    def extra_profile_set(self, slot: int, args: dict[str, Any]) -> Any:
        name = args.pop("name", None)
        if args or not isinstance(name, str):
            raise ValueError("O argumento name é obrigatório")
        return self.runtime.set_extra_profile(slot, name.lower())

    def ram_used(self, args: dict[str, Any]) -> Any:
        return self._ram(args, "used_mb")

    def ram_total(self, args: dict[str, Any]) -> Any:
        return self._ram(args, "total_mb")

    def ram_usage(self, args: dict[str, Any]) -> Any:
        return self._ram(args, "usage_pct")

    def storage_list(self, args: dict[str, Any]) -> Any:
        return self._snapshot(args).get("disks", [])

    def power_total(self, args: dict[str, Any]) -> Any:
        return self._power(args, "estimated_total_w")

    def power_wall(self, args: dict[str, Any]) -> Any:
        return self._power(args, "estimated_wall_w")

    def power_load(self, args: dict[str, Any]) -> Any:
        return self._power(args, "load_pct")

    def power_history(self, args: dict[str, Any]) -> Any:
        period = args.pop("range", "24h")
        points = args.pop("points", 240)
        if args or not isinstance(period, str) or not isinstance(points, int):
            raise ValueError("Argumentos inválidos para power.history")
        if not 24 <= points <= 500:
            raise ValueError("points tem de estar entre 24 e 500")
        return self.runtime.history.query(period, points)
