from __future__ import annotations

from typing import Any


def require_no_args(args: dict[str, Any]) -> None:
    if args:
        raise ValueError("Este comando não aceita argumentos")

