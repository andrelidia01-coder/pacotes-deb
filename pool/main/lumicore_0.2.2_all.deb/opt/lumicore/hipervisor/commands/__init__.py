"""Catálogo fechado de comandos expostos ao LumiOS."""

