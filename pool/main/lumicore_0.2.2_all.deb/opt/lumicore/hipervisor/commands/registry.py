from __future__ import annotations

from collections.abc import Callable
from typing import Any

from hipervisor.commands.power import PowerCommands
from hipervisor.commands.services import ServiceCommands
from hipervisor.commands.system import SystemCommands


class CommandError(RuntimeError):
    """Erro esperado e seguro para apresentar ao cliente."""


class CommandRegistry:
    """Tabela fechada: um pedido produz somente um valor."""

    def __init__(self, runtime: Any, cfg: dict[str, Any]):
        system = SystemCommands(runtime)
        services = ServiceCommands(cfg["services"].get("allowed", []))
        power = PowerCommands()
        self._handlers: dict[str, Callable[[dict[str, Any]], Any]] = {
            "state": system.state,
            "cpu.temp": system.cpu_temp,
            "cpu.power": system.cpu_power,
            "cpu.usage": system.cpu_usage,
            "cpu.clock": system.cpu_clock,
            "gpu.name": system.gpu_name,
            "gpu.temp": system.gpu_temp,
            "gpu.power": system.gpu_power,
            "gpu.usage": system.gpu_usage,
            "gpu.clock": system.gpu_clock,
            "gpu.memory_clock": system.gpu_memory_clock,
            "gpu.vram.used": system.gpu_vram_used,
            "gpu.vram.total": system.gpu_vram_total,
            "gpu.fan": system.gpu_fan,
            "gpu.profile": system.profile_get,
            "gpu.profile.set": system.profile_set,
            "gpu1.name": system.gpu1_name,
            "gpu1.temp": system.gpu1_temp,
            "gpu1.power": system.gpu1_power,
            "gpu1.usage": system.gpu1_usage,
            "gpu1.clock": system.gpu1_clock,
            "gpu1.memory_clock": system.gpu1_memory_clock,
            "gpu1.fan": system.gpu1_fan,
            "gpu1.profile": system.profile1_get,
            "gpu1.profile.set": system.profile1_set,
            "fans.state": system.case_fans_state,
            "fans.front": system.case_fan_front,
            "fans.exhaust": system.case_fan_exhaust,
            "ram.used": system.ram_used,
            "ram.total": system.ram_total,
            "ram.usage": system.ram_usage,
            "storage.list": system.storage_list,
            "power.total": system.power_total,
            "power.wall": system.power_wall,
            "power.load": system.power_load,
            "power.history": system.power_history,
            "service.status": services.status,
            "service.start": services.start,
            "service.stop": services.stop,
            "server.shutdown": power.shutdown,
            "server.reboot": power.reboot,
        }
        for slot in (2, 3):
            for suffix, field in (("name", "name"), ("temp", "temp_c"),
                                  ("power", "power_w"), ("usage", "usage_pct"),
                                  ("clock", "clock_mhz"),
                                  ("memory_clock", "memory_clock_mhz"),
                                  ("fan", "fan_pct")):
                self._handlers[f"gpu{slot}.{suffix}"] = (
                    lambda args, slot=slot, field=field:
                    (system._snapshot(args).get(f"gpu{slot}") or {}).get(field))
            self._handlers[f"gpu{slot}.profile"] = (
                lambda args, slot=slot: system.extra_profile_get(slot, args))
            self._handlers[f"gpu{slot}.profile.set"] = (
                lambda args, slot=slot: system.extra_profile_set(slot, args))
        self._protected = frozenset({
            "gpu.profile.set", "gpu1.profile.set", "gpu2.profile.set", "gpu3.profile.set", "service.start", "service.stop",
            "server.shutdown", "server.reboot",
        })

    def requires_auth(self, name: str) -> bool:
        if name not in self._handlers:
            raise CommandError(f"Comando não autorizado: {name}")
        return name in self._protected

    def describe(self) -> list[dict[str, Any]]:
        """Lista estável de comandos sem revelar segredos."""
        return [
            {"name": name, "requires_auth": name in self._protected}
            for name in sorted(self._handlers)
        ]

    def execute(self, name: str, args: dict[str, Any] | None = None) -> Any:
        if name not in self._handlers:
            raise CommandError(f"Comando não autorizado: {name}")
        if args is None:
            args = {}
        if not isinstance(args, dict):
            raise CommandError("args tem de ser um objeto JSON")
        return self._handlers[name](args)
