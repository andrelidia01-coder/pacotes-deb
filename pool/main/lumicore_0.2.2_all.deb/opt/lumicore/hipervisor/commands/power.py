from __future__ import annotations

import time
from typing import Any

from hipervisor.core.command import run


class PowerCommands:
    @staticmethod
    def _confirm(args: dict[str, Any], expected: str) -> None:
        confirmation = args.pop("confirm", None)
        if args or confirmation != expected:
            raise ValueError(f"Confirmação obrigatória: {expected}")

    @staticmethod
    def _schedule(action: str) -> None:
        unit = f"lumios-{action}-{int(time.time())}"
        run([
            "systemd-run",
            f"--unit={unit}",
            "--on-active=3s",
            "/usr/bin/systemctl",
            action,
        ], timeout=5.0)

    def shutdown(self, args: dict[str, Any]) -> dict[str, Any]:
        self._confirm(args, "DESLIGAR")
        self._schedule("poweroff")
        return {"scheduled": "poweroff", "delay_s": 3}

    def reboot(self, args: dict[str, Any]) -> dict[str, Any]:
        self._confirm(args, "REINICIAR")
        self._schedule("reboot")
        return {"scheduled": "reboot", "delay_s": 3}

