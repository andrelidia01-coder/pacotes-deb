from __future__ import annotations

from typing import Any

from hipervisor.core.profile_db import load as load_database


def load(path: str) -> dict[str, Any]:
    cfg = load_database(path)
    validate(cfg)
    return cfg


def validate(cfg: dict[str, Any]) -> None:
    for section in ("server", "gpu", "gpu1", "profiles", "power", "thermal", "case_fans", "services", "energy_history"):
        if section not in cfg or not isinstance(cfg[section], dict):
            raise ValueError(f"Secção obrigatória inválida: {section}")
    gpu = cfg["gpu"]
    profiles = cfg["profiles"]
    if not profiles or not isinstance(gpu.get("adapter"), str) or not gpu["adapter"].startswith("/"):
        raise ValueError("GPU0 requer adaptador absoluto e perfis")
    if gpu.get("startup_profile") not in profiles:
        raise ValueError("Perfil inicial GPU0 ausente")
    if "fan_profile_percent" in gpu and set(gpu["fan_profile_percent"]) != set(profiles):
        raise ValueError("A política de ventoinha GPU0 deve cobrir todos os perfis")
    gpu1 = cfg["gpu1"]
    if not isinstance(gpu1.get("enabled"), bool):
        raise ValueError("gpu1.enabled inválido")
    if gpu1["enabled"]:
        if not isinstance(gpu1.get("adapter"), str) or not gpu1["adapter"].startswith("/"):
            raise ValueError("GPU1 requer adaptador absoluto")
        if gpu1.get("startup_profile") not in gpu1.get("profiles", {}):
            raise ValueError("Perfil inicial GPU1 ausente")
        if "fan_profile_percent" in gpu1 and set(gpu1["fan_profile_percent"]) != set(gpu1["profiles"]):
            raise ValueError("A política de ventoinha GPU1 deve cobrir todos os perfis")
    for slot in (2, 3):
        spec = cfg.get(f"gpu{slot}", {"enabled": False})
        if not isinstance(spec, dict) or not isinstance(spec.get("enabled"), bool):
            raise ValueError(f"gpu{slot}.enabled inválido")
        if not spec["enabled"]:
            continue
        expected = set(profiles)
        if not isinstance(spec.get("adapter"), str) or not spec["adapter"].startswith("/"):
            raise ValueError(f"GPU{slot} requer adaptador absoluto")
        if not isinstance(spec.get("uuid"), str) or not spec["uuid"].strip():
            raise ValueError(f"GPU{slot} requer UUID")
        if set(spec.get("profiles", {})) != expected or spec.get("startup_profile") not in expected:
            raise ValueError(f"GPU{slot} requer todos os perfis e perfil inicial")
        for name, profile in spec["profiles"].items():
            if not isinstance(profile, dict) or float(profile.get("power_limit_w", 0)) <= 0:
                raise ValueError(f"GPU{slot}.{name}: limite de potência inválido")
            for key in ("clock_mhz", "memory_clock_mhz"):
                if profile.get(key) is not None and float(profile[key]) <= 0:
                    raise ValueError(f"GPU{slot}.{name}.{key} inválido")
            for key in ("clock_offset_mhz", "memory_offset_mhz"):
                if key in profile and not isinstance(profile[key], (int, float)):
                    raise ValueError(f"GPU{slot}.{name}.{key} inválido")
        fans = spec.get("fan_profile_percent", {})
        if fans and set(fans) != expected:
            raise ValueError(f"GPU{slot}: política de ventoinha incompleta")
        for percent in fans.values():
            if percent is not None and (not isinstance(percent, int) or not 30 <= percent <= 100):
                raise ValueError(f"GPU{slot}: velocidade da ventoinha inválida")
    for key in ("gpu", "gpu1"):
        for name, value in cfg[key].get("fan_profile_percent", {}).items():
            if value is not None and (not isinstance(value, int) or not 30 <= value <= 100):
                raise ValueError(f"Ventoinha inválida {key}.{name}")
    for name, profile in profiles.items():
        if not isinstance(name, str) or not isinstance(profile, dict):
            raise ValueError("Perfil GPU0 inválido")
    if float(cfg["server"].get("interval_s", 0)) < 0.25:
        raise ValueError("interval_s mínimo: 0.25")
    thermal = cfg["thermal"]
    if set(thermal.get("profile_order", [])) != set(profiles):
        raise ValueError("profile_order não cobre todos os perfis GPU0")
    if not float(thermal["gpu_recovery_c"]) < float(thermal["gpu_alarm_c"]) <= float(thermal["gpu_limit_c"]):
        raise ValueError("Limites térmicos GPU inválidos")
    if not float(thermal["gpu_fan_boost_release_c"]) < float(thermal["gpu_fan_boost_c"]) < float(thermal["gpu_alarm_c"]):
        raise ValueError("Limites do reforço das ventoinhas inválidos")
    if cfg["case_fans"].get("enabled"):
        if not cfg["case_fans"].get("hwmon_name_prefix"):
            raise ValueError("Controlador de ventoinhas da caixa ausente")
    if float(cfg["power"].get("capacity_w", 0)) <= 0:
        raise ValueError("Capacidade PSU inválida")
    if float(cfg["power"].get("hard_limit_w", 0)) <= 0:
        raise ValueError("Limite energético inválido")
