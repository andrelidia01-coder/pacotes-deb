from __future__ import annotations

import threading
import time
from copy import deepcopy
from typing import Any


class StateStore:
    def __init__(self, version: str):
        self._lock = threading.Lock()
        self._snapshot: dict[str, Any] = {
            "api": 1,
            "version": version,
            "timestamp": time.time(),
            "state": "STARTING",
            "profile": None,
            "cpu": {},
            "gpu": None,
            "memory": {},
            "disks": [],
            "power": {},
            "fault": None,
            "errors": {},
        }

    def replace(self, snapshot: dict[str, Any]) -> None:
        with self._lock:
            self._snapshot = deepcopy(snapshot)

    def get(self) -> dict[str, Any]:
        with self._lock:
            return deepcopy(self._snapshot)
