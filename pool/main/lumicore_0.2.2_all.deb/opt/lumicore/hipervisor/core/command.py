from __future__ import annotations

import subprocess
from collections.abc import Sequence


def run(command: Sequence[str], timeout: float = 3.0) -> str:
    result = subprocess.run(
        list(command),
        check=True,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return result.stdout.strip()
