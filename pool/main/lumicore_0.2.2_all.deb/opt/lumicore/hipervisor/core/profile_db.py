"""Configuração por máquina em SQLite (.dat); nenhuma pesquisa automática por nome."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any


SCHEMA = 1


def create(path: str | Path, name: str, config: dict[str, Any]) -> None:
    target = Path(path)
    if target.exists():
        raise FileExistsError(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(target) as db:
        db.execute("CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        db.execute("CREATE TABLE sections (name TEXT PRIMARY KEY, document TEXT NOT NULL)")
        db.executemany("INSERT INTO meta VALUES (?,?)", [
            ("schema_version", str(SCHEMA)), ("name", name),
        ])
        db.executemany("INSERT INTO sections VALUES (?,?)", [
            (key, json.dumps(value, ensure_ascii=False, sort_keys=True))
            for key, value in config.items()
        ])
    target.chmod(0o600)


def load(path: str | Path) -> dict[str, Any]:
    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(f"BD do hipervisor ausente: {source}")
    with sqlite3.connect(f"file:{source}?mode=ro", uri=True) as db:
        meta = dict(db.execute("SELECT key, value FROM meta"))
        if meta.get("schema_version") != str(SCHEMA):
            raise ValueError("Versão incompatível da BD do hipervisor")
        cfg = {key: json.loads(document) for key, document in db.execute(
            "SELECT name, document FROM sections"
        )}
    if not all(isinstance(value, dict) for value in cfg.values()):
        raise ValueError("Secções inválidas na BD")
    cfg["instance_name"] = meta["name"]
    return cfg
