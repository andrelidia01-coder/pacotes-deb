"""Configuração e estado partilhado."""
