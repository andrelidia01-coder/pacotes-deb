"""Aplicação de perfis de hardware."""
