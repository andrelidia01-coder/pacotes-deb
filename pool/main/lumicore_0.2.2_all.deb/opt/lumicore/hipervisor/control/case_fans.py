from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Any


LOG = logging.getLogger("hipervisor")


class CaseFanController:
    """Controla zonas PWM da caixa através do hwmon do IT8688.

    O caminho ``hwmonN`` não é estável entre arranques, por isso o controlador
    é sempre descoberto pelo conteúdo do ficheiro ``name``.
    """

    def __init__(self, cfg: dict[str, Any], hwmon_root: str | Path = "/sys/class/hwmon"):
        self.cfg = cfg
        self.enabled = bool(cfg.get("enabled", False))
        self.hwmon_root = Path(hwmon_root)
        self.hwmon: Path | None = None
        self.zones: dict[str, dict[str, int]] = {}
        self.curve = list(cfg.get("curve", []))
        self.hysteresis_c = float(cfg.get("hysteresis_c", 3.0))
        self.down_delay_s = float(cfg.get("down_delay_s", 30.0))
        self.stall_timeout_s = float(cfg.get("stall_timeout_s", 5.0))
        self.current_level: int | None = None
        self.last_change = 0.0
        self._managed = False
        self._closed = False
        self._original: dict[str, dict[str, int]] = {}
        self._stall_since: dict[str, float | None] = {}
        self._last_state: dict[str, Any] = {
            "enabled": self.enabled,
            "managed": False,
            "fail_safe": False,
        }

        if not self.enabled:
            return

        self.hwmon = self._discover(str(cfg.get("hwmon_name_prefix", "it8688")))
        zones_cfg = dict(cfg.get("zones", {}))
        if len(zones_cfg) > 4:
            raise ValueError("Máximo de quatro ventoinhas da caixa")
        for name, zone in zones_cfg.items():
            if not zone.get("enabled", True):
                continue
            if zone.get("position", "unknown") not in ("unknown", "front", "frontal", "side", "lateral",
                                                      "rear", "traseira", "auxiliary", "auxiliar", "exhaust"):
                raise ValueError(f"Posição de ventoinha inválida: {name}")
            pwm = int(zone["pwm"])
            fan = int(zone.get("fan", pwm))
            self._require_node(f"pwm{pwm}", writable=True)
            self._require_node(f"pwm{pwm}_enable", writable=True)
            self._require_node(f"fan{fan}_input")
            self.zones[name] = {"pwm": pwm, "fan": fan}
            self._original[name] = {
                "enable": self._read_int(f"pwm{pwm}_enable"),
                "pwm": self._read_int(f"pwm{pwm}"),
            }
            self._stall_since[name] = None

        if not self.zones:
            self.enabled = False
            return

        LOG.info(
            "Ventoinhas da caixa: controlador %s; zonas %s",
            self.hwmon,
            ", ".join(f"{name}=PWM{zone['pwm']}" for name, zone in self.zones.items()),
        )

    def _discover(self, prefix: str) -> Path:
        for candidate in sorted(self.hwmon_root.glob("hwmon*")):
            try:
                name = (candidate / "name").read_text(encoding="ascii").strip()
            except OSError:
                continue
            if name.startswith(prefix):
                return candidate.resolve()
        raise RuntimeError(f"Controlador hwmon {prefix!r} não encontrado")

    def _path(self, name: str) -> Path:
        if self.hwmon is None:
            raise RuntimeError("Controlador das ventoinhas indisponível")
        return self.hwmon / name

    def _require_node(self, name: str, writable: bool = False) -> None:
        path = self._path(name)
        if not path.is_file():
            raise RuntimeError(f"Nó hwmon obrigatório ausente: {path}")
        if writable and not os.access(path, os.W_OK):
            raise RuntimeError(f"Nó hwmon não gravável: {path}")

    def _read_int(self, name: str) -> int:
        return int(self._path(name).read_text(encoding="ascii").strip())

    def _write_int(self, name: str, value: int) -> None:
        self._path(name).write_text(f"{int(value)}\n", encoding="ascii")

    def _ensure_manual(self) -> None:
        if self._managed:
            return
        for zone in self.zones.values():
            self._write_int(f"pwm{zone['pwm']}_enable", 1)
        self._managed = True

    def _apply_level(self, level: int) -> None:
        self._ensure_manual()
        point = self.curve[level]
        for name, zone in self.zones.items():
            value = int(point[f"{name}_pwm"])
            self._write_int(f"pwm{zone['pwm']}", value)

    def _apply_full(self) -> None:
        self._ensure_manual()
        for zone in self.zones.values():
            self._write_int(f"pwm{zone['pwm']}", 255)

    def _desired_level(self, temperature_c: float) -> int:
        desired = 0
        for index, point in enumerate(self.curve):
            if temperature_c >= float(point["temp_c"]):
                desired = index
        return desired

    def _read_zones(self, point: dict[str, Any]) -> dict[str, dict[str, Any]]:
        result: dict[str, dict[str, Any]] = {}
        for name, zone in self.zones.items():
            pwm = int(point[f"{name}_pwm"])
            result[name] = {
                "channel": int(zone["pwm"]),
                "pwm": pwm,
                "percent": round(pwm * 100.0 / 255.0, 1),
                "rpm": self._read_int(f"fan{zone['fan']}_input"),
            }
        return result

    def update(self, temperatures: dict[str, float | None], now: float | None = None) -> dict[str, Any]:
        if not self.enabled:
            return dict(self._last_state)
        if self._closed:
            raise RuntimeError("Controlador das ventoinhas já foi encerrado")
        if now is None:
            now = time.monotonic()

        missing = sorted(name for name, value in temperatures.items() if value is None)
        valid = {name: float(value) for name, value in temperatures.items() if value is not None}
        if missing or not valid:
            self._apply_full()
            zones = self._read_zones({f"{name}_pwm": 255 for name in self.zones})
            self._last_state = {
                "enabled": True,
                "managed": True,
                "controller": str(self.hwmon),
                "level": "failsafe",
                "control_source": None,
                "control_temp_c": max(valid.values()) if valid else None,
                "fail_safe": True,
                "fail_safe_reason": "missing_sensor:" + ",".join(missing or temperatures),
                "zones": zones,
            }
            return dict(self._last_state)

        source, temperature = max(valid.items(), key=lambda item: item[1])
        desired = self._desired_level(temperature)
        if self.current_level is None:
            self.current_level = desired
            self.last_change = now
        elif desired > self.current_level:
            # Acelera imediatamente; a histerese aplica-se apenas à descida.
            self.current_level = desired
            self.last_change = now
        elif desired < self.current_level:
            boundary = float(self.curve[self.current_level]["temp_c"])
            if (temperature <= boundary - self.hysteresis_c
                    and now - self.last_change >= self.down_delay_s):
                self.current_level -= 1
                self.last_change = now

        self._apply_level(self.current_level)
        point = self.curve[self.current_level]
        zones = self._read_zones(point)
        stalled: list[str] = []
        for name, values in zones.items():
            if int(values["pwm"]) > 0 and int(values["rpm"]) <= 0:
                if self._stall_since[name] is None:
                    self._stall_since[name] = now
                elif now - float(self._stall_since[name]) >= self.stall_timeout_s:
                    stalled.append(name)
            else:
                self._stall_since[name] = None

        if stalled:
            self._apply_full()
            zones = self._read_zones({f"{name}_pwm": 255 for name in self.zones})
            self._last_state = {
                "enabled": True,
                "managed": True,
                "controller": str(self.hwmon),
                "level": "failsafe",
                "control_source": source,
                "control_temp_c": round(temperature, 1),
                "fail_safe": True,
                "fail_safe_reason": "fan_stall:" + ",".join(stalled),
                "zones": zones,
            }
            return dict(self._last_state)

        self._last_state = {
            "enabled": True,
            "managed": True,
            "controller": str(self.hwmon),
            "level": str(point.get("name", self.current_level)),
            "control_source": source,
            "control_temp_c": round(temperature, 1),
            "fail_safe": False,
            "fail_safe_reason": None,
            "zones": zones,
        }
        return dict(self._last_state)

    def restore(self) -> None:
        """Devolve cada canal ao modo encontrado no arranque.

        Em modo automático (2), escrever primeiro em ``pwmN`` devolve EBUSY.
        Só restauramos o valor PWM quando o canal era originalmente manual.
        """
        if not self.enabled or self._closed:
            return
        errors: list[str] = []
        for name, zone in self.zones.items():
            original = self._original[name]
            try:
                if original["enable"] == 1:
                    self._write_int(f"pwm{zone['pwm']}_enable", 1)
                    self._write_int(f"pwm{zone['pwm']}", original["pwm"])
                else:
                    self._write_int(f"pwm{zone['pwm']}_enable", original["enable"])
            except OSError as exc:
                errors.append(f"{name}: {exc}")
        self._managed = False
        self._closed = True
        if errors:
            raise RuntimeError("; ".join(errors))
