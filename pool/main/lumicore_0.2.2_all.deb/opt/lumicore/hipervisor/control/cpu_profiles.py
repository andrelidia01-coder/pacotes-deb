"""Perfis de frequência CPU medidos por hipervisor-data; sempre restauráveis."""
from pathlib import Path

class CpuProfiles:
    def __init__(self,cfg):
        self.data=cfg.get('cpu_profiles',{}).get('profiles',{})
        paths=cfg.get('hardware_inventory',{}).get('cpu',{}).get('policies',[])
        self.policies=[Path(p)/'scaling_max_freq' for p in paths] if self.data else []
        self.original={}
        for p in self.policies:
            if p.is_file():
                try:self.original[p]=int(p.read_text().strip())
                except (ValueError,OSError):pass

    def apply(self,name):
        point=self.data.get(name)
        if not point or not self.original or not point.get('max_mhz_requested'):
            return
        requested=int(float(point['max_mhz_requested'])*1000)
        for p,original in self.original.items():
            minimum=p.with_name('scaling_min_freq')
            try:floor=int(minimum.read_text().strip())
            except (OSError,ValueError):floor=0
            target=min(original,max(floor,requested))
            p.write_text(str(target))
            observed=int(p.read_text().strip())
            if abs(observed-target)>1000:
                raise RuntimeError(f'CPU: frequência máxima não confirmada em {p}')

    def restore(self):
        for p,original in self.original.items():
            p.write_text(str(original))
