from __future__ import annotations

import logging
import threading
import time
from typing import Any

from hipervisor import __version__
from lumicore_fans import FanManager
from hipervisor.integrations.gpu_command import (
    GpuCommand, ExternalProfileController, ExternalFanController,
)
from hipervisor.control.case_fans import CaseFanController
from hipervisor.control.cpu_profiles import CpuProfiles
from hipervisor.commands.registry import CommandRegistry
from hipervisor.core.state import StateStore
from hipervisor.safety.guard import SafetyGuard
from hipervisor.safety.thermal import TemperatureFanBoost, ThermalLadder
from hipervisor.sensors.cpu import CpuSensor
from hipervisor.sensors.system import disks, memory
from hipervisor.energy.history import EnergyHistory
from hipervisor.energy.estimator import WallPowerEstimator


LOG = logging.getLogger("hipervisor")
STANDARD_FAN_PERCENT = {"max": 60, "sweet": 50, "med": 40,
                        "min": 40, "eco": 30, "standby": 30}


class Runtime:
    def __init__(self, cfg: dict[str, Any]):
        self.cfg = cfg
        self.state = StateStore(__version__)
        self.cpu = CpuSensor()
        self.gpu = GpuCommand(str(cfg["gpu"]["adapter"]), cfg["gpu"].get("uuid"))
        self.profiles = ExternalProfileController(self.gpu, cfg["profiles"])
        self.cpu_profiles = CpuProfiles(cfg)
        thermal = cfg["thermal"]
        self.thermal = ThermalLadder(
            list(thermal["profile_order"]),
            float(thermal["gpu_alarm_c"]),
            float(thermal["gpu_recovery_c"]),
            float(thermal["gpu_limit_c"]),
            float(thermal["step_interval_s"]),
            float(thermal["release_delay_s"]),
        )
        self.fans = ExternalFanController(self.gpu, bool(cfg["gpu"].get("fan_control", False)))
        self.gpu0_fan_profiles = dict(cfg["gpu"].get("fan_profile_percent", STANDARD_FAN_PERCENT))
        self.fan_boost = TemperatureFanBoost(
            float(thermal["gpu_fan_boost_c"]),
            float(thermal["gpu_fan_boost_release_c"]),
            int(thermal["gpu_fan_boost_percent"]),
        )
        gpu1 = cfg.get("gpu1", {})
        self.gpu1_enabled = bool(gpu1.get("enabled", False))
        self.gpu1_sensor = GpuCommand(str(gpu1["adapter"]), gpu1.get("uuid")) if self.gpu1_enabled else None
        self.profiles1 = ExternalProfileController(
            self.gpu1_sensor, gpu1.get("profiles", {})
        ) if self.gpu1_enabled else None
        self.gpu1_fan_profiles = dict(gpu1.get("fan_profile_percent", STANDARD_FAN_PERCENT))
        self.fan_boost1 = TemperatureFanBoost(
            float(thermal["gpu_fan_boost_c"]),
            float(thermal["gpu_fan_boost_release_c"]),
            int(thermal["gpu_fan_boost_percent"]),
        )
        self.thermal1 = ThermalLadder(
            ["max", "sweet", "med", "min", "eco"],
            float(thermal["gpu_alarm_c"]),
            float(thermal["gpu_recovery_c"]),
            float(thermal["gpu_limit_c"]),
            float(thermal["step_interval_s"]),
            float(thermal["release_delay_s"]),
        )
        self.fans1 = ExternalFanController(self.gpu1_sensor, bool(gpu1.get("fan_control", False))) if self.gpu1_enabled else None
        # GPU2 e GPU3 são opcionais. As entradas desativadas nem instanciam adaptador.
        self.extra_gpus = {}
        for slot in (2, 3):
            spec = cfg.get(f"gpu{slot}", {"enabled": False})
            if not spec.get("enabled", False):
                continue
            sensor = GpuCommand(str(spec["adapter"]), spec["uuid"])
            order = [name for name in thermal["profile_order"] if name in spec["profiles"]]
            self.extra_gpus[slot] = {
                "sensor": sensor,
                "profiles": ExternalProfileController(sensor, spec["profiles"]),
                "fans": ExternalFanController(sensor, bool(spec.get("fan_control", False))),
                "fan_profiles": dict(spec.get("fan_profile_percent", STANDARD_FAN_PERCENT)),
                "boost": TemperatureFanBoost(float(thermal["gpu_fan_boost_c"]),
                    float(thermal["gpu_fan_boost_release_c"]), int(thermal["gpu_fan_boost_percent"])),
                "thermal": ThermalLadder(order, float(thermal["gpu_alarm_c"]),
                    float(thermal["gpu_recovery_c"]), float(thermal["gpu_limit_c"]),
                    float(thermal["step_interval_s"]), float(thermal["release_delay_s"])),
                "startup": spec["startup_profile"],
            }
        self.platform_fans = FanManager()
        # Exclusive ownership of the H81's CPU+CASE hwmon outputs. Preserve
        # existing it87 native zone policies on every other platform.
        self.case_fans = CaseFanController(
            {"enabled": False} if self.platform_fans.detected()
            else cfg.get("case_fans", {})
        )
        self.guard = SafetyGuard(cfg)
        self.history = EnergyHistory(cfg["energy_history"])
        self.wall_estimator = WallPowerEstimator(cfg)
        self.commands = CommandRegistry(self, cfg)
        self.stop_event = threading.Event()
        self._sample_lock = threading.Lock()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        startup = self.cfg["gpu"]["startup_profile"]
        try:
            self.fans.prepare()
            self._set_gpu0_fan_policy(startup, force_auto=True)
            self._apply_gpu0_profile(startup)
            LOG.info("Perfil inicial aplicado: %s", startup)
        except Exception as exc:
            LOG.warning("Não foi possível aplicar o perfil inicial: %s", exc)
        if self.gpu1_enabled:
            startup1 = self.cfg["gpu1"].get("startup_profile", "eco")
            try:
                self._set_gpu1_fan_policy(startup1)
                self.profiles1.apply(startup1)
                LOG.info("Perfil inicial GPU1 aplicado: %s", startup1)
            except Exception as exc:
                LOG.warning("Não foi possível aplicar o perfil inicial GPU1: %s", exc)
        for slot, item in self.extra_gpus.items():
            try:
                item["fans"].prepare()
                self._set_extra_fan_policy(slot, item["startup"])
                item["profiles"].apply(item["startup"])
            except Exception as exc:
                LOG.warning("Não foi possível iniciar GPU%d: %s", slot, exc)
        self._thread = threading.Thread(target=self._loop, name="sampler", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        if self._thread:
            self._thread.join(timeout=5.0)
        # Hardware cooling comes first even when restoring CPU profiles fails.
        try:
            self.platform_fans.stop()
            LOG.info("H81 hwmon devolvido ao modo MAX")
        except Exception as exc:
            LOG.error("Não foi possível restaurar as ventoinhas H81: %s", exc)
        try:
            self.cpu_profiles.restore()
        except Exception as exc:
            LOG.error("Não foi possível restaurar o perfil CPU: %s", exc)
        try:
            self.case_fans.restore()
        except Exception as exc:
            LOG.error("Não foi possível restaurar as ventoinhas da caixa: %s", exc)

    def _apply_gpu0_profile(self, name: str) -> str:
        previous = self.profiles.current
        self.cpu_profiles.apply(name)
        try:
            return self.profiles.apply(name)
        except Exception:
            if previous is not None:
                self.cpu_profiles.apply(previous)
            else:
                self.cpu_profiles.restore()
            raise

    def set_profile(self, name: str) -> str:
        # Serializa ordens manuais com a amostragem/proteção térmica. Uma
        # escolha explícita substitui sempre a intenção térmica anterior.
        with self._sample_lock:
            snapshot = self.state.get()
            if snapshot.get("state") == "FAULT" and name != "eco":
                raise RuntimeError("Apenas o perfil eco é permitido durante FAULT")
            fan_percent = self.gpu0_fan_profiles.get(name)
            if fan_percent is not None:
                # A carga só pode começar depois de a própria GPU já estar
                # preparada para a potência pedida. As ventoinhas da caixa
                # são independentes e respondem somente às temperaturas.
                self.fans.set_speed(int(fan_percent))
            applied = self._apply_gpu0_profile(name)
            self.thermal.cancel()
            if fan_percent is None:
                self._set_gpu0_fan_policy(name)
            return applied

    def _set_gpu0_fan_policy(self, profile: str, force_auto: bool = False) -> None:
        percent = self.gpu0_fan_profiles.get(profile)
        if percent is None:
            self.fans.set_auto(force=force_auto)
        else:
            self.fans.set_speed(int(percent))

    def set_profile1(self, name: str) -> str:
        if not self.gpu1_enabled:
            raise RuntimeError("GPU1 está desativada")
        with self._sample_lock:
            snapshot = self.state.get()
            if snapshot.get("state") == "FAULT" and name != "eco":
                raise RuntimeError("Apenas o perfil eco é permitido durante FAULT")
            self._set_gpu1_fan_policy(name)
            applied = self.profiles1.apply(name)
            self.thermal1.cancel()
            return applied

    def _set_gpu1_fan_policy(self, profile: str) -> None:
        percent = self.gpu1_fan_profiles.get(profile)
        if percent is None:
            self.fans1.set_auto()
        else:
            self.fans1.set_speed(int(percent))

    def _set_extra_fan_policy(self, slot: int, profile: str) -> None:
        item = self.extra_gpus[slot]
        percent = item["fan_profiles"].get(profile)
        if percent is None:
            item["fans"].set_auto()
        else:
            item["fans"].set_speed(int(percent))

    def set_extra_profile(self, slot: int, name: str) -> str:
        if slot not in self.extra_gpus:
            raise RuntimeError(f"GPU{slot} está desativada")
        with self._sample_lock:
            if self.state.get().get("state") == "FAULT" and name != "eco":
                raise RuntimeError("Apenas o perfil eco é permitido durante FAULT")
            item = self.extra_gpus[slot]
            self._set_extra_fan_policy(slot, name)
            applied = item["profiles"].apply(name)
            item["thermal"].cancel()
            return applied

    def _update_gpu0_fan(
        self, temp_c: float | None, force_full: bool = False
    ) -> None:
        profile = self.profiles.current or "eco"
        baseline = self.gpu0_fan_profiles.get(profile)
        target = self.fan_boost.target(temp_c, baseline, force_full)
        if target is None:
            self.fans.set_auto()
        else:
            self.fans.set_speed(target)

    def _update_gpu1_fan(
        self, temp_c: float | None, force_full: bool = False
    ) -> None:
        profile = self.profiles1.current or "eco"
        baseline = self.gpu1_fan_profiles.get(profile)
        target = self.fan_boost1.target(temp_c, baseline, force_full)
        if target is None:
            self.fans1.set_auto()
        else:
            self.fans1.set_speed(target)

    def sample_now(self) -> dict[str, Any]:
        """Atualiza e devolve uma fotografia coerente do estado."""
        self._sample()
        return self.state.get()

    def _loop(self) -> None:
        interval = float(self.cfg["server"]["interval_s"])
        while not self.stop_event.is_set():
            started = time.monotonic()
            self._sample()
            remaining = interval - (time.monotonic() - started)
            self.stop_event.wait(max(0.05, remaining))

    def _sample(self) -> None:
        with self._sample_lock:
            self._sample_unlocked()

    def _sample_unlocked(self) -> None:
        errors: dict[str, str] = {}
        try:
            cpu = self.cpu.sample()
        except Exception as exc:
            cpu = {}
            errors["cpu"] = str(exc)
        try:
            gpu = self.gpu.sample()
            gpus = [gpu]
        except Exception as exc:
            gpus = []
            gpu = None
            errors["gpu"] = str(exc)
        gpu1 = None
        if self.gpu1_enabled:
            try:
                gpu1 = self.gpu1_sensor.sample()
                gpus.append(gpu1)
            except Exception as exc:
                errors["gpu1"] = str(exc)
        extra_samples = {}
        for slot, item in self.extra_gpus.items():
            try:
                extra_samples[slot] = item["sensor"].sample()
                gpus.append(extra_samples[slot])
            except Exception as exc:
                extra_samples[slot] = None
                errors[f"gpu{slot}"] = str(exc)
        case_fan_temperatures: dict[str, float | None] = {
            "cpu": cpu.get("temp_c"),
            "gpu0": gpu.get("temp_c") if gpu else None,
        }
        if self.gpu1_enabled:
            case_fan_temperatures["gpu1"] = gpu1.get("temp_c") if gpu1 else None
        for slot, sample in extra_samples.items():
            case_fan_temperatures[f"gpu{slot}"] = sample.get("temp_c") if sample else None
        case_fans: dict[str, Any] = {
            "enabled": False,
            "managed": False,
            "fail_safe": False,
        }
        case_fan_control_error = False
        # H81 has its own hwmon controller and curves. Other boards keep the
        # legacy CaseFanController policy unchanged.
        h81_present = self.platform_fans.detected()
        if not h81_present:
            try:
                case_fans = self.case_fans.update(case_fan_temperatures, time.monotonic())
            except Exception as exc:
                case_fan_control_error = True
                errors["case_fans"] = str(exc)
        cpu_power = cpu.get("power_w")
        gpu_powers = [item.get("power_w") for item in gpus if item.get("power_w") is not None]
        gpu_power = sum(float(value) for value in gpu_powers) if gpu_powers else None
        measured = None
        if cpu_power is not None or gpu_power is not None:
            measured = float(cpu_power or 0.0) + float(gpu_power or 0.0)
        wall_ac = self.wall_estimator.estimate(measured) if self.cfg["power"].get("enabled", True) else None
        efficiency = float(self.cfg["power"]["efficiency"])
        estimated_dc = wall_ac * efficiency if wall_ac is not None else None
        capacity = float(self.cfg["power"]["capacity_w"])
        load_pct = 100.0 * estimated_dc / capacity if estimated_dc is not None else None
        decision = self.guard.evaluate(cpu, gpus, estimated_dc)
        missing_gpus = ([0] if gpu is None else []) + ([1] if self.gpu1_enabled and gpu1 is None else [])
        missing_gpus += [slot for slot, sample in extra_samples.items() if sample is None]
        if missing_gpus:
            decision = type(decision)("FAULT", "GPU_SENSOR_MISSING:" + ",".join(map(str, missing_gpus)), "eco")
        if case_fan_control_error:
            decision = type(decision)("FAULT", "CASE_FAN_CONTROL_FAULT", "eco")
        elif case_fans.get("fail_safe"):
            reason = str(case_fans.get("fail_safe_reason") or "")
            if reason.startswith("fan_stall:"):
                decision = type(decision)("FAULT", "CASE_FAN_STALL", "eco")
            elif decision.state == "NORMAL":
                decision = type(decision)("DEGRADED", "CASE_FAN_SENSOR_MISSING", None)
        thermal_action = self.thermal.update(
            gpu.get("temp_c") if gpu else None,
            self.profiles.current,
            time.monotonic(),
        )
        try:
            self._update_gpu0_fan(
                gpu.get("temp_c") if gpu else None,
                thermal_action.fans_full is True,
            )
        except Exception as exc:
            errors["gpu0_fans"] = str(exc)
        if thermal_action.profile and thermal_action.profile != self.profiles.current:
            try:
                self._apply_gpu0_profile(thermal_action.profile)
                self.thermal.profile_applied(time.monotonic())
                LOG.warning("Proteção térmica GPU0: perfil %s", thermal_action.profile)
            except Exception as exc:
                errors["thermal_profile"] = str(exc)
        thermal_action1 = self.thermal1.update(
            gpu1.get("temp_c") if gpu1 else None,
            self.profiles1.current if self.gpu1_enabled else None,
            time.monotonic(),
        ) if self.gpu1_enabled else None
        if self.gpu1_enabled:
            try:
                self._update_gpu1_fan(
                    gpu1.get("temp_c") if gpu1 else None,
                    thermal_action1.fans_full is True,
                )
            except Exception as exc:
                errors["gpu1_fans"] = str(exc)
            if thermal_action1.profile and thermal_action1.profile != self.profiles1.current:
                try:
                    self.profiles1.apply(thermal_action1.profile)
                    self.thermal1.profile_applied(time.monotonic())
                    LOG.warning("Proteção térmica GPU1: perfil %s", thermal_action1.profile)
                except Exception as exc:
                    errors["gpu1_thermal_profile"] = str(exc)
            if thermal_action1.fault:
                decision = type(decision)("FAULT", "GPU1_THERMAL_FAULT", None)
        if thermal_action.fault:
            decision = type(decision)("FAULT", thermal_action.fault, None)
        for slot, item in self.extra_gpus.items():
            sample = extra_samples[slot]
            action = item["thermal"].update(sample.get("temp_c") if sample else None,
                item["profiles"].current, time.monotonic())
            try:
                baseline = item["fan_profiles"].get(item["profiles"].current or "eco")
                target = item["boost"].target(sample.get("temp_c") if sample else None,
                    baseline, action.fans_full is True)
                if target is None: item["fans"].set_auto()
                else: item["fans"].set_speed(target)
            except Exception as exc:
                errors[f"gpu{slot}_fans"] = str(exc)
            if action.profile and action.profile != item["profiles"].current:
                try:
                    item["profiles"].apply(action.profile)
                    item["thermal"].profile_applied(time.monotonic())
                except Exception as exc:
                    errors[f"gpu{slot}_thermal_profile"] = str(exc)
            if action.fault:
                decision = type(decision)("FAULT", f"GPU{slot}_THERMAL_FAULT", "eco")
        if decision.force_profile and self.profiles.current != decision.force_profile:
            try:
                self._apply_gpu0_profile(decision.force_profile)
                self._set_gpu0_fan_policy(decision.force_profile)
                LOG.error("Proteção acionada: %s", decision.fault)
            except Exception as exc:
                errors["safety_profile"] = str(exc)
        if (self.gpu1_enabled and decision.force_profile
                and self.profiles1.current != decision.force_profile):
            try:
                self.profiles1.apply(decision.force_profile)
                self._set_gpu1_fan_policy(decision.force_profile)
            except Exception as exc:
                errors["gpu1_safety_profile"] = str(exc)
        if decision.force_profile:
            for slot, item in self.extra_gpus.items():
                if item["profiles"].current != decision.force_profile:
                    try:
                        self._set_extra_fan_policy(slot, decision.force_profile)
                        item["profiles"].apply(decision.force_profile)
                    except Exception as exc:
                        errors[f"gpu{slot}_safety_profile"] = str(exc)
        if h81_present:
            # Use the GPU telemetry sampled by the existing adapters.
            # A missing GPU sample is NOT "GPU absent": it triggers CASE MAX.
            gpu_slots = [gpu]
            if self.gpu1_enabled:
                gpu_slots.append(gpu1)
            gpu_slots.extend(extra_samples[slot] for slot in sorted(extra_samples))
            fan_status = self.platform_fans.update(cpu.get("temp_c"), gpu_slots)
            case_fans = {
                "enabled": fan_status["enabled"],
                "managed": fan_status["active"],
                "controller": fan_status["controller"],
                "level": fan_status["mode"],
                "control_source": "cpu_gpu_fan_max",
                "control_temp_c": fan_status["cpu_temp_c"],
                "fail_safe": fan_status["fail_safe"],
                "fail_safe_reason": fan_status["reason"] if fan_status["fail_safe"] else None,
                "zones": {
                    "cpu": {"channel": 1, "percent": fan_status["cpu_target_pct"],
                            "rpm": fan_status["cpu_rpm"]},
                    "side": {"channel": 2, "percent": fan_status["case_target_pct"],
                             "rpm": fan_status["case_rpm"]},
                },
            }
            if fan_status["fail_safe"]:
                reason = fan_status["reason"]
                if reason in ("cpu_fan_stall_latched", "case_fan_stall_latched"):
                    decision = type(decision)("FAULT", "H81_FAN_STALL", "eco")
                elif decision.state == "NORMAL":
                    decision = type(decision)("DEGRADED", "H81_FAN_FAILSAFE", None)
        else:
            fan_status = self.platform_fans.status()
        snapshot = {
            "api": 1,
            "version": __version__,
            "timestamp": time.time(),
            "state": decision.state,
            "profile": self.profiles.current,
            "profile1": self.profiles1.current if self.gpu1_enabled else None,
            **{f"profile{slot}": item["profiles"].current for slot, item in self.extra_gpus.items()},
            "thermal": {
                "active": self.thermal.active,
                "original_profile": self.thermal.original,
                "fans_forced": self.fans.full_speed,
                "fan_manual": self.fans.manual,
                "fan_target_pct": self.fans.speed_percent,
                "fan_boosted": self.fan_boost.active,
                "gpu1_active": self.thermal1.active if self.gpu1_enabled else False,
                "gpu1_original_profile": self.thermal1.original if self.gpu1_enabled else None,
                "gpu1_fans_forced": self.fans1.full_speed if self.gpu1_enabled else False,
                "gpu1_fan_manual": self.fans1.manual if self.gpu1_enabled else False,
                "gpu1_fan_target_pct": self.fans1.speed_percent if self.gpu1_enabled else None,
                "gpu1_fan_boosted": self.fan_boost1.active if self.gpu1_enabled else False,
            },
            "case_fans": case_fans,
            "platform_fans": fan_status,
            "cpu": cpu,
            "gpu": gpu,
            "gpu1": gpu1,
            "gpu2": extra_samples.get(2),
            "gpu3": extra_samples.get(3),
            "gpus": gpus,
            "memory": memory(),
            "disks": disks(),
            "power": {
                "measured_w": round(measured, 2) if measured is not None else None,
                "measured_components_w": round(measured, 2) if measured is not None else None,
                "gpu_total_w": round(gpu_power, 2) if gpu_power is not None else None,
                "reserve_w": float(self.cfg["power"]["reserve_w"]),
                "estimated_total_w": round(estimated_dc, 2) if estimated_dc is not None else None,
                "estimated_wall_w": round(wall_ac, 2) if wall_ac is not None else None,
                "capacity_w": capacity,
                "estimator": "wattmeter_curve_v1",
                "efficiency": efficiency,
                "load_pct": round(load_pct, 1) if load_pct is not None else None,
                "hard_limit_w": float(self.cfg["power"]["hard_limit_w"]),
            },
            "fault": decision.fault,
            "errors": errors,
        }
        self.state.replace(snapshot)
        try:
            self.history.record(snapshot)
        except Exception as exc:
            LOG.warning("Falha no relatório energético: %s", exc)
