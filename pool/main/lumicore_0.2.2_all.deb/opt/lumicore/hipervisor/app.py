from __future__ import annotations

import argparse
import logging
import os
import signal
import threading

from hipervisor.api.server import ApiServer
from hipervisor.core.config import load
from hipervisor.runtime import Runtime


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Hipervisor Servidor modular")
    parser.add_argument("--database", required=True, help="dual-gpu.dat ou minipc.dat")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    os.environ["HIPERVISOR_DB"] = args.database
    cfg = load(args.database)
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    runtime = Runtime(cfg)
    server = ApiServer(
        (cfg["server"]["host"], int(cfg["server"]["port"])),
        runtime,
        str(cfg["server"].get("control_key", "")),
    )
    runtime.start()

    def request_stop(_signum: int, _frame: object) -> None:
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)
    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        server.server_close()
        runtime.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
