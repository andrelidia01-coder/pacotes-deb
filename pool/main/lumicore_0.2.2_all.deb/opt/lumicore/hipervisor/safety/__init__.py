"""Proteções térmicas e energéticas."""
