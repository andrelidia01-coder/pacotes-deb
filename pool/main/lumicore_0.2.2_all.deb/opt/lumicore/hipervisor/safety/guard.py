from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Decision:
    state: str
    fault: str | None
    force_profile: str | None


class SafetyGuard:
    def __init__(self, cfg: dict[str, Any]):
        self.gpu_limit = float(cfg["thermal"]["gpu_limit_c"])
        self.gpu_warning = float(cfg["thermal"].get("gpu_warning_c", self.gpu_limit - 5.0))
        self.cpu_limit = float(cfg["thermal"]["cpu_limit_c"])
        self.power_limit = float(cfg["power"]["hard_limit_w"])

    def evaluate(
        self,
        cpu: dict[str, Any],
        gpu: dict[str, Any] | list[dict[str, Any]] | None,
        estimated_power_w: float | None,
    ) -> Decision:
        gpu_list = gpu if isinstance(gpu, list) else ([gpu] if gpu else [])
        gpu_temps = [item.get("temp_c") for item in gpu_list if item.get("temp_c") is not None]
        gpu_temp = max(gpu_temps) if gpu_temps else None
        cpu_temp = cpu.get("temp_c")
        if cpu_temp is not None and cpu_temp >= self.cpu_limit:
            return Decision("FAULT", "CPU_OVER_TEMPERATURE", "eco")
        if estimated_power_w is not None and estimated_power_w >= self.power_limit:
            return Decision("FAULT", "POWER_LIMIT", "eco")
        if not gpu_list:
            return Decision("DEGRADED", "GPU_UNAVAILABLE", None)
        if gpu_temp is not None and gpu_temp >= self.gpu_warning:
            return Decision("DEGRADED", "GPU_AIRFLOW_WARNING", None)
        return Decision("NORMAL", None, None)
