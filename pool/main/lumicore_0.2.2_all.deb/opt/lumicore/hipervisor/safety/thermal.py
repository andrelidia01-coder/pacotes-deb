from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ThermalAction:
    profile: str | None = None
    fans_full: bool | None = None
    fault: str | None = None


class TemperatureFanBoost:
    """Pré-ventilação térmica com histerese, independente do perfil."""

    def __init__(
        self,
        threshold_c: float = 70.0,
        release_c: float = 67.0,
        percent: int = 80,
    ):
        self.threshold_c = float(threshold_c)
        self.release_c = float(release_c)
        self.percent = int(percent)
        self.active = False

    def target(
        self,
        temp_c: float | None,
        baseline: int | None,
        force_full: bool = False,
    ) -> int | None:
        if force_full:
            self.active = True
            return 100
        if temp_c is None:
            return baseline
        if temp_c >= self.threshold_c:
            self.active = True
        elif temp_c < self.release_c:
            self.active = False
        return self.percent if self.active else baseline


class ThermalLadder:
    """Proteção térmica por degraus, preservando o perfil pedido.

    Ao atingir o alarme baixa imediatamente dois níveis. A recuperação é
    deliberadamente lenta: cada subida exige ``release_s`` segundos
    consecutivos a, ou abaixo de, ``recovery_c``.
    """

    def __init__(
        self,
        order: list[str],
        alarm_c: float = 80.0,
        recovery_c: float = 70.0,
        critical_c: float = 83.0,
        step_s: float = 15.0,
        release_s: float = 30.0,
    ):
        self.order = order
        self.alarm_c = alarm_c
        self.recovery_c = recovery_c
        self.critical_c = critical_c
        self.step_s = step_s
        self.release_s = release_s
        self.active = False
        self.original: str | None = None
        self.last_step = 0.0
        self.original_since: float | None = None
        self.phase = "monitoring"

    def cancel(self) -> None:
        """Cancela uma recuperação antiga após uma ordem explícita do utilizador."""
        self.active = False
        self.original = None
        self.last_step = 0.0
        self.original_since = None
        self.phase = "monitoring"

    def profile_applied(self, now: float) -> None:
        """O intervalo térmico começa quando a transição realmente termina."""
        if self.active:
            self.last_step = now
            self.original_since = None

    def _down(self, profile: str, steps: int = 1) -> str:
        index = self.order.index(profile)
        return self.order[min(index + steps, len(self.order) - 1)]

    def _up(self, profile: str) -> str:
        assert self.original is not None
        index = self.order.index(profile)
        target = self.order.index(self.original)
        return self.order[max(index - 1, target)]

    def update(self, temp_c: float | None, profile: str | None, now: float) -> ThermalAction:
        if temp_c is None or profile not in self.order:
            return ThermalAction()

        if not self.active:
            if temp_c < self.alarm_c:
                return ThermalAction()
            self.active = True
            self.original = profile
            self.phase = "cooling"
            self.last_step = now
            self.original_since = None
            lowered = self._down(profile, 2)
            if lowered == profile and temp_c >= self.critical_c:
                return ThermalAction(fans_full=True, fault="GPU0_THERMAL_FAULT")
            return ThermalAction(
                profile=lowered if lowered != profile else None,
                fans_full=True,
            )

        # Um novo evento crítico pode voltar a baixar dois níveis, mas só
        # depois de o nível anterior ter tido tempo para produzir efeito.
        if temp_c >= self.alarm_c:
            self.original_since = None
            self.phase = "cooling"
            if now - self.last_step < self.step_s:
                return ThermalAction(fans_full=True)
            self.last_step = now
            lowered = self._down(profile, 2)
            if lowered == profile and temp_c >= self.critical_c:
                return ThermalAction(fans_full=True, fault="GPU0_THERMAL_FAULT")
            return ThermalAction(
                profile=lowered if lowered != profile else None,
                fans_full=True,
            )

        # A zona intermédia é estável. Qualquer amostra acima do limiar de
        # recuperação invalida toda a contagem anterior.
        if temp_c > self.recovery_c:
            self.original_since = None
            return ThermalAction(fans_full=True)

        if self.original_since is None:
            self.original_since = now
            self.phase = "recovering"
            return ThermalAction(fans_full=True)

        if now - self.original_since < self.release_s:
            return ThermalAction(fans_full=True)

        self.original_since = None
        self.last_step = now
        raised = self._up(profile)
        if raised != profile:
            return ThermalAction(profile=raised, fans_full=True)

        # O perfil originalmente pedido já passou mais uma janela completa
        # abaixo do limiar: termina a proteção e devolve a política normal.
        self.active = False
        self.original = None
        self.phase = "monitoring"
        return ThermalAction(fans_full=False)
