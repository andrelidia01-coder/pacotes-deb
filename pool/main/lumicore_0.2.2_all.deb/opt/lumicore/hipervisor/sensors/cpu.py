from __future__ import annotations

import glob
import os
import time
from pathlib import Path
from typing import Any


class CpuSensor:
    def __init__(self):
        self._last_total: int | None = None
        self._last_idle: int | None = None
        self._rapl_energy = self._find_rapl_energy()
        self._last_energy: int | None = None
        self._last_energy_time: float | None = None

    @staticmethod
    def _find_rapl_energy() -> Path | None:
        candidates = sorted(glob.glob("/sys/class/powercap/intel-rapl:*/energy_uj"))
        return Path(candidates[0]) if candidates else None

    @staticmethod
    def _read_number(path: str | Path) -> float | None:
        try:
            return float(Path(path).read_text(encoding="ascii").strip())
        except (OSError, ValueError):
            return None

    @staticmethod
    def _temperature() -> float | None:
        for base in sorted(glob.glob("/sys/class/hwmon/hwmon*")):
            try:
                if Path(base, "name").read_text(encoding="ascii").strip() != "coretemp":
                    continue
            except OSError:
                continue
            labels = sorted(glob.glob(f"{base}/temp*_label"))
            for label_path in labels:
                try:
                    label = Path(label_path).read_text(encoding="ascii").strip()
                except OSError:
                    continue
                if label == "Package id 0":
                    value = CpuSensor._read_number(label_path.replace("_label", "_input"))
                    return round(value / 1000.0, 1) if value is not None else None
        return None

    def _usage(self) -> float | None:
        try:
            fields = Path("/proc/stat").read_text(encoding="ascii").splitlines()[0].split()[1:]
            values = [int(item) for item in fields]
        except (OSError, ValueError, IndexError):
            return None
        total = sum(values)
        idle = values[3] + (values[4] if len(values) > 4 else 0)
        if self._last_total is None:
            usage = None
        else:
            delta_total = total - self._last_total
            delta_idle = idle - self._last_idle
            usage = 100.0 * (delta_total - delta_idle) / delta_total if delta_total > 0 else None
        self._last_total, self._last_idle = total, idle
        return round(usage, 1) if usage is not None else None

    def _power(self, now: float) -> float | None:
        if self._rapl_energy is None:
            return None
        value = self._read_number(self._rapl_energy)
        if value is None:
            return None
        power = None
        if self._last_energy is not None and self._last_energy_time is not None:
            delta = value - self._last_energy
            if delta < 0:
                maximum = self._read_number(self._rapl_energy.with_name("max_energy_range_uj"))
                if maximum is not None:
                    delta += maximum
            elapsed = now - self._last_energy_time
            if elapsed > 0 and delta >= 0:
                power = delta / 1_000_000.0 / elapsed
        self._last_energy, self._last_energy_time = int(value), now
        return round(power, 2) if power is not None else None

    @staticmethod
    def _clock() -> int | None:
        values = []
        for path in glob.glob("/sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq"):
            value = CpuSensor._read_number(path)
            if value is not None:
                values.append(value / 1000.0)
        return round(sum(values) / len(values)) if values else None

    def sample(self, now: float | None = None) -> dict[str, Any]:
        timestamp = time.monotonic() if now is None else now
        return {
            "usage_pct": self._usage(),
            "temp_c": self._temperature(),
            "power_w": self._power(timestamp),
            "clock_mhz": self._clock(),
            "cores": os.cpu_count(),
        }
