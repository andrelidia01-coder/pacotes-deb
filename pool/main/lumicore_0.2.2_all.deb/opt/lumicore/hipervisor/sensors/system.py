from __future__ import annotations

import os
from pathlib import Path
from typing import Any


def memory() -> dict[str, Any]:
    values: dict[str, int] = {}
    try:
        for line in Path("/proc/meminfo").read_text(encoding="ascii").splitlines():
            key, raw = line.split(":", 1)
            values[key] = int(raw.strip().split()[0])
    except (OSError, ValueError, IndexError):
        return {}
    total = values.get("MemTotal")
    available = values.get("MemAvailable")
    if total is None or available is None:
        return {}
    used = total - available
    return {
        "used_mb": round(used / 1024.0, 1),
        "total_mb": round(total / 1024.0, 1),
        "usage_pct": round(100.0 * used / total, 1),
    }


def disks() -> list[dict[str, Any]]:
    mounts: list[dict[str, Any]] = []
    seen: set[str] = set()
    try:
        lines = Path("/proc/self/mounts").read_text(encoding="utf-8").splitlines()
    except OSError:
        return mounts
    for line in lines:
        fields = line.split()
        if len(fields) < 3:
            continue
        source, target, fstype = fields[:3]
        target = target.replace("\\040", " ")
        if not source.startswith("/dev/") or target in seen:
            continue
        try:
            stats = os.statvfs(target)
        except OSError:
            continue
        total = stats.f_blocks * stats.f_frsize
        available = stats.f_bavail * stats.f_frsize
        if total <= 0:
            continue
        used = total - available
        seen.add(target)
        mounts.append({
            "path": target,
            "fstype": fstype,
            "used_gb": round(used / 1024**3, 1),
            "total_gb": round(total / 1024**3, 1),
            "usage_pct": round(100.0 * used / total, 1),
        })
    return mounts
