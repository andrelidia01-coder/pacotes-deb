from __future__ import annotations

from typing import Any

from hipervisor.integrations.amd_smi import AMD_SMI_VERSION, AmdSmiClient


class AmdSensor:
    def __init__(
        self,
        client: AmdSmiClient,
        amd_index: int = 0,
        logical_index: int = 1,
    ):
        self.client = client
        self.amd_index = amd_index
        self.logical_index = logical_index

    def sample(self) -> dict[str, Any]:
        raw = self.client.query(self.amd_index)
        pci = str(raw.get("pci") or "desconhecido")
        return {
            "index": self.logical_index,
            "amd_index": raw.get("index", self.amd_index),
            "uuid": f"PCI-{pci}",
            "pci_bdf": pci,
            "vendor": "AMD",
            "name": raw.get("name") or "AMD GPU",
            "driver": raw.get("driver"),
            "temp_c": raw.get("temperature_c"),
            "usage_pct": raw.get("utilization_percent"),
            "power_w": raw.get("power_w"),
            "power_limit_w": raw.get("power_cap_w"),
            "clock_mhz": raw.get("core_clock_mhz"),
            "memory_clock_mhz": raw.get("memory_clock_mhz"),
            "vram_used_mb": raw.get("vram_used_mib"),
            "vram_total_mb": raw.get("vram_total_mib"),
            "fan_rpm": raw.get("fan_rpm"),
            "fan_pct": raw.get("fan_percent"),
            "fan_mode": raw.get("fan_mode"),
            "performance_level": raw.get("performance_level"),
            "pcie_speed": raw.get("pcie_speed"),
            "pcie_width": raw.get("pcie_width"),
            "backend": "amd-smi",
            "backend_version": AMD_SMI_VERSION,
        }
