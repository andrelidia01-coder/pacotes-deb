"""Sensores de hardware, sem decisões de política."""
