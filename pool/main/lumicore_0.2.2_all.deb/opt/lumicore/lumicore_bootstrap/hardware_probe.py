"""LumiCore read-only hardware inventory and telemetry in SETUP or READY.

No writes to sysfs, MSRs, fan controllers, GPU drivers or firmware.
Unavailable fields remain None; installed hardware is discovered independently of LHDB.
"""
from __future__ import annotations

import os
from pathlib import Path
import re
import struct
import subprocess
import threading
import time

try:
    from hipervisor.sensors.cpu import CpuSensor
    from hipervisor.sensors.system import memory, disks
except ImportError:
    CpuSensor = None
    def memory(): return {}
    def disks(): return []

CPU_SENSOR = CpuSensor() if CpuSensor else None
_CACHE_LOCK = threading.RLock()
_CACHE = {'at': 0.0, 'value': None}


def _text(path):
    try:
        return Path(path).read_text(encoding='utf-8', errors='replace').strip()
    except (OSError, UnicodeError):
        return None


def _float(value):
    if value is None: return None
    try: return float(str(value).strip().replace(' %', '').replace(' W', '').replace(' MiB', '').replace(' MHz', ''))
    except ValueError: return None


def _first_cpu():
    raw = _text('/proc/cpuinfo') or ''
    blocks = [x for x in raw.split('\n\n') if x.strip()]
    data = []
    for block in blocks:
        d = dict((a.strip(),b.strip()) for line in block.splitlines() if ':' in line for a,b in [line.split(':',1)])
        if 'processor' in d: data.append(d)
    return data


def _cpu_pl():
    info = {'pl1_w': None, 'pl2_w': None, 'lock': None, 'source': 'unavailable',
            'package_scope': True, 'patch_applied': None}
    path = '/dev/cpu/0/msr'
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, 'O_CLOEXEC', 0))
        try:
            units = struct.unpack('<Q', os.pread(fd, 8, 0x606))[0]
            raw = struct.unpack('<Q', os.pread(fd, 8, 0x610))[0]
        finally:
            os.close(fd)
        watt_unit = 1/(1 << (units & 0xF))
        info.update(pl1_w=round((raw & 0x7fff) * watt_unit, 2),
                    pl2_w=round(((raw >> 32) & 0x7fff) * watt_unit, 2),
                    pl1_enabled=bool(raw & (1 << 15)),
                    pl2_enabled=bool(raw & (1 << 47)),
                    lock=bool(raw & (1 << 63)), source='msr 0x610',
                    patch_applied=None)
        return info
    except (OSError, ValueError, struct.error):
        pass
    for base in sorted(Path('/sys/class/powercap').glob('intel-rapl:*')):
        if ':' in base.name.removeprefix('intel-rapl:'): continue
        if (_text(base/'name') or '').lower() not in ('package-0','package-1','package'): continue
        values = {}
        for index in (0,1):
            name = (_text(base / f'constraint_{index}_name') or '').lower()
            raw = _float(_text(base/f'constraint_{index}_power_limit_uw'))
            if raw is not None:
                values['pl2_w' if 'short' in name else 'pl1_w' if 'long' in name else f'pl{index+1}_w'] = round(raw/1e6,2)
        if values:
            info.update(values); info['source']='intel-rapl sysfs'; break
    return info


def _cpu():
    entries = _first_cpu()
    first = entries[0] if entries else {}
    pairs = {(e.get('physical id','0'),e['core id']) for e in entries if 'core id' in e}
    physical = len(pairs) or (int(first['cpu cores']) if first.get('cpu cores','').isdigit() else None)
    logical = len(entries) or os.cpu_count()
    freqs=[]
    cpus=sorted(Path('/sys/devices/system/cpu').glob('cpu[0-9]*'),key=lambda p:int(p.name[3:]))
    for path in cpus:
        curr = _float(_text(path/'cpufreq/scaling_cur_freq'))
        if curr is None:
            idx=int(path.name[3:])
            if idx < len(entries): curr = _float(entries[idx].get('cpu MHz'))
            mhz=round(curr) if curr is not None else None
        else:
            mhz=round(curr/1000)
        freqs.append({'cpu':int(path.name[3:]),'mhz':mhz})
    if not freqs:
        for i,e in enumerate(entries):
            mhz=_float(e.get('cpu MHz'))
            freqs.append({'cpu':i,'mhz':round(mhz) if mhz is not None else None})
    valid=[r['mhz'] for r in freqs if r['mhz'] is not None]
    sample=CPU_SENSOR.sample() if CPU_SENSOR else {}
    governors={v for p in cpus if (v:=_text(p/'cpufreq/scaling_governor'))}
    turbo=_text('/sys/devices/system/cpu/intel_pstate/no_turbo')
    if turbo is None:
        turbo=_text('/sys/devices/system/cpu/cpufreq/boost')
        turbo_enabled=(turbo=='1') if turbo in ('0','1') else None
    else:
        turbo_enabled=(turbo=='0') if turbo in ('0','1') else None
    maxima=[_float(_text(p/'cpufreq/cpuinfo_max_freq')) for p in cpus]
    maxima=[round(x/1000) for x in maxima if x is not None]
    return {'model':first.get('model name'), 'physical_cores':physical,
            'logical_cpus':logical,'threads':logical,
            'frequencies_mhz':freqs,'clock_mhz':round(sum(valid)/len(valid)) if valid else sample.get('clock_mhz'),
            'min_mhz':min(valid) if valid else None, 'max_mhz':max(valid) if valid else None,
            'rated_max_mhz':max(maxima) if maxima else None,
            'usage_pct':sample.get('usage_pct'), 'power_w':sample.get('power_w'),
            'temp_c':sample.get('temp_c'),
            'governor':next(iter(governors)) if len(governors)==1 else ', '.join(sorted(governors)) if governors else None,
            'turbo_enabled':turbo_enabled, 'pl':_cpu_pl()}


def _gpus():
    result=[]
    vendor_lookup={'0x10de':'NVIDIA','0x1002':'AMD','0x8086':'Intel'}
    for pci in sorted(Path('/sys/bus/pci/devices').glob('*')):
        vendor=_text(pci/'vendor')
        cls=_text(pci/'class') or ''
        if vendor not in vendor_lookup or not cls.startswith('0x03'): continue
        try: driver=(pci/'driver').resolve().name if (pci/'driver').exists() else None
        except OSError: driver=None
        result.append({'pci':pci.name,'vendor':vendor_lookup[vendor],
                       'device_id':_text(pci/'device'), 'name':None,
                       'driver':driver,'fan_pct':None,'fan_rpm':None,
                       'temp_c':None,'usage_pct':None,'power_w':None,
                       'core_mhz':None,'mem_mhz':None,'vram_used_mb':None,'vram_total_mb':None,
                       'telemetry_ok':False})
    # NVIDIA: nvidia-smi may fail or omit individual devices, but PCI inventory remains.
    nv=[d for d in result if d['vendor']=='NVIDIA']
    if nv:
        keys='pci.bus_id,name,temperature.gpu,utilization.gpu,power.draw,clocks.current.graphics,clocks.current.memory,memory.used,memory.total,fan.speed'
        try:
            p=subprocess.run(['nvidia-smi','--query-gpu='+keys,'--format=csv,noheader,nounits'],
                             capture_output=True,text=True,timeout=3,check=True)
            rows=[x.strip() for x in p.stdout.splitlines() if x.strip()]
            for line in rows:
                parts=[p.strip() for p in line.split(',')]
                if len(parts)!=10: continue
                bus,name,*metrics=parts
                pci=bus.lower()
                pci=re.sub(r'^00000000:', '0000:', pci)
                dev=next((d for d in nv if d['pci'].lower()==pci),None)
                if dev is None:
                    # NVIDIA sometimes prints domain 00000000 vs 0000; use BDF (last 7 chars).
                    dev=next((d for d in nv if d['pci'][-7:].lower()==pci[-7:]),None)
                if dev is None: continue
                vals=[_float(v) for v in metrics]
                for k,v in zip(['temp_c','usage_pct','power_w','core_mhz','mem_mhz','vram_used_mb','vram_total_mb','fan_pct'],vals):
                    dev[k]=v
                dev['name']=name
                dev['telemetry_ok']=True
        except (OSError, ValueError, subprocess.SubprocessError):
            pass
    for dev in result:
        if dev['vendor']!='AMD': continue
        base=Path('/sys/bus/pci/devices')/dev['pci']
        for hw in sorted((base/'hwmon').glob('hwmon*')):
            def sensor(name,scale=1):
                v=_float(_text(hw/name))
                return round(v/scale,1) if v is not None else None
            dev['temp_c']=sensor('temp1_input',1000)
            dev['power_w']=sensor('power1_average',1e6) or sensor('power1_input',1e6)
            dev['fan_rpm']=sensor('fan1_input')
            p=sensor('pwm1')
            dev['fan_pct']=round(p*100/255,1) if p is not None else None
            dev['telemetry_ok']=any(dev[k] is not None for k in ['temp_c','power_w','fan_rpm'])
            break
        used=_float(_text(base/'mem_info_vram_used'))
        total=_float(_text(base/'mem_info_vram_total'))
        dev['vram_used_mb']=round(used/1048576) if used is not None else None
        dev['vram_total_mb']=round(total/1048576) if total is not None else None
        # Report vendor/device PCI identifier if no reliable consumer card label.
        dev['name']='AMD PCI '+(dev['device_id'] or '?')
    for dev in result:
        if not dev['name']: dev['name']=dev['vendor']+' PCI '+(dev['device_id'] or '?')
    return result


def _collect():
    return {'timestamp':time.time(),'cpu':_cpu(),'ram':memory(), 'gpus':_gpus(),
            'disks':disks(), 'board':{'vendor':_text('/sys/class/dmi/id/board_vendor'),
                                     'name':_text('/sys/class/dmi/id/board_name')},
            'info':'Telemetria de leitura; não ativa perfis GPU nem altera PL.'}


def snapshot():
    now=time.monotonic()
    with _CACHE_LOCK:
        if _CACHE['value'] is not None and now-_CACHE['at']<2.0:
            return _CACHE['value']
        value=_collect()
        _CACHE.update(at=now,value=value)
        return value
