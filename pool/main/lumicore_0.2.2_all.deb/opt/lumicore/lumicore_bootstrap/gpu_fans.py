"""Read GPU FAN DUTY (not GPU utilization), strictly read-only.

If an installed GPU cannot report fan duty, return None so H81 CASE
stays at 100 percent. Absence of installed NVIDIA/AMD GPUs returns [].
This is only the temporary SETUP provider; the approved core uses GPU adapters.
"""
from pathlib import Path
import subprocess
import time

_GPU_VENDORS = {'0x10de', '0x1002'}


def _devices(root='/sys/bus/pci/devices'):
    result = []
    for dev in Path(root).glob('*'):
        try:
            vendor = (dev / 'vendor').read_text().strip().lower()
            pci_class = (dev / 'class').read_text().strip().lower()
            if vendor in _GPU_VENDORS and (pci_class.startswith('0x03')):
                result.append((vendor, dev))
        except OSError:
            continue
    return result


def _nvidia_fans():
    try:
        p = subprocess.run(['nvidia-smi', '--query-gpu=fan.speed',
                            '--format=csv,noheader,nounits'],
                           text=True, capture_output=True, timeout=2, check=True)
        rows = [v.strip().replace(' %', '') for v in p.stdout.splitlines() if v.strip()]
        result = [float(x) for x in rows]
        if not result or any(x < 0 or x > 100 for x in result):
            return None
        return result
    except (FileNotFoundError, ValueError, OSError,
            subprocess.SubprocessError):
        return None


def _amd_fans(devices):
    values = []
    for device in devices:
        # This is the GPU's own hwmon PWM, not the chassis fan controller.
        paths = list((device / 'hwmon').glob('hwmon*/pwm1'))
        if len(paths) != 1:
            return None
        try:
            pct = round(int(paths[0].read_text().strip()) * 100 / 255)
            if not 0 <= pct <= 100:
                return None
            values.append(pct)
        except (OSError, ValueError):
            return None
    return values


def read_gpu_fans():
    devices = _devices()
    nv = [d for vendor, d in devices if vendor == '0x10de']
    amd = [d for vendor, d in devices if vendor == '0x1002']
    fans = []
    if nv:
        nvidia = _nvidia_fans()
        if nvidia is None or len(nvidia) != len(nv):
            return None
        fans.extend(nvidia)
    if amd:
        amdfans = _amd_fans(amd)
        if amdfans is None:
            return None
        fans.extend(amdfans)
    return fans


class CachedProvider:
    def __init__(self, interval=3.0):
        self.interval = interval
        self.next_check = 0.0
        self.result = None

    def get(self):
        now = time.monotonic()
        if now >= self.next_check:
            self.next_check = now + self.interval
            self.result = read_gpu_fans()
        return self.result
