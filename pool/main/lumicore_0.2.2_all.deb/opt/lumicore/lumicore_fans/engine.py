"""Generic platform fan manager. Only a plugin knows board-specific rules."""
from __future__ import annotations
import importlib
import logging
import pkgutil
from time import monotonic

LOG = logging.getLogger('lumicore.fans')


class FanManager:
    """Discover optional lumicore_platforms.* plugins without assuming hardware."""

    def __init__(self):
        self._delegate = None
        self._plugin = None
        self._scan_at = 0.0

    def _get(self):
        if self._delegate is not None:
            try:
                if self._delegate.detected():
                    return self._delegate
            except Exception as exc:
                LOG.warning('Plugin ventilação indisponível: %s', exc)
            self._delegate = None
            self._plugin = None
        now = monotonic()
        if now < self._scan_at:
            return None
        self._scan_at = now + 3.0
        try:
            namespace = importlib.import_module('lumicore_platforms')
            for item in pkgutil.iter_modules(namespace.__path__):
                try:
                    plugin = importlib.import_module(f'lumicore_platforms.{item.name}.plugin')
                    manager = plugin.discover()
                    if manager is not None:
                        self._delegate = manager
                        self._plugin = plugin
                        LOG.info('Controlador de plataforma detetado: %s', item.name)
                        return manager
                except (ImportError, OSError, ValueError) as exc:
                    LOG.debug('Plugin %s indisponível: %s', item.name, exc)
        except ImportError:
            pass
        return None

    def detected(self):
        return self._get() is not None

    def status(self):
        manager = self._get()
        if manager is not None:
            return manager.status()
        return {'platform': None, 'present': False, 'enabled': False,
                'active': False, 'mode': 'absent', 'controller': None,
                'cpu_temp_c': None, 'gpu_fans_pct': None, 'demand_pct': None,
                'cpu_target_pct': 100, 'case_target_pct': 100,
                'cpu_rpm': None, 'case_rpm': None,
                'reason': 'controller_absent', 'fail_safe': False}

    def settings(self):
        manager = self._get()
        return manager.settings() if manager else {'platform': None, 'available': False,
                                                    'settings': None}

    def save(self, settings):
        manager = self._get()
        if manager is None:
            raise RuntimeError('Controlador de plataforma indisponível')
        return manager.save(settings)

    def update(self, cpu_temp, gpu_slots):
        manager = self._get()
        return manager.update(cpu_temp, gpu_slots) if manager else self.status()

    def preview(self, payload):
        if self._get() is None or self._plugin is None:
            raise RuntimeError('Controlador de plataforma indisponível')
        return self._plugin.preview(payload)

    def stop(self):
        manager = self._get()
        if manager is not None:
            manager.stop()
