"""Generic fan platform discovery; all platform-specific implementations are optional."""
from .engine import FanManager
__all__=['FanManager']
