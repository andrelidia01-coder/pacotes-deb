"""LumiCore 0.2 platform API adapter for the native H81 fan controller.

Importantly, instantiate the PLATFORM FanManager, not the legacy generic
FanManager(store, read_cpu_c, gpu_fans) from earlier prototype versions.
"""
from .engine import FanManager
from .curves import H81Curves
from .config import validate_h81
from .platform import detect_platform


def discover():
    # Cheap, read-only gate: only the exact INTEL/H81 board with h81_fan hwmon.
    if detect_platform() != 'h81':
        return None
    manager = FanManager()
    return manager if manager.detected() else None


def preview(payload):
    if not isinstance(payload, dict):
        raise ValueError('Pedido inválido')
    settings = validate_h81(payload['settings'])
    result = H81Curves(settings).calculate(payload['cpu_temp_c'], payload['gpu_fans_pct'])
    return {'cpu_pct': result.cpu_pct, 'case_pct': result.case_pct,
            'demand_pct': result.demand_pct, 'reason': result.reason}
