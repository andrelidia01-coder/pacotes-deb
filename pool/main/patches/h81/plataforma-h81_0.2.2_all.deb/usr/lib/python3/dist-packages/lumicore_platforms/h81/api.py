"""Framework-neutral fan endpoints. Attach only behind existing LumiCore auth/CSRF.

Return (HTTP status, JSON-able object), not an HTTP listener. No new network port.
Existing web authentication MUST gate read/write routes; writes require CSRF.
"""
from copy import deepcopy
from .config import InvalidSettings,validate_h81
from .curves import H81Curves

class FanAPI:
    def __init__(self,manager,store):
        self.manager=manager
        self.store=store

    def dispatch(self,method,path,payload=None,authenticated=False,csrf_ok=False):
        if not authenticated:
            return 401,{'error':'Autenticação necessária'}
        if method=='GET' and path=='/api/fans/status':
            return 200,self.manager.status()
        if method=='GET' and path=='/api/fans/settings':
            return 200,{'platform':'h81','settings':self.store.get_platform('h81'),
                        'available':self.manager.status().get('platform')=='h81'}
        if method=='POST' and path=='/api/fans/preview':
            try:
                payload=payload or {}
                cfg=validate_h81(payload['settings'])
                t=payload['cpu_temp_c']
                g=payload['gpu_fans_pct']
                # Preview never reads/writes real fan hardware.
                decision=H81Curves(cfg).calculate(t,g)
                return 200,{'cpu_percent':decision.cpu_pct,'case_percent':decision.case_pct,
                            'reason':decision.reason,'demand_percent':decision.demand_pct}
            except (ValueError,TypeError,KeyError,OverflowError):
                return 400,{'error':'Pedido inválido'}
        if method=='PUT' and path=='/api/fans/settings':
            if not csrf_ok:
                return 403,{'error':'Proteção CSRF necessária'}
            try:
                cfg=validate_h81(payload)
                self.store.save_platform('h81',cfg)
                self.manager.reload_settings()
                return 200,{'ok':True,'platform':'h81','settings':deepcopy(cfg)}
            except (InvalidSettings,TypeError,ValueError) as exc:
                return 400,{'error':str(exc)}
        return 404,{'error':'API desconhecida'}
