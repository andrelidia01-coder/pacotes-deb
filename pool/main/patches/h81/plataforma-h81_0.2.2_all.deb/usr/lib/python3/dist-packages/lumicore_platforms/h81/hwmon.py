"""Linux hwmon driver adapter; does not open the CH340 USB serial port."""
from pathlib import Path

class HwmonFans:
    def __init__(self, path):
        self.path=Path(path)
        if (self.path/'name').read_text().strip()!='h81_fan':
            raise ValueError('Controlador inesperado')

    @classmethod
    def discover(cls, base='/sys/class/hwmon'):
        for p in sorted(Path(base).glob('hwmon*')):
            try:
                if (p/'name').read_text().strip()=='h81_fan':
                    return cls(p)
            except (OSError,ValueError):
                pass
        return None

    def read(self):
        def integer(name):return int((self.path/name).read_text().strip())
        return {'cpu_rpm':integer('fan1_input'),'case_rpm':integer('fan2_input'),
                'cpu_pwm':integer('pwm1'),'case_pwm':integer('pwm2'),
                'cpu_enable':integer('pwm1_enable'),'case_enable':integer('pwm2_enable')}

    def max(self):
        # 0 means forced maximum specifically in the current H81 driver.
        for i in (1,2):
            (self.path/f'pwm{i}_enable').write_text('0\n')

    def apply(self, cpu_pct,case_pct):
        if not 30<=cpu_pct<=100 or not 0<=case_pct<=100:
            raise ValueError('PWM fora dos limites de segurança')
        def pwm(pct): return int(pct*255/100+0.5)
        try:
            (self.path/'pwm1').write_text(f'{pwm(cpu_pct)}\n')
            (self.path/'pwm2').write_text(f'{pwm(case_pct)}\n')
            (self.path/'pwm1_enable').write_text('1\n')
            (self.path/'pwm2_enable').write_text('1\n')
        except (OSError,ValueError):
            try:self.max()
            except OSError:pass
            raise
