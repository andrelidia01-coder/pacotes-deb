"""CPU package sensor and explicit GPU provider integration contract."""
from pathlib import Path

def cpu_package_temperature(hwmon='/sys/class/hwmon'):
    for h in Path(hwmon).glob('hwmon*'):
        try:
            if (h/'name').read_text().strip() != 'coretemp':
                continue
            for label in h.glob('temp*_label'):
                if label.read_text().strip()=='Package id 0':
                    value=label.with_name(label.name.replace('_label','_input'))
                    return int(value.read_text().strip())/1000
        except (OSError,ValueError):
            continue
    raise RuntimeError('Sensor Package id 0 indisponível')

def gpu_fan_percentages_from_existing_adapters(gpu_list):
    """Take existing LumiCore GPU fan telemetry, not fan duty guessed from load.

    Each GPU dict must have `has_fan` bool; if has_fan true, `fan_percent`
    is a measured or commanded GPU fan PWM percentage in [0,100].
    If telemetry is missing for an expected fan, return None (CASE MAX).
    """
    if gpu_list is None:
        return None
    fans=[]
    for gpu in gpu_list:
        if 'has_fan' not in gpu:
            return None
        if gpu['has_fan']:
            percent=gpu.get('fan_percent')
            if type(percent) not in (float,int) or not 0<=percent<=100:
                return None
            fans.append(percent)
    return fans
