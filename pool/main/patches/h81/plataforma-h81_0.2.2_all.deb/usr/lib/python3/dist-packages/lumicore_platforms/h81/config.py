"""Separate settings for each platform, persisted atomically, with strict validation."""
from __future__ import annotations
import copy
import json
import os
from pathlib import Path
import tempfile

DEFAULT_H81 = {
    'enabled': False,  # disabled until supervised electrical/fault testing completed
    'cpu': {
        'up_c': [40, 45, 50, 55],
        'down_c': [37, 42, 47, 52],
        'speeds_pct': [30, 50, 70, 85, 100],
        'rpm_min': 700,
        'temp_emergency_c': 65,
    },
    'case': {
        'start_at_pct': 50,
        'full_at_pct': 75,
        'start_speed_pct': 30,
        'off_below_pct': 47,
        'off_speed_pct': 0,
    },
    'poll_seconds': 1,
}

class InvalidSettings(ValueError):
    pass


def validate_h81(settings):
    """Return normalized H81 settings. Never accept arbitrary system paths/commands."""
    if not isinstance(settings, dict):
        raise InvalidSettings('Configuração deve ser um objeto JSON')
    required = {'enabled','cpu','case','poll_seconds'}
    if set(settings) != required:
        raise InvalidSettings('Campos H81 desconhecidos ou em falta')
    if type(settings['enabled']) is not bool:
        raise InvalidSettings('enabled deve ser booleano')
    c, k = settings['cpu'], settings['case']
    if not isinstance(c, dict) or set(c) != {'up_c','down_c','speeds_pct','rpm_min','temp_emergency_c'}:
        raise InvalidSettings('Configuração CPU inválida')
    if not isinstance(k, dict) or set(k) != {'start_at_pct','full_at_pct','start_speed_pct','off_below_pct','off_speed_pct'}:
        raise InvalidSettings('Configuração CASE inválida')
    ups, downs, speeds = c['up_c'], c['down_c'], c['speeds_pct']
    if not all(isinstance(a,list) and len(a)==length for a,length in ((ups,4),(downs,4),(speeds,5))):
        raise InvalidSettings('Curva CPU requer 4 limiares e 5 velocidades')
    def num(x, lo, hi):
        if type(x) not in (int,float) or not lo <= x <= hi:
            raise InvalidSettings(f'Valor fora dos limites: {x!r}')
        return x
    ups=[num(v,25,85) for v in ups]
    downs=[num(v,20,85) for v in downs]
    speeds=[num(v,30,100) for v in speeds]
    if any(a>=b for a,b in zip(ups,ups[1:])) or any(a>=b for a,b in zip(downs,downs[1:])):
        raise InvalidSettings('Limiares têm de subir progressivamente')
    if any(a>=b for a,b in zip(speeds,speeds[1:])) or speeds[-1]!=100:
        raise InvalidSettings('Velocidades CPU devem subir até 100%')
    if any(not (downs[i]<ups[i] and (i==0 or downs[i]>=ups[i-1])) for i in range(4)):
        raise InvalidSettings('Histerese CPU inválida')
    emergency=num(c['temp_emergency_c'],55,85)
    if emergency < ups[-1]:
        raise InvalidSettings('Emergência deve ser >= último limiar CPU')
    num(c['rpm_min'],300,3000)
    start=num(k['start_at_pct'],25,80)
    full=num(k['full_at_pct'],start+1,100)
    off=num(k['off_below_pct'],0,start-1)
    num(k['start_speed_pct'],15,70)
    if k['off_speed_pct'] != 0:
        raise InvalidSettings('CASE desligada deve ser 0%')
    poll=num(settings['poll_seconds'],0.5,3)
    return copy.deepcopy(settings)


class FanConfigStore:
    def __init__(self, path: Path):
        self.path=Path(path)

    def get_platform(self, platform: str):
        # Only an H81 profile is shipped; other platforms are not configured implicitly.
        if platform != 'h81':
            return None
        base=copy.deepcopy(DEFAULT_H81)
        if not self.path.exists():
            return base
        doc=json.loads(self.path.read_text())
        if doc.get('schema') != 1 or not isinstance(doc.get('platforms'),dict):
            raise InvalidSettings('Versão/formato de configuração desconhecido')
        stored=doc['platforms'].get('h81')
        return validate_h81(stored) if stored is not None else base

    def save_platform(self, platform: str, settings: dict):
        if platform != 'h81':
            raise InvalidSettings('Perfil não suportado neste pacote')
        cfg=validate_h81(settings)
        doc={'schema': 1, 'platforms': {}}
        if self.path.exists():
            doc=json.loads(self.path.read_text())
            if doc.get('schema')!=1 or not isinstance(doc.get('platforms'),dict):
                raise InvalidSettings('Versão/formato de configuração desconhecido')
        doc['platforms']['h81']=cfg
        self.path.parent.mkdir(mode=0o750,parents=True,exist_ok=True)
        fd,temp=tempfile.mkstemp(prefix='.fans-',dir=str(self.path.parent))
        try:
            with os.fdopen(fd,'w') as f:
                json.dump(doc,f,ensure_ascii=False,indent=2)
                f.write('\n')
                f.flush()
                os.fsync(f.fileno())
            os.chmod(temp,0o640)
            os.replace(temp,self.path)
        finally:
            if os.path.exists(temp):
                os.unlink(temp)
        return cfg
