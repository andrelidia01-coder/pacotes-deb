"""Stateful H81 curve logic; entirely independent of kernel, GPU drivers and web app."""
from __future__ import annotations
from dataclasses import dataclass
from math import isfinite

@dataclass(frozen=True)
class Decision:
    cpu_pct: int
    case_pct: int
    demand_pct: float
    reason: str

class H81Curves:
    def __init__(self, config):
        self.config=config
        self.cpu_step=0
        self.case_active=False

    def reset(self):
        self.cpu_step=0
        self.case_active=False

    def calculate(self, cpu_c, gpu_fans):
        c=self.config['cpu']; k=self.config['case']
        try:
            temp=float(cpu_c)
            if not isfinite(temp) or not (0<temp<105):
                raise ValueError('CPU temperature invalid')
            if temp>=c['temp_emergency_c']:
                self.cpu_step=4
                self.case_active=True
                return Decision(100,100,100,'cpu_emergency')
            while self.cpu_step<4 and temp>=c['up_c'][self.cpu_step]:
                self.cpu_step+=1
            while self.cpu_step>0 and temp<c['down_c'][self.cpu_step-1]:
                self.cpu_step-=1
            cpu=int(c['speeds_pct'][self.cpu_step])
            if gpu_fans is None:
                self.case_active=True
                return Decision(cpu,100,100,'gpu_telemetry_missing')
            pct=[]
            for x in gpu_fans:
                n=float(x)
                if not isfinite(n) or n<0 or n>100:
                    raise ValueError('Invalid GPU fan percentage')
                pct.append(n)
            demand=max([float(cpu)]+pct)
            start=k['start_at_pct']; off=k['off_below_pct']; full=k['full_at_pct']
            if demand>=start: self.case_active=True
            elif demand<=off: self.case_active=False
            if not self.case_active: case=0
            elif demand<start: case=k['start_speed_pct']
            elif demand>=full: case=100
            else:
                case=round(k['start_speed_pct']+(demand-start)*(100-k['start_speed_pct'])/(full-start))
            return Decision(cpu,int(case),demand,'normal')
        except (TypeError,ValueError,OverflowError):
            self.cpu_step=4
            self.case_active=True
            return Decision(100,100,100,'invalid_sensor')
