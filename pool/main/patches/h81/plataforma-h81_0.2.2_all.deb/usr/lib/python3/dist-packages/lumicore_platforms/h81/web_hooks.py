"""Example adapters for existing Flask-like web framework; no standalone server.

This is a template. Wire it into hipervisor_web.app after inspecting source,
using the EXISTING authorization decorator and CSRF mechanism.
"""

def register_flask_routes(app,api,require_auth,require_csrf):
    """Only call if `app` is a Flask application and auth callbacks are supplied.

    require_auth(request)->bool; require_csrf(request)->bool. These MUST use the
    same controls already protecting administrative LumiCore endpoints.
    """
    from flask import request,jsonify

    @app.route('/api/fans/status', methods=['GET'])
    @app.route('/api/fans/settings', methods=['GET','PUT'])
    @app.route('/api/fans/preview', methods=['POST'])
    def lumicore_fans_api():
        method=request.method
        status,data=api.dispatch(
            method,request.path,request.get_json(silent=True),
            authenticated=bool(require_auth(request)),
            csrf_ok=bool(require_csrf(request)) if method=='PUT' else False,
        )
        return jsonify(data),status
