"""Plataform-aware fan manager integrated in the LumiCore sampling thread.

No direct serial access, no background competing PWM writer; only hwmon.
H81 profile is opt-in. Legacy it87 case-fan control remains untouched elsewhere.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from math import isfinite
from pathlib import Path
import logging
import time
import copy

from .curves import H81Curves
from .hwmon import HwmonFans
from .platform import detect_platform
from .config import FanConfigStore, DEFAULT_H81

LOG = logging.getLogger('lumicore.fans')


@dataclass
class FanState:
    platform: str | None = None
    present: bool = False
    enabled: bool = False
    active: bool = False
    mode: str = 'absent'
    controller: str | None = None
    cpu_temp_c: float | None = None
    gpu_fans_pct: list[float] | None = None
    demand_pct: float | None = None
    cpu_target_pct: int = 100
    case_target_pct: int = 100
    cpu_rpm: int | None = None
    case_rpm: int | None = None
    reason: str = 'controller_absent'
    fail_safe: bool = False
    measured_at: float | None = None

    def as_json(self):
        return asdict(self)


class FanManager:
    """Detect H81 device by DMI AND hwmon name. Does nothing on other PCs."""

    def __init__(self, path='/etc/lumicore/platforms/h81/fans.json',
                 dmi='/sys/class/dmi/id', hwmon='/sys/class/hwmon'):
        self.store = FanConfigStore(Path(path))
        self.dmi = dmi
        self.hwmon = hwmon
        try:
            self.cfg = self.store.get_platform('h81')
        except (OSError, ValueError) as exc:
            LOG.error('Perfil H81 inválido: controlo desativado (%s)', exc)
            self.cfg = copy.deepcopy(DEFAULT_H81)
        self.curves = H81Curves(self.cfg)
        self.state = FanState()
        self.low_rpm_checks = 0
        self.case_stall_checks = 0
        self.fault_latched = False
        self.last_logged_reason = None

    def detected(self):
        return detect_platform(self.dmi, self.hwmon) == 'h81'

    def status(self):
        return self.state.as_json()

    def settings(self):
        return {'platform': 'h81' if self.detected() else None,
                'available': self.detected(),
                'settings': self.store.get_platform('h81') if self.detected() else None}

    def save(self, settings):
        if not self.detected():
            raise RuntimeError('Controlador H81 não encontrado nesta plataforma')
        saved = self.store.save_platform('h81', settings)
        self.cfg = saved
        self.curves = H81Curves(saved)
        self.low_rpm_checks = 0
        self.case_stall_checks = 0
        # Conservatively force full immediately when turning off control.
        if not saved['enabled']:
            dev = HwmonFans.discover(self.hwmon)
            if dev is not None:
                dev.max()
        return saved

    def _log_transition(self, status):
        if status.reason != self.last_logged_reason:
            LOG.info('H81 fans: %s (CPU %s%%, CASE %s%%, rpm %s/%s)',
                     status.reason, status.cpu_target_pct, status.case_target_pct,
                     status.cpu_rpm, status.case_rpm)
            self.last_logged_reason = status.reason

    @staticmethod
    def _extract_gpu_percentages(gpu_slots):
        """Every installed GPU needs valid fan duty telemetry, else CASE MAX.

        `fan_pct` comes from the existing GPU adapter status JSON, never
        from utilization or RPM. An empty list represents no installed GPUs.
        """
        if gpu_slots is None or not isinstance(gpu_slots, (list, tuple)):
            return None
        percentages = []
        for gpu in gpu_slots:
            if not isinstance(gpu, dict):
                return None
            value = gpu.get('fan_pct')
            if type(value) not in (int, float) or not isfinite(value) or not 0 <= value <= 100:
                return None
            percentages.append(float(value))
        return percentages

    def update(self, cpu_temp, gpu_slots):
        now = time.time()
        if not self.detected():
            self.state = FanState(measured_at=now)
            return self.status()
        dev = HwmonFans.discover(self.hwmon)
        if dev is None:
            self.state = FanState(measured_at=now)
            return self.status()

        s = FanState(platform='h81', present=True, enabled=self.cfg['enabled'],
                     mode='max', controller=str(dev.path), measured_at=now,
                     reason='disabled')
        try:
            values = dev.read()
            s.cpu_rpm = values['cpu_rpm']
            s.case_rpm = values['case_rpm']
            s.cpu_temp_c = float(cpu_temp) if cpu_temp is not None else None
            s.gpu_fans_pct = self._extract_gpu_percentages(gpu_slots)
            if (not isinstance(s.cpu_rpm, int) or not 0 <= s.cpu_rpm <= 20000
                    or not isinstance(s.case_rpm, int) or not 0 <= s.case_rpm <= 20000):
                raise RuntimeError('Tachómetro inválido')
            if not self.cfg['enabled']:
                dev.max()
                self.curves.reset()
                self.low_rpm_checks = 0
                self.case_stall_checks = 0
                self.fault_latched = False
                self.state = s
                self._log_transition(s)
                return self.status()

            if s.cpu_rpm < int(self.cfg['cpu']['rpm_min']):
                self.low_rpm_checks += 1
            else:
                self.low_rpm_checks = 0
            if self.low_rpm_checks >= 3:
                self.fault_latched = True
            # CASE may intentionally be at 0%. Only detect stall when a
            # nonzero speed has already been commanded in earlier cycles.
            if self.state.case_target_pct >= 30 and self.state.active and s.case_rpm < 200:
                self.case_stall_checks += 1
            else:
                self.case_stall_checks = 0
            if self.case_stall_checks >= 3:
                self.fault_latched = True
            if self.fault_latched:
                s.reason = ('cpu_fan_stall_latched' if self.low_rpm_checks >= 3
                            else 'case_fan_stall_latched')
                s.fail_safe = True
                raise RuntimeError(s.reason)

            decision = self.curves.calculate(cpu_temp, s.gpu_fans_pct)
            s.demand_pct = decision.demand_pct
            s.cpu_target_pct = decision.cpu_pct
            s.case_target_pct = decision.case_pct
            s.reason = decision.reason
            if decision.reason in ('invalid_sensor', 'cpu_emergency'):
                s.fail_safe = True
                dev.max()
                s.cpu_target_pct = s.case_target_pct = 100
                s.mode = 'failsafe'
            else:
                dev.apply(s.cpu_target_pct, s.case_target_pct)
                s.mode = 'auto'
                s.active = True
            self.state = s
        except (OSError, ValueError, RuntimeError) as exc:
            LOG.warning('H81 fan safe mode: %s', exc)
            try:
                dev.max()
            except (OSError, ValueError) as restore_exc:
                LOG.error('Não foi possível repor MAX nas ventoinhas H81: %s', restore_exc)
            s.mode = 'failsafe'
            s.reason = (('cpu_fan_stall_latched' if self.low_rpm_checks >= 3
                         else 'case_fan_stall_latched') if self.fault_latched
                        else 'hwmon_or_sensor_error')
            s.fail_safe = True
            s.cpu_target_pct = s.case_target_pct = 100
            self.state = s
        self._log_transition(self.state)
        return self.status()

    def stop(self):
        if self.detected():
            dev = HwmonFans.discover(self.hwmon)
            if dev is not None:
                dev.max()
