"""Platform registry: H81 is optional, nothing special required on other machines."""
from pathlib import Path
from .hwmon import HwmonFans

def detect_board(dmi='/sys/class/dmi/id'):
    dmi=Path(dmi)
    try:
        return {'vendor':(dmi/'board_vendor').read_text().strip(),
                'name':(dmi/'board_name').read_text().strip()}
    except OSError:
        return {'vendor':None,'name':None}

def detect_platform(dmi='/sys/class/dmi/id',hwmon='/sys/class/hwmon'):
    board=detect_board(dmi)
    if board=={'vendor':'INTEL','name':'H81'} and HwmonFans.discover(hwmon):
        return 'h81'
    return None
