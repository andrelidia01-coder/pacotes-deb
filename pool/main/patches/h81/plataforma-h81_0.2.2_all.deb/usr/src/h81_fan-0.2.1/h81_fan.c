// SPDX-License-Identifier: GPL-2.0
/*
 * h81_fan: hwmon interface for a verified USB H81 Fan Controller.
 *
 * Kernel <-> USB serial bridge uses an exclusive misc char device and IOCTLs.
 * No experimental TTY line discipline ID; CH340 stays with the ch341 driver.
 * The hwmon device exists only while a userspace bridge is attached.
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/hwmon.h>
#include <linux/miscdevice.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/dmi.h>
#include <linux/mutex.h>
#include <linux/jiffies.h>
#include <linux/errno.h>
#include <linux/string.h>
#include "h81_fan_ioctl.h"

#define H81_CPU_MIN_PWM 77  /* ceil(30% * 255) */
#define H81_CPU_MIN_RPM 700
#define H81_RPM_TIMEOUT (5 * HZ)

struct h81_state {
    struct mutex lock;
    struct device *hwmon;
    bool attached;
    bool enabled[2];
    unsigned int requested[2];
    unsigned int rpm[2];
    bool cpu_rpm_good;
    bool cpu_fault;
    unsigned int low_cpu_rpm_samples;
    unsigned long last_telemetry;
};
static struct h81_state state;
static struct miscdevice h81_misc;

static bool h81_fresh(void)
{
    return state.last_telemetry &&
        time_before(jiffies, state.last_telemetry + H81_RPM_TIMEOUT);
}

static umode_t h81_is_visible(const void *data, enum hwmon_sensor_types type,
                             u32 attr, int channel)
{
    if (channel < 0 || channel > 1)
        return 0;
    switch (type) {
    case hwmon_fan:
        if (attr == hwmon_fan_input || attr == hwmon_fan_label)
            return 0444;
        break;
    case hwmon_pwm:
        if (attr == hwmon_pwm_input || attr == hwmon_pwm_enable)
            return 0644;
        break;
    default:
        break;
    }
    return 0;
}

static int h81_read(struct device *dev, enum hwmon_sensor_types type,
                    u32 attr, int channel, long *val)
{
    int ret = 0;

    if (channel < 0 || channel > 1)
        return -EINVAL;
    mutex_lock(&state.lock);
    if (!state.attached) {
        ret = -ENODEV;
    } else if (type == hwmon_fan && attr == hwmon_fan_input) {
        if (!h81_fresh())
            ret = -ENODATA;
        else
            *val = state.rpm[channel];
    } else if (type == hwmon_pwm && attr == hwmon_pwm_input) {
        *val = state.requested[channel];
    } else if (type == hwmon_pwm && attr == hwmon_pwm_enable) {
        *val = state.enabled[channel] ? 1 : 0;
    } else {
        ret = -EOPNOTSUPP;
    }
    mutex_unlock(&state.lock);
    return ret;
}

static int h81_read_string(struct device *dev,
                           enum hwmon_sensor_types type, u32 attr,
                           int channel, const char **str)
{
    static const char * const labels[] = { "CPU", "CASE" };

    if (type != hwmon_fan || attr != hwmon_fan_label ||
        channel < 0 || channel > 1)
        return -EOPNOTSUPP;
    *str = labels[channel];
    return 0;
}

static int h81_write(struct device *dev, enum hwmon_sensor_types type,
                     u32 attr, int channel, long value)
{
    int ret = 0;

    if (type != hwmon_pwm || channel < 0 || channel > 1)
        return -EINVAL;
    mutex_lock(&state.lock);
    if (!state.attached) {
        ret = -ENODEV;
    } else if (attr == hwmon_pwm_input) {
        if (value < 0 || value > 255)
            ret = -EINVAL;
        else if (channel == 0 && value < H81_CPU_MIN_PWM)
            ret = -ERANGE;
        else if (channel == 0 && value < 255 &&
                 (!h81_fresh() || !state.cpu_rpm_good || state.cpu_fault))
            ret = -EAGAIN;
        else
            state.requested[channel] = value;
    } else if (attr == hwmon_pwm_enable) {
        if (value != 0 && value != 1)
            ret = -EINVAL;
        else if (channel == 0 && value == 1 &&
                 state.requested[0] < 255 &&
                 (!h81_fresh() || !state.cpu_rpm_good || state.cpu_fault))
            ret = -EAGAIN;
        else
            state.enabled[channel] = value == 1;
    } else {
        ret = -EOPNOTSUPP;
    }
    mutex_unlock(&state.lock);
    return ret;
}

static const struct hwmon_ops h81_ops = {
    .is_visible = h81_is_visible,
    .read = h81_read,
    .read_string = h81_read_string,
    .write = h81_write,
};

static const struct hwmon_channel_info * const h81_info[] = {
    HWMON_CHANNEL_INFO(fan,
        HWMON_F_INPUT | HWMON_F_LABEL,
        HWMON_F_INPUT | HWMON_F_LABEL),
    HWMON_CHANNEL_INFO(pwm,
        HWMON_PWM_INPUT | HWMON_PWM_ENABLE,
        HWMON_PWM_INPUT | HWMON_PWM_ENABLE),
    NULL,
};

static const struct hwmon_chip_info h81_chip = {
    .ops = &h81_ops,
    .info = h81_info,
};

static int h81_open(struct inode *inode, struct file *file)
{
    int ret = 0;

    mutex_lock(&state.lock);
    if (state.attached) {
        ret = -EBUSY;
    } else {
        state.attached = true;
        state.requested[0] = 255;
        state.requested[1] = 255;
        state.enabled[0] = false;
        state.enabled[1] = false;
        state.rpm[0] = 0;
        state.rpm[1] = 0;
        state.cpu_rpm_good = false;
        state.cpu_fault = false;
        state.low_cpu_rpm_samples = 0;
        state.last_telemetry = 0;
    }
    mutex_unlock(&state.lock);
    return ret;
}

static int h81_release(struct inode *inode, struct file *file)
{
    struct device *dev;

    mutex_lock(&state.lock);
    /* Remove outside lock: hwmon unregister waits for sysfs callbacks. */
    dev = state.hwmon;
    state.hwmon = NULL;
    state.attached = false;
    state.enabled[0] = false;
    state.enabled[1] = false;
    mutex_unlock(&state.lock);
    if (dev)
        hwmon_device_unregister(dev);
    return 0;
}

static long h81_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    struct h81_fan_snapshot snap;
    struct h81_fan_telemetry tel;
    struct device *dev;
    unsigned long now;
    int ret = 0;

    switch (cmd) {
    case H81_FAN_IOC_ATTACH:
        mutex_lock(&state.lock);
        if (!state.attached)
            ret = -ENODEV;
        else if (state.hwmon)
            ret = -EALREADY;
        else {
            /* Called only after userspace verifies IDENTIFY. */
            dev = hwmon_device_register_with_info(h81_misc.this_device,
                    "h81_fan", &state, &h81_chip, NULL);
            if (IS_ERR(dev))
                ret = PTR_ERR(dev);
            else
                state.hwmon = dev;
        }
        mutex_unlock(&state.lock);
        return ret;

    case H81_FAN_IOC_GET:
        mutex_lock(&state.lock);
        if (!state.attached || !state.hwmon) {
            ret = -ENODEV;
        } else {
            now = jiffies;
            snap.pwm_cpu = 255;
            snap.pwm_case = state.enabled[1] ? state.requested[1] : 255;
            if (state.enabled[0] && !state.cpu_fault &&
                state.cpu_rpm_good && state.last_telemetry &&
                time_before(now, state.last_telemetry + H81_RPM_TIMEOUT))
                snap.pwm_cpu = state.requested[0];
            snap.rpm_cpu = state.rpm[0];
            snap.rpm_case = state.rpm[1];
            snap.telemetry_fresh = h81_fresh() ? 1 : 0;
            /* A stale bridge must not command reduced CASE either. */
            if (!snap.telemetry_fresh)
                snap.pwm_case = 255;
            snap.fault = state.cpu_fault ? 1 : 0;
        }
        mutex_unlock(&state.lock);
        if (ret)
            return ret;
        return copy_to_user((void __user *)arg, &snap, sizeof(snap))
            ? -EFAULT : 0;

    case H81_FAN_IOC_TELEMETRY:
        if (copy_from_user(&tel, (void __user *)arg, sizeof(tel)))
            return -EFAULT;
        if (tel.rpm_cpu > 20000 || tel.rpm_case > 20000)
            return -ERANGE;
        mutex_lock(&state.lock);
        if (!state.attached || !state.hwmon) {
            ret = -ENODEV;
        } else {
            state.rpm[0] = tel.rpm_cpu;
            state.rpm[1] = tel.rpm_case;
            state.last_telemetry = jiffies;
            if (tel.rpm_cpu >= H81_CPU_MIN_RPM) {
                state.cpu_rpm_good = true;
                state.low_cpu_rpm_samples = 0;
                /* Unlatch only when requested output can be 100%. */
                if (!state.enabled[0] || state.requested[0] == 255)
                    state.cpu_fault = false;
            } else {
                if (++state.low_cpu_rpm_samples >= 3) {
                    state.cpu_rpm_good = false;
                    state.cpu_fault = true;
                    state.enabled[0] = false;
                    state.requested[0] = 255;
                    state.enabled[1] = false;
                }
            }
        }
        mutex_unlock(&state.lock);
        return ret;

    default:
        return -ENOTTY;
    }
}

static const struct file_operations h81_fops = {
    .owner = THIS_MODULE,
    .open = h81_open,
    .release = h81_release,
    .unlocked_ioctl = h81_ioctl,
#ifdef CONFIG_COMPAT
    .compat_ioctl = compat_ptr_ioctl,
#endif
    .llseek = noop_llseek,
};

static struct miscdevice h81_misc = {
    .minor = MISC_DYNAMIC_MINOR,
    .name = "h81fanctl",
    .fops = &h81_fops,
    .mode = 0600,
};

static int __init h81_init(void)
{
    int ret;
    if (!dmi_match(DMI_BOARD_VENDOR, "INTEL") ||
        !dmi_match(DMI_BOARD_NAME, "H81"))
        return -ENODEV;
    mutex_init(&state.lock);
    ret = misc_register(&h81_misc);
    if (!ret)
        pr_info("h81_fan: controller interface ready; hwmon awaits ESP32 attach\n");
    return ret;
}

static void __exit h81_exit(void)
{
    misc_deregister(&h81_misc);
}
module_init(h81_init);
module_exit(h81_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("LumiCore H81 prototype");
MODULE_DESCRIPTION("H81 ESP32 dual-fan native hwmon interface");
MODULE_VERSION("0.2.1");
