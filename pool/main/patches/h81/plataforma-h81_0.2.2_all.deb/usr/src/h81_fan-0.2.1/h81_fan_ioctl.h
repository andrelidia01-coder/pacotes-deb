/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef H81_FAN_IOCTL_H
#define H81_FAN_IOCTL_H
#include <linux/ioctl.h>
#include <linux/types.h>

struct h81_fan_snapshot {
    __u32 pwm_cpu;
    __u32 pwm_case;
    __u32 rpm_cpu;
    __u32 rpm_case;
    __u32 telemetry_fresh;
    __u32 fault;
};
struct h81_fan_telemetry {
    __u32 rpm_cpu;
    __u32 rpm_case;
};
#define H81_FAN_IOC_ATTACH _IO('H', 1)
#define H81_FAN_IOC_GET _IOR('H', 2, struct h81_fan_snapshot)
#define H81_FAN_IOC_TELEMETRY _IOW('H', 3, struct h81_fan_telemetry)
#endif
