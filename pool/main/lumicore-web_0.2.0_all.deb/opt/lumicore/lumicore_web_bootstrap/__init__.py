"""LumiCore management first-run support."""
