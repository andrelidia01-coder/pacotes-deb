"""Web admin: existing full manager when approved, or read-only setup page."""
import os, urllib.request, json
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from hipervisor.core.config import load
DB='/var/lib/lumicore/lhdb.dat'
FLAG=Path('/etc/lumicore/hardware-approved')
HTML="""<!doctype html><html lang="pt"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>LumiCore 0.2 · Configuração</title>
<style>body{background:#081521;color:#dcefff;font:16px system-ui,sans-serif;max-width:850px;margin:8vh auto;padding:24px;line-height:1.6}h1{color:#62deff}.panel{background:#10293b;border:1px solid #256079;border-radius:12px;padding:24px}code{color:#9ce1e6}small{color:#afcad9}</style></head><body>
<h1>LumiCore 0.2</h1><div class="panel"><h2>Configuração inicial</h2>
<p>O núcleo e a gestão web estão instalados. Ainda não existe um perfil de hardware validado e ativado.</p>
<p>Consulte <code>sudo lumicore-lhdb show</code>. Para importar uma configuração validada, utilize <code>sudo lumicore-lhdb import-json &lt;ficheiro.json&gt;</code>.</p>
<p>Depois de validar adaptadores e perfis GPU, execute <code>sudo lumicore-setup activate</code>.</p>
<p><small>Nenhuma GPU, CPU ou ventoinha é alterada neste modo. A interface completa será disponibilizada após ativação.</small></p></div></body></html>"""

def ready():
    if not FLAG.is_file():return False
    try:
        cfg=load(DB)
        return Path(cfg['gpu']['adapter']).is_file()
    except Exception:return False

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def respond(self,data,mime='application/json',status=200):
        self.send_response(status);self.send_header('Content-Type',mime+'; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def do_GET(self):
        if self.path in ('/','/admin'):
            self.respond(HTML.encode(),'text/html')
        elif self.path=='/health':
            self.respond(json.dumps({'ok':True,'version':'0.2.0','state':'SETUP'}).encode())
        elif self.path=='/api/system':
            try:
                with urllib.request.urlopen('http://127.0.0.1:8765/v1/system',timeout=2) as r:
                    self.respond(r.read())
            except Exception:self.respond(b'{"error":"core_unavailable"}',status=502)
        else:self.respond(b'{"error":"setup_mode"}',status=409)

def main():
    if ready():
        os.execv('/usr/bin/python3',['/usr/bin/python3','-m','hipervisor_web.app',
                                     '--config',DB])
    ThreadingHTTPServer(('0.0.0.0',8766),Handler).serve_forever(poll_interval=.5)

if __name__=='__main__':main()
