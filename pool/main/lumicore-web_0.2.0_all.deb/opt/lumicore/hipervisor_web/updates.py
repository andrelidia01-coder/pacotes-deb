from __future__ import annotations
import fcntl, json, os, re, subprocess, tempfile
from pathlib import Path

CONFIG=Path('/etc/lumicore/updates.json')
DROPIN=Path('/etc/systemd/system/lumicore-update.timer.d/schedule.conf')
TIMER='lumicore-update.timer'

def run(args):
    return subprocess.run(args,check=True,capture_output=True,text=True,timeout=20)

def atomic(path, body):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(dir=path.parent)
    try:
        with os.fdopen(fd,'w') as f: f.write(body); f.flush(); os.fsync(f.fileno())
        os.chmod(name,0o644); os.replace(name,path)
    finally:
        if os.path.exists(name): os.unlink(name)

def current():
    return json.loads(CONFIG.read_text()) if CONFIG.exists() else {'enabled':True,'time':'00:00','timezone':'UTC'}

def validate(p):
    if not isinstance(p,dict) or type(p.get('enabled')) is not bool: raise ValueError('Activação inválida')
    t=p.get('time')
    if not isinstance(t,str) or not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',t): raise ValueError('Horário inválido; usar HH:MM UTC')
    return {'enabled':p['enabled'],'time':t,'timezone':'UTC'}

def save(p):
    cfg=validate(p)
    CONFIG.parent.mkdir(parents=True,exist_ok=True)
    with (CONFIG.parent/'updates.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        old=current(); old_drop=DROPIN.read_text() if DROPIN.exists() else None
        try:
            atomic(DROPIN,f"[Timer]\nOnCalendar=\nOnCalendar=*-*-* {cfg['time']}:00 UTC\n")
            run(['systemctl','daemon-reload'])
            if cfg['enabled']:
                run(['systemctl','enable',TIMER]); run(['systemctl','restart',TIMER])
            else: run(['systemctl','disable','--now',TIMER])
            atomic(CONFIG,json.dumps(cfg,ensure_ascii=False)+'\n')
        except Exception:
            if old_drop is None: DROPIN.unlink(missing_ok=True)
            else: atomic(DROPIN,old_drop)
            run(['systemctl','daemon-reload'])
            if old['enabled']:
                run(['systemctl','enable',TIMER]); run(['systemctl','restart',TIMER])
            else: run(['systemctl','disable','--now',TIMER])
            raise
    return cfg

def status():
    cfg=current()
    for unit,key,properties in [(TIMER,'timer','ActiveState,UnitFileState,NextElapseUSecRealtime'),('lumicore-update.service','service','ActiveState,Result,ExecMainStatus,ExecMainExitTimestamp')]:
        r=subprocess.run(['systemctl','show',unit,'--property='+properties],capture_output=True,text=True,timeout=5)
        cfg[key]=dict(line.split('=',1) for line in r.stdout.splitlines() if '=' in line)
    r=subprocess.run(['journalctl','-u','lumicore-update.service','-n','20','--no-pager','-o','cat'],capture_output=True,text=True,timeout=5)
    cfg['log']=r.stdout[-8000:]
    return cfg
