# LumiOS CYD — teste USB em duas etapas (pacote 0.2.3)

Este pacote testa só o CYD no mini-PC que já tem LumiCore e ia.local. Ainda não
é a etapa web do instalador geral. Não altera Docker, Open WebUI ou o serviço
das ventoinhas. O firmware normal é Build031v11, derivado da source Build031v7.

## Instalar e compilar

```bash
sudo apt install /home/user/lumios-cyd_0.2.3_all.deb
sudo journalctl -fu lumios-cyd-build.service
```

A primeira instalação obtém PlatformIO/toolchain e compila dois firmwares
genéricos: `cydsetup` (só USB/Wi-Fi/NVS) e `cyd2usb` (LumiOS normal).
Nenhum tem o SSID, a palavra-passe ou a chave de autenticação incorporados.
Pode repetir o download/build com `sudo lumios-cyd compilar`.

## Executar o teste

Identifique a porta do CYD com ecrã:

```bash
ls -l /dev/serial/by-id/
sudo lumios-cyd testar /dev/serial/by-id/PORTA_DO_CYD
```

O teste pede confirmação do dispositivo e da interface Ethernet do mini-PC.
Depois, sem tocar no ecrã:

1. Faz um backup local da NVS antes de gravar.
2. Grava o firmware mínimo e confirma o protocolo USB.
3. O CYD pesquisa redes Wi-Fi 2.4 GHz; a lista aparece no terminal do mini-PC.
4. Seleciona-se a rede e introduz-se a palavra-passe (oculta).
5. O CYD testa a ligação e comunica sucesso ou erro; é possível repetir.
6. Após sucesso, recebe a chave LumiCore e o MAC para WoL por USB.
7. Grava em NVS e confirma por leitura os valores, sem devolver a chave.
8. O mini-PC anuncia o serviço LumiCore e ativa WoL na interface Ethernet.
9. Grava LumiOS normal sem escrever ou apagar a região NVS.

No fim, verificar no ecrã que o LumiOS normal ligou ao Wi-Fi/LumiCore e testar
WoL fisicamente. O resultado de conexão do firmware mínimo não substitui esses
testes finais. A compilação não é prova de sucesso no hardware.

## Se houver uma falha

- Compilação: ver o journal e executar `sudo lumios-cyd compilar`.
- Palavra-passe errada: o teste permite nova seleção/tentativa.
- Falha antes de guardar configuração: repetir `testar`.
- Falha na gravação normal, após configuração confirmada: executar
  `sudo lumios-cyd finalizar /dev/serial/by-id/PORTA_DO_CYD`.
- Interrupção enquanto está no mínimo: o CYD permanece nessa etapa até se
  repetir o teste ou gravar normal. Não é enviado qualquer `erase_flash`.
- Recuperação da NVS anterior: backups privados em `/var/lib/lumios-cyd/backups/`;
  não restaurar sem identificar o dispositivo correto e o efeito sobre os dados.

## Preservação e isolamento

As duas imagens têm a mesma tabela. NVS ocupa `0x9000` até `0xE000`.
As escritas são só bootloader `0x1000`, tabela `0x8000`, OTA metadata `0xE000`
e firmware `0x10000`; os limites de tamanho são verificados antes de gravar.
Não existe formatação completa. Em atualizações normais a source genérica não
substitui os campos existentes de NVS por defaults vazios.

O programa recusa uma porta reservada a um h81-fan-bridge carregado. Mesmo assim,
é necessário confirmar qual USB é o CYD: CH340 não identifica por si só o ecrã.
Não desligar nem gravar o H81 Fan Controller. Se dois dispositivos forem
indistinguíveis, usar os caminhos USB físicos/by-path e confirmar o CYD.

O Wi-Fi fica no CYD. O host guarda só interface Ethernet, MAC, chip e data.
A chave partilhada fica em `/etc/lumicore/control-key` e em NVS; é reutilizada
se existir. Os backups de NVS podem conter dados pessoais e ficam root/600.
A comunicação USB depende do acesso físico. Não se transfere nenhuma chave por
mDNS nem se imprime a palavra-passe em logs. O pacote e os binários genéricos
podem ser distribuídos; os backups e a chave local não.

O CYD encontra `_lumicore._tcp` por MAC, mesmo com novo IP DHCP. WoL usa broadcast
calculado pela rede Wi-Fi atual e exige a mesma LAN/VLAN. `ia.local` pertence ao
mini-PC; o CYD não disputa esse nome. O launcher antigo do CYD fica num nome
separado `lumios-cyd.local` e encaminha para ia.local, mas esse launcher ainda não
é o setup web solicitado para a instalação geral.

## Estado da validação

Scripts Python/shell e pacote verificados. Testes simulados do protocolo USB,
repetição após falha Wi-Fi, rejeição de dispositivo errado e intervalos de flash.
O firmware ESP32 é compilado no mini-PC durante a instalação; não foi compilado
com o SDK ESP32 nem executado num CYD real neste ambiente. Esta é uma versão
para o primeiro teste físico. Telemetria antiga Lua e melhorias de UI ficam para
uma atualização seguinte.

## Correções 0.2.1

- Palavra-passe errada: repetir na mesma rede sem voltar a pesquisar.
- wifi_scan_failed: repetir a pesquisa sem sair do instalador.
- Firmware mínimo: desativar reconexão e terminar associação falhada antes do scan.
- Retoma: identificar o firmware mínimo já ativo e evitar novo flash inicial.
- Porta: bloquear o fan bridge ativo, não uma instância inativa criada pela descoberta.
- IDENTIFY por USB: recusar também um controlador de fans inativo que se identifique.
- Preservar NVS e não alterar o USB durante instalação/compilação do pacote.

O primeiro teste físico 0.2.0 confirmou a pesquisa Wi-Fi e a gravação normal;
a tentativa de password errada expôs a falha do scan que motivou esta correção.
A versão corrigida foi testada por simulação; a compilação e o teste físico
do firmware corrigido ainda são efetuados no mini-PC.

## Hora e encerramento — 0.2.2 / Build031v11

- Corrigido o limiar do relógio (o valor antigo só aceitava datas muito futuras).
- Hora UTC obtida do cabeçalho HTTP Date do LumiCore se o relógio ainda não for
  válido; a timezone de apresentação existente mantém-se Europa/Paris. NTP fica
  como alternativa. Sem relógio válido no mini-PC nem Internet, não se inventa a hora.
- Encerramento: pedido autenticado em background, timeout 12 segundos e estado
  pendente/confirmado/falhado na interface, com erro HTTP sem mostrar a chave.
- Um POST repetido não é enviado automaticamente após timeout: o estado remoto
  pode ser incerto. A API mantém confirmação explícita antes de poweroff.
- Se NVS já estiver configurada, executar apenas finalizar para gravar a nova
  versão normal, preservando Wi-Fi e chave.

A API no mini-PC do teste foi verificada com confirm:false e respondeu
confirmation_required. Isso confirma disponibilidade e autenticação local da API,
mas não confirma ainda uma operação de poweroff feita pelo CYD.

Verificado o parser de hora em C++ no host com datas atuais, leap day e erros;
os 11 testes simulados USB continuam a passar. Falta compilar o firmware no
mini-PC e validar relógio/encerramento no CYD físico.

## Acerca vertical — 0.2.3 / Build031v12

O ecrã Acerca acompanha a orientação vertical selecionada. O título fica
centrado, a identidade usa quebra de linha na área de 216 píxeis e o botão
OTA fica abaixo dos dados, com área de toque correspondente. A identidade
LumiCore vem do servidor; removido o rodapé fixo 0.1.0. Se houver mais texto
que a área disponível, fica recortado dentro do corpo, sem cobrir o botão.
As correções de hora e encerramento da versão 0.2.2 mantêm-se. A atualização
pode ser gravada com finalizar, preservando a NVS, sem repetir o setup Wi-Fi.
Ainda é necessária a verificação visual num CYD real.
