# LumiOS Build 31v3

HTTP Wake launcher for `ia.local`.

Flow:
1. ESP32 advertises `ia.local`.
2. Browser requests `/`.
3. ESP32 sends Wake-on-LAN.
4. ESP32 sends the complete HTML launcher page.
5. After a short 150 ms grace period, ESP32 stops HTTP and mDNS.
6. The browser waits 15 seconds in the already-delivered page.
7. Browser opens `http://ia.local/` again.

The 7-second delay is entirely in the browser.

Important: after the ESP32 releases `ia.local`, the normal AI server must itself provide `ia.local` (DNS/mDNS/hosts as appropriate).
