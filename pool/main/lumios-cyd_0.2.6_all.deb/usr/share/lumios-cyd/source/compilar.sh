#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
PIO="${LUMIOS_PIO:-$HOME/.venvs/platformio/bin/pio}"
if [[ ! -x "$PIO" ]]; then PIO="$(command -v pio || true)"; fi
[[ -n "$PIO" && -x "$PIO" ]] || { echo 'PlatformIO indisponivel'; exit 1; }
exec "$PIO" run -e cyd2usb "$@"
