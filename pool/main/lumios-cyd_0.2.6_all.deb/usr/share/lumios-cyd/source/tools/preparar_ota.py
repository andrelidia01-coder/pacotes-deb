#!/usr/bin/env python3
"""Prepare immutable release assets; does not publish or send data."""
import argparse, hashlib, json, shutil, re
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--tag',required=True)
p.add_argument('--firmware',type=Path,default=Path('.pio/build/cyd2usb/firmware.bin'))
p.add_argument('--out',type=Path,default=Path('ota-release'))
a=p.parse_args()
if not a.tag or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._' for c in a.tag):p.error('Tag invalida')
header=(Path(__file__).resolve().parents[1]/'include/lumios_version.h').read_text()
build=int(re.search(r'#define LUMIOS_BUILD_NUMBER (\d+)',header)[1])
root=Path(__file__).resolve().parents[1]
for file,macro in [('lumicore_key.h','LUMIOS_LUMICORE_KEY')]:
    text=(root/'include'/file).read_text()
    value=re.search(r'#define '+macro+r'\s+"([^"\n]*)"',text)
    if not value or value[1]:p.error('Release publico exige headers sem chaves reais: '+file)
data=a.firmware.read_bytes()
if not data or data[0]!=0xe9 or len(data)>0x1D0000:p.error('Firmware ESP32 invalido ou demasiado grande')
a.out.mkdir(parents=True,exist_ok=True)
shutil.copyfile(a.firmware,a.out/'firmware.bin')
m={'product':'LumiOS','build':build,'version':f'BUILD {build}','target':'esp32-2432s028-cyd2usb-4mb','lumicore':'0.1.0','size':len(data),'sha256':hashlib.sha256(data).hexdigest(),'url':f'https://github.com/andrelidia01-coder/pacotes-deb/releases/download/{a.tag}/firmware.bin'}
(a.out/'ota.json').write_text(json.dumps(m,indent=2)+'\n')
print('Publicar firmware.bin no release',a.tag,'e ota.json em lumios/ota.json na branch main.')
