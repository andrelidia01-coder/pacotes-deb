#pragma once
#include <stdint.h>
struct IdleBacklight {
 uint32_t last=0; bool off=false, suppress=false;
 // Returns -1 to extinguish, +1 to wake, 0 otherwise.
 int update(uint32_t now,bool pressed){
  if(pressed){last=now;if(off){off=false;suppress=true;return 1;}}
  else {suppress=false;if(!off&&uint32_t(now-last)>=10000){off=true;return -1;}}
  return 0;
 }
};
