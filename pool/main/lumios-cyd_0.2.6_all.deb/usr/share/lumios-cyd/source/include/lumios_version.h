#pragma once
#define LUMIOS_NAME "LumiOS"
#define LUMIOS_VERSION "BUILD 31V14-RECOVERY"
#define LUMIOS_BUILD "build31v14-twrp-controller"
#define LUMIOS_BUILD_NUMBER 31
#define LUMIOS_OTA_TARGET "esp32-2432s028-cyd2usb-4mb"
