#pragma once
#define LUMIOS_DEFAULT_ENDPOINT "ia.local:8765"
#define LUMIOS_DEFAULT_MAC ""
#define LUMIOS_DEFAULT_BROADCAST "255.255.255.255"
#define LUMIOS_OTA_MANIFEST "https://raw.githubusercontent.com/andrelidia01-coder/pacotes-deb/main/lumios/ota.json"
