#pragma once
#include <stdint.h>
#include <stdio.h>
#include <string.h>

namespace LumiTime {
// 2000-01-01; valid modern clocks are around 1.8 billion seconds, not 11.5 billion.
constexpr int64_t VALID_FROM = 946684800LL;
inline bool valid(int64_t epoch) { return epoch >= VALID_FROM; }

// HTTP Date is UTC. Conversion is independent of the device's display timezone.
inline int64_t httpDate(const char* value) {
  char month[4]={0}, zone[4]={0};
  int d=0,y=0,h=0,m=0,s=0;
  if(!value || strlen(value)<5 || value[3]!=',')return 0;
  if(sscanf(value+5,"%d %3s %d %d:%d:%d %3s",&d,month,&y,&h,&m,&s,zone)!=7)return 0;
  if(strcmp(zone,"GMT")!=0 || y<2000 || y>2099 || d<1 || d>31 || h<0 || h>23 || m<0 || m>59 || s<0 || s>59)return 0;
  const char* names[]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
  int mon=0;for(int i=0;i<12;i++)if(strcmp(month,names[i])==0)mon=i+1;
  if(!mon)return 0;
  const int lengths[]={31,28,31,30,31,30,31,31,30,31,30,31};
  bool leap=(y%4==0 && (y%100!=0 || y%400==0));
  if(d>lengths[mon-1]+(mon==2&&leap?1:0))return 0;
  int adjusted=y-(mon<=2);
  int era=adjusted/400;
  unsigned yoe=unsigned(adjusted-era*400);
  unsigned doy=(153*(mon+(mon>2?-3:9))+2)/5+unsigned(d)-1;
  unsigned doe=yoe*365+yoe/4-yoe/100+doy;
  int64_t days=int64_t(era)*146097+doe-719468;
  return days*86400+h*3600+m*60+s;
}
}
