#pragma once
#define LUMIOS_CONFIG_REV "unconfigured"
#define LUMIOS_WIFI_SSID ""
#define LUMIOS_WIFI_PASSWORD ""
