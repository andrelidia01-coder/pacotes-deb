#pragma once

namespace HardwarePins {
constexpr int BACKLIGHT = 21;

constexpr int TOUCH_SCLK = 25;
constexpr int TOUCH_MISO = 39;
constexpr int TOUCH_MOSI = 32;
constexpr int TOUCH_CS = 33;
constexpr int TOUCH_IRQ = 36;

constexpr int SD_SCLK = 18;
constexpr int SD_MISO = 19;
constexpr int SD_MOSI = 23;
constexpr int SD_CS = 5;
}  // namespace HardwarePins

