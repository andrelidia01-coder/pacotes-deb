#include <Arduino.h>
#include <WiFi.h>
#include <Preferences.h>
#include <cJSON.h>

// Dedicated USB setup firmware: no TFT, Lua, SD or household credentials.
static char line[2048];
static size_t used = 0;
static bool dropping = false;
static bool tested = false;
static String ssid, password;

static const char* field(cJSON* root, const char* key) {
  cJSON* v = cJSON_GetObjectItemCaseSensitive(root, key);
  return cJSON_IsString(v) ? v->valuestring : "";
}
static cJSON* response(const char* id, bool ok, const char* event) {
  cJSON* r = cJSON_CreateObject();
  cJSON_AddNumberToObject(r, "protocol", 1);
  cJSON_AddStringToObject(r, "id", id);
  cJSON_AddBoolToObject(r, "ok", ok);
  cJSON_AddStringToObject(r, "event", event);
  return r;
}
static void emit(cJSON* r) {
  if (!r) return;
  char* text = cJSON_PrintUnformatted(r);
  if (text) { Serial.println(text); cJSON_free(text); }
  cJSON_Delete(r);
}
static void error(const char* id, const char* code) {
  cJSON* r = response(id, false, "error");
  cJSON_AddStringToObject(r, "error", code); emit(r);
}
static void hello(const char* id) {
  cJSON* r = response(id, true, "hello");
  cJSON_AddStringToObject(r, "device", "LumiOS-CYD-Setup");
  cJSON_AddStringToObject(r, "firmware", "usb-setup-v1");
  uint64_t mac = ESP.getEfuseMac();
  char chip[17]; snprintf(chip,sizeof(chip),"%04X%08X",unsigned(mac>>32),unsigned(mac));
  cJSON_AddStringToObject(r, "chip", chip);
  cJSON_AddStringToObject(r, "wifi_mac", WiFi.macAddress().c_str());
  cJSON_AddBoolToObject(r, "wifi_connected", WiFi.status()==WL_CONNECTED);
  cJSON_AddNumberToObject(r, "free_heap", ESP.getFreeHeap()); emit(r);
}
static bool validMac(const char* value) {
  if (strlen(value)!=17) return false;
  for (int i=0;i<17;i++) {
    if (i%3==2) { if(value[i]!=':') return false; }
    else if(!isxdigit(static_cast<unsigned char>(value[i]))) return false;
  }
  return strcmp(value,"00:00:00:00:00:00")!=0;
}
static bool put(Preferences& p, const char* key, const String& value) {
  p.putString(key, value);
  return p.getString(key, "") == value;
}
static void handle(cJSON* root) {
  if (!cJSON_IsObject(root)) { error("", "invalid_json_object"); return; }
  const char* id = field(root,"id");
  const char* cmd = field(root,"command");
  if(strlen(id)>32) { error("", "invalid_id"); return; }
  if(strcmp(cmd,"hello")==0) { hello(id); return; }
  if(strcmp(cmd,"scan")==0) {
    tested=false;
    // A failed association can leave an automatic reconnect running. Stop it
    // before scanning; do not change saved NVS credentials.
    WiFi.setAutoReconnect(false);
    WiFi.disconnect(false,false);WiFi.scanDelete();delay(250);
    int count=WiFi.scanNetworks(false,true);
    if(count<0) {
      WiFi.mode(WIFI_OFF);delay(100);WiFi.mode(WIFI_STA);delay(250);
      count=WiFi.scanNetworks(false,true);
    }
    if(count<0) { error(id,"wifi_scan_failed"); return; }
    cJSON* r=response(id,true,"scan");
    cJSON* networks=cJSON_AddArrayToObject(r,"networks");
    for(int i=0;i<count && i<32;i++) {
      String name=WiFi.SSID(i); if(name.isEmpty())continue;
      cJSON* item=cJSON_CreateObject();
      cJSON_AddStringToObject(item,"ssid",name.c_str());
      cJSON_AddNumberToObject(item,"rssi",WiFi.RSSI(i));
      cJSON_AddBoolToObject(item,"secured",WiFi.encryptionType(i)!=WIFI_AUTH_OPEN);
      cJSON_AddNumberToObject(item,"channel",WiFi.channel(i));
      cJSON_AddItemToArray(networks,item);
    }
    WiFi.scanDelete();emit(r);return;
  }
  if(strcmp(cmd,"connect")==0) {
    String name=field(root,"ssid"), pass=field(root,"password");
    if(name.length()<1 || name.length()>32 || pass.length()>64) {
      error(id,"invalid_wifi_fields");return;
    }
    tested=false;WiFi.setAutoReconnect(false);WiFi.disconnect(false,false);delay(150);
    WiFi.begin(name.c_str(),pass.c_str());
    uint32_t start=millis();
    while(WiFi.status()!=WL_CONNECTED && millis()-start<25000)delay(100);
    if(WiFi.status()!=WL_CONNECTED) {
      WiFi.disconnect(false,false);delay(150);
      error(id,"wifi_connection_failed");return;
    }
    ssid=name;password=pass;tested=true;
    cJSON* r=response(id,true,"connected");
    cJSON_AddStringToObject(r,"ip",WiFi.localIP().toString().c_str());
    cJSON_AddStringToObject(r,"gateway",WiFi.gatewayIP().toString().c_str());
    cJSON_AddNumberToObject(r,"rssi",WiFi.RSSI());emit(r);return;
  }
  if(strcmp(cmd,"apply")==0) {
    if(!tested || WiFi.status()!=WL_CONNECTED) { error(id,"wifi_not_tested");return; }
    String key=field(root,"control_key"), mac=field(root,"wol_mac");
    if(key.length()<16 || key.length()>128 || !validMac(mac.c_str())) {
      error(id,"invalid_pairing_fields");return;
    }
    // Mark complete last; never report success unless both namespaces read back correctly.
    Preferences net;
    if(!net.begin("lumios-net",false)) { error(id,"nvs_open_failed");return; }
    bool ok=put(net,"ssid",ssid) && put(net,"pass",password) && put(net,"configrev","usb-v1");
    net.end();
    Preferences device;
    if(!device.begin("lumi-device",false)) { error(id,"nvs_open_failed");return; }
    ok=ok && put(device,"controlkey",key) && put(device,"wolmac",mac)
      && put(device,"endpoint","ia.local:8765") && put(device,"wolbc","255.255.255.255")
      && put(device,"configrev","usb-v1");
    device.end();
    if(!ok) { error(id,"nvs_write_failed");return; }
    cJSON* r=response(id,true,"configured");
    cJSON_AddStringToObject(r,"wol_mac",mac.c_str());
    cJSON_AddBoolToObject(r,"key_saved",true);emit(r);return;
  }
  if(strcmp(cmd,"status")==0) {
    Preferences net, device;
    net.begin("lumios-net",true); device.begin("lumi-device",true);
    bool configured=net.getString("ssid","").length()>0 && device.getString("controlkey","").length()>=16
      && device.getString("configrev","")=="usb-v1";
    net.end();device.end();
    cJSON* r=response(id,true,"status");
    cJSON_AddBoolToObject(r,"configured",configured);emit(r);return;
  }
  error(id,"unknown_command");
}
void setup() {
  // The minimal firmware does not light the LCD or touch the fan controller.
  pinMode(21,OUTPUT);digitalWrite(21,LOW);
  Serial.begin(115200);
  WiFi.persistent(false);WiFi.setAutoReconnect(false);WiFi.mode(WIFI_STA);
  delay(200);hello("");
}
void loop() {
  while(Serial.available()) {
    char ch=Serial.read();
    if(ch=='\r')continue;
    if(ch=='\n') {
      if(dropping)error("","line_too_long");
      else if(used) {
        line[used]=0;cJSON* root=cJSON_Parse(line);
        if(root) { handle(root);cJSON_Delete(root); }
        else error("","invalid_json");
      }
      used=0;dropping=false;
    } else if(!dropping) {
      if(used+1<sizeof(line))line[used++]=ch;
      else { dropping=true;used=0; }
    }
  }
  delay(5);
}
