#include <Arduino.h>
#include <Preferences.h>
#include <time.h>
#include "DisplayCore.h"
#include "StoreCore.h"
#include "KeyboardCore.h"
#include "LuaCore.h"
#include "NetworkCore.h"
#include "OtaCore.h"
#include "ShellCore.h"
#include "ServerCore.h"
#include "SdShareCore.h"
#include "StorageCore.h"
#include "TouchCore.h"
#include "WolCore.h"
#include "HttpWakeCore.h"
#include "lumios_version.h"
#include "TimeValidity.h"
#include "IdleBacklight.h"
IdleBacklight idleBacklight;

enum class Screen { Home, Server, ShutdownWarning1, ShutdownWarning2, PowerResult, Network, NetworkScan, NetworkKeyboard, NetworkResult, Config, Apps, AppDetails, AppConfirm, AppResult, SdShare, ResetWarning, ResetUnavailable, RecoveryMenu, RecoveryConfirm, RecoveryResult, System, OtaResult, Display, Storage, StorageWarning1, StorageWarning2, StorageResult, Alerts, LuaApp };
bool managerPackages=false;unsigned managerSelected=0;bool managerDelete=false;
DisplayCore display; TouchCore touch; StorageCore storage; NetworkCore network; WolCore wol; ServerCore server; StoreCore apps; SdShareCore sdShare; OtaCore ota; LuaCore lua;
ShellCore shell(display.tft()); KeyboardCore keyboard(display.tft()); Preferences prefs; HttpWakeCore httpWake;
Screen screen=Screen::Home; SdReport sdReport; uint8_t brightness=70,networkFirst=0;
unsigned launcherPage=0,managerPage=0;
uint16_t screenOrientation=0;
bool superMemory=false,appForcedLandscape=false;
uint32_t lastClockDraw=0; int lastClockMinute=-1;
int lastShutdownState=0;
bool networkSuccess=false,lastWifiOnline=false,lastServerOnline=false,powerSent=false,powerWasShutdown=false,otaSuccess=false,recoverySuccess=false;
uint8_t recoverySelected=0; String recoveryMessage; String selectedSsid; SdTestResult lastSdTest=SdTestResult::NotRun;

void onStorageProgress(SdTestPhase phase,uint8_t percent,uint32_t){shell.storageProgress(phase,percent);}
bool wifiOnline(){return network.online();} bool sdReady(){return sdReport.state==SdState::Ready;}
void drawManagerDetail();
bool portraitMenu(){return (screenOrientation==90||screenOrientation==270)&&
 (screen==Screen::Home||screen==Screen::Config||screen==Screen::Display||screen==Screen::System||screen==Screen::ResetWarning||screen==Screen::ResetUnavailable||screen==Screen::RecoveryMenu||screen==Screen::RecoveryConfirm||screen==Screen::RecoveryResult||
  screen==Screen::Server||screen==Screen::ShutdownWarning1||
  screen==Screen::ShutdownWarning2||screen==Screen::PowerResult);}
void applyScreenOrientation(){
 uint16_t wanted=portraitMenu()?screenOrientation:
  ((screenOrientation==90||screenOrientation==270)?0:screenOrientation);
 if(display.orientation()!=wanted){display.setOrientation(wanted);touch.setOrientation(wanted);}
}
void drawCurrent(){applyScreenOrientation();switch(screen){
 case Screen::Home:shell.home(wifiOnline(),sdReady(),server.online(),apps,launcherPage);break; case Screen::Server:shell.serverPage(wifiOnline(),sdReady(),server.online(),wol.mac());break;
 case Screen::ShutdownWarning1:shell.shutdownWarning(1,wifiOnline(),sdReady());break;
 case Screen::ShutdownWarning2:shell.shutdownWarning(2,wifiOnline(),sdReady());break;
 case Screen::PowerResult:shell.powerResult(powerSent,powerWasShutdown,wifiOnline(),sdReady(),powerWasShutdown?server.shutdownMessage():String(),powerWasShutdown&&server.shutdownState()==1);break;
 case Screen::Network:shell.networkPage(network,sdReady());break; case Screen::NetworkScan:shell.networkList(network,networkFirst,sdReady());break;
 case Screen::NetworkKeyboard:keyboard.draw(wifiOnline(),sdReady());break; case Screen::NetworkResult:shell.networkResult(networkSuccess,selectedSsid,sdReady());break;
 case Screen::Config:shell.configPage(wifiOnline(),sdReady());break; case Screen::Display:shell.displayPage(brightness,wifiOnline(),sdReady(),screenOrientation,superMemory);break;
 case Screen::Apps:shell.appsPage(apps,wifiOnline(),sdReady(),managerPage,managerPackages);break;
 case Screen::AppDetails:case Screen::AppConfirm:case Screen::AppResult:drawManagerDetail();break;
 case Screen::SdShare:shell.sdSharePage(sdShare.active(),wifiOnline(),sdReady(),sdShare.active()?("http://"+network.ip()+"/sd"):String("--"));break;
 case Screen::ResetWarning:shell.resetPage(false,wifiOnline(),sdReady());break;
 case Screen::ResetUnavailable:shell.resetPage(true,wifiOnline(),sdReady());break;
 case Screen::RecoveryMenu:shell.recoveryPage(recoverySelected,wifiOnline(),sdReady());break;
 case Screen::RecoveryConfirm:shell.recoveryConfirmPage(recoverySelected,wifiOnline(),sdReady());break;
 case Screen::RecoveryResult:shell.recoveryResultPage(recoverySuccess,recoveryMessage,wifiOnline(),sdReady());break;
 case Screen::System:shell.systemPage(wifiOnline(),sdReady(),server.systemInfo());break;
 case Screen::OtaResult:shell.otaResult(otaSuccess,ota.message(),wifiOnline(),sdReady());break;
 case Screen::Storage:shell.storagePage(sdReport,wifiOnline());break; case Screen::StorageWarning1:shell.storageWarning(1,wifiOnline(),sdReady());break;
 case Screen::StorageWarning2:shell.storageWarning(2,wifiOnline(),sdReady());break; case Screen::StorageResult:shell.storageResult(lastSdTest,wifiOnline(),sdReady());break;
 case Screen::Alerts:shell.alertsPage(wifiOnline(),sdReady());break;
 case Screen::LuaApp:break;}
 // Icon loading temporarily uses the SD SPI bus; always leave the touch bus ready.
 touch.restoreBus();
}
void drawManagerDetail(){
 shell.luaPage("Gestor de apps",wifiOnline(),sdReady());
 auto& t=display.tft();t.fillRect(0,32,320,208,0x0863);t.setTextDatum(MC_DATUM);
 auto text=[&](const String& value,int y,uint16_t color=TFT_WHITE){t.setTextColor(color,0x0863);t.drawString(value,160,y,2);};
 auto button=[&](const char* value,int x,int y,int w,uint16_t color){t.fillRoundRect(x,y,w,38,5,color);t.setTextColor(TFT_WHITE,color);t.drawString(value,x+w/2,y+19,2);};
 if(screen==Screen::AppResult){
  text("Resultado",66,0x05df);String msg=apps.message;
  for(unsigned i=0;i<msg.length()&&i<108;i+=36)text(msg.substring(i,i+36),99+(i/36)*24);
  button("VOLTAR A LISTA",12,179,296,0x2495);return;
 }
 unsigned count=managerPackages?apps.packageCount:apps.count;
 if(managerSelected>=count){text("Selecao indisponivel",99,TFT_RED);return;}
 String name=managerPackages?apps.packages[managerSelected]:apps.entries[managerSelected].name;
 if(name.length()>34)name=name.substring(0,31)+"...";
 text(name,62,0x05df);
 if(screen==Screen::AppConfirm){
  text(managerDelete?"Apagar pacote definitivamente?":"Desinstalar esta aplicacao?",103,TFT_RED);
  text(managerDelete?"A app instalada fica preservada":"Apaga a pasta e dados desta app",133);
  button("CANCELAR",8,179,146,0x2495);button("CONFIRMAR",166,179,146,TFT_RED);return;
 }
 text(managerPackages?"Pacote no SD":"Aplicacao instalada no SD",96);
 button(managerPackages?"INSTALAR":"DESINSTALAR",12,132,296,managerPackages?0x2495:TFT_RED);
 if(managerPackages)button("APAGAR PACOTE",12,179,296,TFT_RED);
}
void restoreConfiguredOrientation(){appForcedLandscape=false;}
void goHome(){lua.stop();restoreConfiguredOrientation();if(sdShare.active()){sdShare.stop();touch.restoreBus();}launcherPage=min(launcherPage,(apps.count+2)/9);screen=Screen::Home;drawCurrent();}
void goBack(){lua.stop();restoreConfiguredOrientation();if(screen==Screen::RecoveryConfirm||screen==Screen::RecoveryResult){screen=Screen::RecoveryMenu;drawCurrent();return;}if(screen==Screen::AppDetails||screen==Screen::AppConfirm||screen==Screen::AppResult){screen=Screen::Apps;drawCurrent();return;}if(screen==Screen::Display||screen==Screen::Storage||screen==Screen::Apps||screen==Screen::System||screen==Screen::ResetWarning||screen==Screen::ResetUnavailable||screen==Screen::RecoveryMenu||screen==Screen::RecoveryConfirm||screen==Screen::RecoveryResult||screen==Screen::OtaResult||screen==Screen::SdShare){if(sdShare.active()){sdShare.stop();touch.restoreBus();}screen=Screen::Config;}
 else if(screen==Screen::StorageWarning1||screen==Screen::StorageWarning2||screen==Screen::StorageResult)screen=Screen::Storage;
 else if(screen==Screen::NetworkScan||screen==Screen::NetworkKeyboard||screen==Screen::NetworkResult)screen=Screen::Network;
 else if(screen==Screen::ShutdownWarning1||screen==Screen::ShutdownWarning2||screen==Screen::PowerResult)screen=Screen::Server;
 else screen=Screen::Home;drawCurrent();}
void refreshStorage(){sdReport=storage.probeReadOnly();touch.restoreBus();screen=Screen::Storage;drawCurrent();}
void runStorageTest(){lastSdTest=storage.destructiveFullTest(onStorageProgress);touch.restoreBus();sdReport=storage.probeReadOnly();touch.restoreBus();screen=Screen::StorageResult;drawCurrent();}
void scanNetworks(){shell.networkScanning(wifiOnline(),sdReady());network.scan();touch.restoreBus();networkFirst=0;screen=Screen::NetworkScan;drawCurrent();}
void connectSelectedNetwork(){shell.networkConnecting(selectedSsid,sdReady());networkSuccess=network.connect(selectedSsid,keyboard.password());touch.restoreBus();screen=Screen::NetworkResult;drawCurrent();}
void openApp(AppId app){if(app==AppId::Wol)screen=Screen::Server;else if(app==AppId::Network)screen=Screen::Network;else if(app==AppId::Config)screen=Screen::Config;
 else{shell.lockedNotice();delay(650);shell.home(wifiOnline(),sdReady(),server.online(),apps,launcherPage);return;}drawCurrent();}

void openMobile(unsigned index){
 if(index>=apps.count)return;
 if(apps.entries[index].requiresServer&&!server.online()){
   shell.lockedNotice();delay(350);drawCurrent();return;
 }
 String source;bool ok=apps.readScript(index,source);touch.restoreBus();
 if(!ok){shell.otaResult(false,"Nao foi possivel ler main.lua",wifiOnline(),sdReady());screen=Screen::LuaApp;return;}
 // Existing .app packages use the 320x240 API and remain landscape-only.
 if(screenOrientation==90||screenOrientation==270){appForcedLandscape=true;display.setOrientation(0);touch.setOrientation(0);}
 screen=Screen::LuaApp;shell.luaPage(apps.entries[index].name.c_str(),wifiOnline(),sdReady());
 if(!lua.start(source,display.tft(),apps.entries[index].id,superMemory)&&lua.lastError().length())Serial.println(lua.lastError());
}
void setup(){Serial.begin(115200);DeviceConfig::begin();display.begin();prefs.begin("lumios",false);brightness=constrain(prefs.getUChar("brightness",70),5,100);
 screenOrientation=prefs.getUShort("orientation",prefs.getBool("rotate180",false)?180:0);if(screenOrientation%90)screenOrientation=0;
 superMemory=prefs.getBool("superMemory",false);display.setOrientation(screenOrientation);touch.setOrientation(screenOrientation);
 display.setBacklight(map(brightness,0,100,0,255));touch.begin();sdReport=storage.probeReadOnly();touch.restoreBus();apps.refresh();touch.restoreBus();sdShare.attach(apps);lua.begin();network.begin();server.begin();
 lastWifiOnline=wifiOnline();lastServerOnline=server.online();Serial.printf("%s %s | SD=%u\n",LUMIOS_NAME,LUMIOS_VERSION,static_cast<unsigned>(sdReport.state));goHome();}
void loop(){
 // The server state must be refreshed continuously. Build 10 never called
 // server.update(), leaving server.online() permanently false.
 server.update(wifiOnline());
 int currentShutdownState=server.shutdownState();
 if(currentShutdownState!=lastShutdownState){
   lastShutdownState=currentShutdownState;
   if(screen==Screen::PowerResult&&powerWasShutdown&&currentShutdownState!=0){
     powerSent=currentShutdownState==2;drawCurrent();
   }
 }
 httpWake.begin(&wol);
 httpWake.loop();
 bool nowServerOnline=server.online();
 if(nowServerOnline!=lastServerOnline){
   lastServerOnline=nowServerOnline;
   if(screen!=Screen::NetworkKeyboard&&screen!=Screen::LuaApp)drawCurrent();
 }
 if(screen==Screen::LuaApp)lua.tick();
 bool pressed=touch.pressed();
 int idleAction=idleBacklight.update(millis(),pressed);
 if(idleAction<0)display.setBacklight(0);
 if(idleAction>0)display.setBacklight(map(brightness,0,100,0,255));
 TouchPoint p;if(idleBacklight.suppress||!touch.read(p)){
 // Health HTTP runs in ServerCore worker; touch stays on the UI loop.
 if(sdShare.active()){sdShare.loop();touch.restoreBus();}
 bool nowOnline=wifiOnline();if(nowOnline!=lastWifiOnline){lastWifiOnline=nowOnline;if(screen!=Screen::NetworkKeyboard&&screen!=Screen::LuaApp)drawCurrent();}
 if(screen!=Screen::NetworkKeyboard&&millis()-lastClockDraw>=1000){lastClockDraw=millis();time_t now=time(nullptr);struct tm localTime;
  int minute=-1;if(LumiTime::valid(now)){localtime_r(&now,&localTime);minute=localTime.tm_min;}
  if(minute!=lastClockMinute){lastClockMinute=minute;shell.drawClock();}}
 delay(10);return;}
 if(screen!=Screen::NetworkKeyboard&&shell.alertHit(p.x,p.y)){lua.stop();if(sdShare.active()){sdShare.stop();touch.restoreBus();}screen=Screen::Alerts;drawCurrent();return;}
 if(screen!=Screen::Home&&shell.homeButtonHit(p.x,p.y)){goHome();return;}if(screen!=Screen::Home&&shell.backHit(p.x,p.y)){goBack();return;}
 if(screen==Screen::Home){
  if(p.y<32&&p.x<115){launcherPage=(launcherPage+1)%((apps.count+3+8)/9);drawCurrent();return;}
  bool portrait=portraitMenu();
  if(p.y<32||p.y>=(portrait?320:240))return;
  unsigned col=min(2,(int)(p.x/(portrait?80:107)));
  unsigned row=min(2,max(0,(int)((p.y-32)/(portrait?83:67))));
  unsigned index=launcherPage*9+col+3*row;
  if(index<3)openApp(index==0?AppId::Wol:(index==1?AppId::Network:AppId::Config));
  else openMobile(index-3);
 }
 else if(screen==Screen::LuaApp)lua.touch(p.x,p.y);
 else if(screen==Screen::Server&&wifiOnline()&&shell.wolHit(p.x,p.y)){if(server.online()){screen=Screen::ShutdownWarning1;drawCurrent();}else{powerWasShutdown=false;powerSent=wol.send();screen=Screen::PowerResult;drawCurrent();}}
 else if(screen==Screen::ShutdownWarning1&&shell.confirmHit(p.x,p.y)){screen=Screen::ShutdownWarning2;drawCurrent();}
 else if(screen==Screen::ShutdownWarning2&&shell.confirmHit(p.x,p.y)){powerWasShutdown=true;powerSent=server.shutdown();screen=Screen::PowerResult;drawCurrent();}
 else if(screen==Screen::PowerResult&&shell.confirmHit(p.x,p.y)){screen=Screen::Server;drawCurrent();}
 else if(screen==Screen::Network){if(shell.networkScanHit(p.x,p.y))scanNetworks();else if(network.online()&&shell.networkForgetHit(p.x,p.y)){network.forget();drawCurrent();}}
 else if(screen==Screen::NetworkScan){int8_t row=shell.networkRowHit(p.x,p.y);if(row>=0&&networkFirst+row<network.count()){
   selectedSsid=network.entry(networkFirst+row).ssid;keyboard.begin(selectedSsid);screen=Screen::NetworkKeyboard;drawCurrent();}
  else{int8_t page=shell.networkPageHit(p.x,p.y);if(page<0&&networkFirst>=5){networkFirst-=5;drawCurrent();}else if(page>0&&networkFirst+5<network.count()){networkFirst+=5;drawCurrent();}else if(!network.count()&&shell.networkScanHit(p.x,p.y))scanNetworks();}}
 else if(screen==Screen::NetworkKeyboard){KeyboardAction action=keyboard.touch(p.x,p.y);if(action==KeyboardAction::Cancel){screen=Screen::NetworkScan;drawCurrent();}else if(action==KeyboardAction::Submit)connectSelectedNetwork();}
 else if(screen==Screen::NetworkResult&&shell.confirmHit(p.x,p.y)){screen=Screen::Network;drawCurrent();}
 else if(screen==Screen::Config){bool portrait=portraitMenu();int start=portrait?42:38,step=portrait?44:33;
  if(p.y>=start&&p.y<start+step*6){int row=(p.y-start)/step;
   if(row==0)screen=Screen::Display;else if(row==1)screen=Screen::Storage;else if(row==2){apps.refresh();apps.scanPackages();managerPage=0;touch.restoreBus();screen=Screen::Apps;}else if(row==3)screen=Screen::SdShare;else if(row==4){recoverySelected=0;screen=Screen::RecoveryMenu;}else screen=Screen::System;drawCurrent();}}
 // TWRP-like controller: every operation requires a second, explicit confirmation.
 else if(screen==Screen::RecoveryMenu){int8_t row=shell.recoveryRowHit(p.x,p.y);if(row>=0){recoverySelected=(uint8_t)row;screen=Screen::RecoveryConfirm;drawCurrent();}}
 else if(screen==Screen::RecoveryConfirm){if(shell.recoveryCancelHit(p.x,p.y)){screen=Screen::RecoveryMenu;drawCurrent();}else if(shell.recoveryConfirmHit(p.x,p.y)){const char* actions[]={"recovery.enter","backup.create","backup.restore","storage.partition","system.restore","factory.reset"};recoveryMessage="Pedido enviado";recoverySuccess=server.recoveryAction(actions[recoverySelected],recoveryMessage);screen=Screen::RecoveryResult;drawCurrent();}}
 else if(screen==Screen::RecoveryResult&&shell.confirmHit(p.x,p.y)){screen=Screen::RecoveryMenu;drawCurrent();}
 else if(screen==Screen::ResetWarning&&shell.confirmHit(p.x,p.y)){screen=Screen::RecoveryMenu;drawCurrent();}
 else if(screen==Screen::ResetUnavailable&&shell.confirmHit(p.x,p.y)){screen=Screen::Config;drawCurrent();}
 else if(screen==Screen::Apps){
  unsigned count=managerPackages?apps.packageCount:apps.count;
  if(p.y>=174&&p.y<200){
   if(p.x<160){managerPackages=!managerPackages;managerPage=0;}
   else {unsigned pages=max(1U,(count+4)/5);managerPage=(managerPage+(p.x<220?pages-1:1))%pages;}
   drawCurrent();
  }else if(p.x>=160&&p.y>=59&&p.y<174){
   unsigned i=managerPage*5+(p.y-59)/23;
   if(i<count){managerSelected=i;screen=Screen::AppDetails;drawCurrent();}
  }
 }
 else if(screen==Screen::AppDetails){
  if(p.y>=132&&p.y<170){managerDelete=false;if(managerPackages){
    shell.luaPage("A instalar...",wifiOnline(),sdReady());
    apps.install(apps.packages[managerSelected]);apps.scanPackages();touch.restoreBus();screen=Screen::AppResult;
   }else screen=Screen::AppConfirm;drawCurrent();
  }else if(managerPackages&&p.y>=179&&p.y<217){managerDelete=true;screen=Screen::AppConfirm;drawCurrent();}
 }
 else if(screen==Screen::AppConfirm&&p.y>=179&&p.y<217){
  if(p.x<160){screen=Screen::AppDetails;drawCurrent();}
  else {
   shell.luaPage("A remover...",wifiOnline(),sdReady());
   if(managerDelete)apps.deletePackage(apps.packages[managerSelected]);else apps.uninstallApp(managerSelected);
   touch.restoreBus();managerPage=0;screen=Screen::AppResult;drawCurrent();
  }
 }
 else if(screen==Screen::AppResult&&p.y>=179&&p.y<217){screen=Screen::Apps;drawCurrent();}
 else if(screen==Screen::SdShare&&p.x>=50&&p.x<=270&&p.y>=174&&p.y<=206){if(sdShare.active())sdShare.stop();else sdShare.start(wifiOnline(),sdReady());touch.restoreBus();drawCurrent();}
 else if(screen==Screen::System&&wifiOnline()&&shell.systemUpdateHit(p.x,p.y)){screen=Screen::OtaResult;applyScreenOrientation();shell.otaProgress(wifiOnline(),sdReady());otaSuccess=ota.install();drawCurrent();}
 else if(screen==Screen::OtaResult&&shell.confirmHit(p.x,p.y)){screen=Screen::System;drawCurrent();}
 else if(screen==Screen::Display&&p.x>=(portraitMenu()?12:35)&&p.x<=(portraitMenu()?228:285)&&p.y>=(portraitMenu()?190:160)&&p.y<=(portraitMenu()?233:199)){
  screenOrientation=(screenOrientation+90)%360;prefs.putUShort("orientation",screenOrientation);
  display.setOrientation(screenOrientation);touch.setOrientation(screenOrientation);drawCurrent();
 }
 else if(screen==Screen::Display&&p.x>=(portraitMenu()?12:35)&&p.x<=(portraitMenu()?228:285)&&p.y>=(portraitMenu()?249:200)&&p.y<=(portraitMenu()?292:239)){
  superMemory=!superMemory;prefs.putBool("superMemory",superMemory);drawCurrent();
 }
 else if(screen==Screen::Display&&p.y>=(portraitMenu()?112:95)&&p.y<=(portraitMenu()?165:145)){brightness=constrain(map(p.x,portraitMenu()?25:45,portraitMenu()?215:275,5,100),5,100);display.setBacklight(map(brightness,0,100,0,255));prefs.putUChar("brightness",brightness);shell.drawBrightness(brightness);}
 else if(screen==Screen::Storage){if(shell.storageRefreshHit(p.x,p.y))refreshStorage();else if(sdReady()&&shell.storageTestHit(p.x,p.y)){screen=Screen::StorageWarning1;drawCurrent();}}
 else if(screen==Screen::StorageWarning1&&shell.confirmHit(p.x,p.y)){screen=Screen::StorageWarning2;drawCurrent();}
 else if(screen==Screen::StorageWarning2&&shell.confirmHit(p.x,p.y))runStorageTest();else if(screen==Screen::StorageResult&&shell.confirmHit(p.x,p.y))refreshStorage();}
