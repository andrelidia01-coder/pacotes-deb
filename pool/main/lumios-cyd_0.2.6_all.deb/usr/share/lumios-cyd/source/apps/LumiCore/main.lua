-- LumiCore 0.1.0: primeira vista, apenas leituras.
local BG=0x0863
local CYAN=0x07ff
local WHITE=0xffff
local GREEN=0x07e0
local RED=0xf800
local last=0
local data={online=false}
lumicore.start()
local function metric(value,unit)
 if type(value)~="number" then return "--" end
 return tostring(math.floor(value+0.5))..unit
end
function on_draw()
 data=lumicore.read()
 ui.clear(BG)
 ui.text("LUMICORE",160,51,4,CYAN)
 ui.text(data.online and "SERVIDOR ONLINE" or "SEM LIGACAO",160,78,2,data.online and GREEN or RED)
 ui.text("PERFIL GPU: "..(data.profile or "--"),160,105,2,WHITE)
 ui.text("GPU  "..metric(data.gpu_temp," C").."  "..metric(data.gpu_power," W"),160,134,2,WHITE)
 ui.text("CPU  "..metric(data.cpu_temp," C"),160,160,2,WHITE)
 ui.text("TOMADA  "..metric(data.wall_power," W"),160,186,2,WHITE)
 ui.text("LumiCore 0.1.0",160,220,1,CYAN)
end
function on_tick(now)
 if now-last>=1000 then last=now;ui.redraw() end
end
