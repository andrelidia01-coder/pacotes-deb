py -m platformio run -e cyd2usb --target upload --upload-port COM6
pause