#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
port="${1:-/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0}"
[[ -e "$port" ]] || { echo "CYD nao encontrado: $port"; exit 1; }
exec bash compilar.sh --target upload --upload-port "$port"
