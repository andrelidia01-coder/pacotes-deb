#pragma once

#include <Arduino.h>
#include <Preferences.h>
#include <WiFi.h>

struct WifiEntry {
  String ssid;
  int32_t rssi = -100;
  bool secured = true;
};

class NetworkCore {
 public:
  void begin();
  bool scan();
  uint8_t count() const { return count_; }
  const WifiEntry& entry(uint8_t index) const { return entries_[index]; }
  bool connect(const String& ssid, const String& password, uint32_t timeoutMs = 15000);
  void forget();
  bool online() const { return WiFi.status() == WL_CONNECTED; }
  String ssid() const { return online() ? WiFi.SSID() : String(); }
  String ip() const { return online() ? WiFi.localIP().toString() : String("--"); }
  int32_t rssi() const { return online() ? WiFi.RSSI() : -100; }
  bool hasSavedNetwork() const { return savedSsid_.length() > 0; }

 private:
  static constexpr uint8_t MAX_NETWORKS = 12;
  WifiEntry entries_[MAX_NETWORKS];
  uint8_t count_ = 0;
  Preferences prefs_;
  String savedSsid_;
  String savedPassword_;
  bool waitForConnection(uint32_t timeoutMs);
};
