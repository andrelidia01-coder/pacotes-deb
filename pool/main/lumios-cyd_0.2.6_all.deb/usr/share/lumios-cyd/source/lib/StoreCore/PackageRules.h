#pragma once
#include <string.h>
#include <stddef.h>
namespace PackageRules {
inline bool id(const char* p) {
 if(!p || !*p || strlen(p)>32)return false;
 for(;*p;p++)if(!((*p>='a'&&*p<='z')||(*p>='0'&&*p<='9')||*p=='-'||*p=='_'))return false;
 return true;
}
inline bool path(const char* p) {
 if(!p||!*p||strlen(p)>120||*p=='/')return false;
 const char* start=p;unsigned depth=0;
 for(const char* q=p;;q++){
  if(*q=='/'||!*q){size_t n=q-start;
   if(!n|| (n==1&&*start=='.') || (n==2&&start[0]=='.'&&start[1]=='.'))return false;
   if(!*q)return true;
   if(++depth>10)return false;
   start=q+1;if(!*start)return true;
  }else if(!((*q>='a'&&*q<='z')||(*q>='A'&&*q<='Z')||(*q>='0'&&*q<='9')||*q=='-'||*q=='_'||*q=='.'))return false;
 }
}
}
