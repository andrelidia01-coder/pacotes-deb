#pragma once

#include <TFT_eSPI.h>
#include "StorageCore.h"
#include "NetworkCore.h"
#include "StoreCore.h"

enum class AppId : uint8_t {
  Oc, Gpu, Energy, Ai, Disks, Fans, Network, Wol, Config, None
};

class ShellCore {
 public:
  explicit ShellCore(TFT_eSPI& tft);
  void drawClock();
  void home(bool wifiOnline, bool sdReady, bool serverOnline, const StoreCore& apps, unsigned page=0);
  void serverPage(bool wifiOnline, bool sdReady, bool serverOnline, const char* mac);
  void powerResult(bool sent, bool shutdown, bool wifiOnline, bool sdReady,
                   const String& detail=String(), bool pending=false);
  void shutdownWarning(uint8_t step, bool wifiOnline, bool sdReady);
  void networkPage(const NetworkCore& network, bool sdReady);
  void networkScanning(bool wifiOnline, bool sdReady);
  void networkList(const NetworkCore& network, uint8_t first, bool sdReady);
  void networkConnecting(const String& ssid, bool sdReady);
  void networkResult(bool success, const String& ssid, bool sdReady);
  void configPage(bool wifiOnline, bool sdReady);
  void resetPage(bool unavailable,bool wifiOnline,bool sdReady);
  void recoveryPage(uint8_t selected,bool wifiOnline,bool sdReady);
  void recoveryConfirmPage(uint8_t selected,bool wifiOnline,bool sdReady);
  void recoveryResultPage(bool success,const String& message,bool wifiOnline,bool sdReady);
  int8_t recoveryRowHit(int16_t x,int16_t y) const;
  bool recoveryConfirmHit(int16_t x,int16_t y) const;
  bool recoveryCancelHit(int16_t x,int16_t y) const;
  void appsPage(const StoreCore& apps, bool wifiOnline, bool sdReady, unsigned page=0,bool packages=false);
  void luaPage(const char* name,bool wifi,bool sd);
  void sdSharePage(bool active, bool wifiOnline, bool sdReady, const String& address);
  void systemPage(bool wifiOnline, bool sdReady, const String& identity);
  void otaProgress(bool wifiOnline, bool sdReady);
  void otaResult(bool success, const String& message, bool wifiOnline, bool sdReady);
  void displayPage(uint8_t brightness, bool wifiOnline, bool sdReady, uint16_t orientation=0, bool superMemory=false);
  void storagePage(const SdReport& report, bool wifiOnline);
  void storageWarning(uint8_t step, bool wifiOnline, bool sdReady);
  void storageProgress(SdTestPhase phase, uint8_t percent);
  void storageResult(SdTestResult result, bool wifiOnline, bool sdReady);
  void alertsPage(bool wifiOnline, bool sdReady);
  void lockedNotice();
  void drawBrightness(uint8_t brightness);
  AppId homeHit(int16_t x, int16_t y) const;
  bool alertHit(int16_t x, int16_t y) const;
  bool backHit(int16_t x, int16_t y) const;
  bool homeButtonHit(int16_t x, int16_t y) const;
  bool storageRefreshHit(int16_t x, int16_t y) const;
  bool storageTestHit(int16_t x, int16_t y) const;
  bool confirmHit(int16_t x, int16_t y) const;
  bool networkScanHit(int16_t x, int16_t y) const;
  bool wolHit(int16_t x, int16_t y) const;
  int8_t appManagerRowHit(int16_t x, int16_t y) const;
  bool systemUpdateHit(int16_t x, int16_t y) const;
  bool networkForgetHit(int16_t x, int16_t y) const;
  int8_t networkRowHit(int16_t x, int16_t y) const;
  int8_t networkPageHit(int16_t x, int16_t y) const;

 private:
  TFT_eSPI& tft_;
  void header(const char* title, bool navigation, bool wifiOnline, bool sdReady);
  void icon(AppId id, int x, int y, uint16_t color);
  void label(const char* text, int x, int y, uint16_t color);
  void wifiIcon(int x, int y, uint16_t color);
  void bellIcon(int x, int y, uint16_t color);
  void button(int y, const char* text, uint16_t color);
};
