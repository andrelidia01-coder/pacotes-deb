#pragma once

#include <TFT_eSPI.h>

#include "StorageCore.h"

class UiCore {
 public:
  explicit UiCore(TFT_eSPI& tft);
  void boot();
  void storagePage(const SdReport& report);
  void eraseWarning(uint8_t step);
  void testProgress(SdTestPhase phase, uint8_t percent, uint32_t errors);
  void testResult(SdTestResult result);
  bool retryPressed(int16_t x, int16_t y) const;
  bool destructivePressed(int16_t x, int16_t y) const;
  bool confirmPressed(int16_t x, int16_t y) const;

 private:
  TFT_eSPI& tft_;
  void header(const char* title);
  void row(int y, const char* label, const String& value, uint16_t color);
  String sizeText(uint64_t bytes) const;
  void button(int y, const char* text, uint16_t color);
};
