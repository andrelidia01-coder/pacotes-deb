#pragma once
#include <Arduino.h>
namespace DeviceConfig {
void begin();
String endpoint(); void setEndpoint(const String& value); const String& mac(); const String& broadcast();
const String& controlKey(); 
}
