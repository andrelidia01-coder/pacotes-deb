#include "DisksTelemetry.h"
#include "ServerCore.h"
#include <HTTPClient.h>
#include <WiFi.h>
#include <cJSON.h>
#include <atomic>
#include <memory>
#include <math.h>
#include <time.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>

namespace DisksTelemetry {
namespace {
struct Snapshot {Gpus gpus;Energy energy;Row rows[MAX_ROWS];unsigned count=0;bool online=false;uint32_t received=0;char error[64]={};};
Snapshot cached;
SemaphoreHandle_t mutex=nullptr;
TaskHandle_t task=nullptr;
std::atomic<bool> enabled{false};std::atomic<unsigned> session{0};
void fail(Snapshot& s,const char* error){s.online=false;s.count=0;strlcpy(s.error,error,sizeof(s.error));}
cJSON* field(cJSON* o,const char* k){return cJSON_GetObjectItemCaseSensitive(o,k);}
double number(cJSON* o,const char* k,double fallback=-1){auto v=field(o,k);return cJSON_IsNumber(v)&&isfinite(v->valuedouble)?v->valuedouble:fallback;}
void stringField(cJSON* o,const char* k,char* out,size_t size){auto v=field(o,k);strlcpy(out,cJSON_IsString(v)?v->valuestring:"--",size);}
// Bound the recursive JSON parser and its allocation demand before parsing.
bool bounded(const String& body,size_t& allocationBudget){
 unsigned nodes=0;int depth=0;bool quoted=false,escaped=false,scalar=false;
 for(unsigned i=0;i<body.length();i++){
  char c=body[i];if(quoted){if(escaped)escaped=false;else if(c=='\\')escaped=true;else if(c=='"')quoted=false;continue;}
  if(c=='"'){quoted=true;scalar=false;++nodes;}
  else if(c=='{'||c=='['){scalar=false;++nodes;if(++depth>10)return false;}
  else if(c=='}'||c==']'){scalar=false;if(--depth<0)return false;}
  else if(c==','||c==':'||c==' '||c=='\n'||c=='\r'||c=='\t')scalar=false;
  else if(!scalar){scalar=true;++nodes;}
  if(nodes>2048)return false;
 }
 allocationBudget=nodes*(sizeof(cJSON)+32)+body.length()+16384;
 return !quoted&&depth==0;
}
cJSON* query(const String& command){
 if(!enabled.load())return nullptr;
 HTTPClient h;h.setConnectTimeout(700);h.setTimeout(1200);
 if(!h.begin(String("http://")+ServerCore().endpoint()+"/v1/run"))return nullptr;
 h.addHeader("Content-Type","application/json");
 int status=h.POST(String("{\"command\":\"")+command+"\",\"args\":{}}");
 int length=h.getSize();String body;
 if(status==200&&length>0&&length<=16384&&ESP.getFreeHeap()>unsigned(length*3+30000))body=h.getString();h.end();
 size_t needed=0;if(status!=200||body.length()!=unsigned(length)||!bounded(body,needed)||ESP.getFreeHeap()<needed)return nullptr;
 return cJSON_Parse(body.c_str());
}
double scalar(const String& command){auto j=query(command);auto v=j?field(j,"result"):nullptr;double n=cJSON_IsNumber(v)&&isfinite(v->valuedouble)?v->valuedouble:-1;if(j)cJSON_Delete(j);return n;}
void fetch(Snapshot& s){
 fail(s,"LumiCore indisponivel");
 if(WiFi.status()!=WL_CONNECTED||!ServerCore::compatibleEndpoint())return;
 s.energy.cpu=scalar("cpu.power");s.energy.total=scalar("power.total");
 double gpuPower=0;bool hasPower=false;
 for(unsigned slot=0;slot<4&&enabled.load();slot++){
  String prefix=slot?String("gpu")+slot:String("gpu");
  auto j=query(prefix+".name");auto name=j?field(j,"result"):nullptr;
  if(!cJSON_IsString(name)||!name->valuestring[0]){if(j)cJSON_Delete(j);continue;}
  auto& g=s.gpus.rows[s.gpus.count++];strlcpy(g.name,name->valuestring,sizeof(g.name));cJSON_Delete(j);
  strlcpy(g.vendor,"--",sizeof(g.vendor));strlcpy(g.chip,"--",sizeof(g.chip));
  g.temp=scalar(prefix+".temp");g.usage=scalar(prefix+".usage");g.power=scalar(prefix+".power");
  g.clock=scalar(prefix+".clock");g.memoryClock=scalar(prefix+".memory_clock");g.fan=scalar(prefix+".fan");
  if(slot==0){g.memoryUsed=scalar("gpu.vram.used");g.memoryTotal=scalar("gpu.vram.total");}
  if(g.power>=0){gpuPower+=g.power;hasPower=true;}
 }
 s.gpus.online=true;s.energy.gpu=hasPower?gpuPower:-1;
 s.energy.online=s.energy.total>=0||s.energy.cpu>=0||hasPower;
 auto root=query("storage.list");auto rows=root?field(root,"result"):nullptr;
 if(!cJSON_IsArray(rows)){fail(s,"storage.list indisponivel");}
 else if(cJSON_GetArraySize(rows)>int(MAX_ROWS)){fail(s,"Limite local: 32 montagens");}
 else {
  s.online=true;s.error[0]=0;s.count=0;
  cJSON* item=nullptr;cJSON_ArrayForEach(item,rows){
   Row& row=s.rows[s.count++];stringField(item,"path",row.mount,sizeof(row.mount));
   strlcpy(row.device,"--",sizeof(row.device));stringField(item,"fstype",row.fs,sizeof(row.fs));
   // LumiCore 0.1.0 exposes rounded GiB, not byte-level filesystem counters.
   row.total=number(item,"total_gb")*1073741824.0;row.used=number(item,"used_gb")*1073741824.0;
   row.free=row.available=row.total-row.used;row.percent=number(item,"usage_pct");
   row.valid=cJSON_IsObject(item)&&row.total>0&&row.used>=0&&row.used<=row.total&&row.percent>=0&&row.percent<=100;
  }
 }
 if(root)cJSON_Delete(root);
}
void worker(void*){
 unsigned previous=0;uint32_t finished=0;
 for(;;){
  unsigned version=session.load();
  if(enabled.load()&&(version!=previous||(uint32_t)(millis()-finished)>=2000)){
   std::unique_ptr<Snapshot> next(new(std::nothrow) Snapshot);
   if(next){
    fetch(*next);next->received=millis();
    xSemaphoreTake(mutex,portMAX_DELAY);
    if(enabled.load()&&session.load()==version)cached=*next;
    xSemaphoreGive(mutex);
   }
   previous=version;finished=millis();
  }
  vTaskDelay(pdMS_TO_TICKS(50));
 }
}
}
void start(){
 if(!mutex)mutex=xSemaphoreCreateMutex();
 if(!mutex)return;
 xSemaphoreTake(mutex,portMAX_DELAY);cached.gpus=Gpus();cached.energy=Energy();fail(cached,"A aguardar LumiCore");cached.received=millis();xSemaphoreGive(mutex);
 session.fetch_add(1);enabled=true;
 if(!task&&xTaskCreate(worker,"lumi-telemetry",8192,nullptr,1,&task)!=pdPASS){task=nullptr;enabled=false;}
}
void stop(){enabled=false;session.fetch_add(1);}
void read(unsigned requested,Page& out){
 out=Page();
 if(!mutex||!task){strlcpy(out.error,"Sem RAM para recolha",sizeof(out.error));return;}
 xSemaphoreTake(mutex,portMAX_DELAY);
 out.online=enabled.load()&&cached.online&&(uint32_t)(millis()-cached.received)<6500;
 strlcpy(out.error,cached.error,sizeof(out.error));
 if(out.online){
  out.total=cached.count;out.pages=max(1U,(out.total+2)/3);out.page=min(requested,out.pages-1);
  for(unsigned i=out.page*3;i<cached.count&&out.count<3;i++)out.rows[out.count++]=cached.rows[i];
 }else if(!out.error[0])strlcpy(out.error,"Telemetria expirada",sizeof(out.error));
 xSemaphoreGive(mutex);
}
void readEnergy(Energy& out){
 out=Energy();
 if(!mutex||!task){strlcpy(out.error,"Sem RAM para recolha",sizeof(out.error));return;}
 xSemaphoreTake(mutex,portMAX_DELAY);
 out=cached.energy;
 out.online=enabled.load()&&out.online&&(uint32_t)(millis()-cached.received)<6500;
 if(!out.online){
  out.cpu=out.gpu=out.total=out.limit=-1;
  if(!out.error[0])strlcpy(out.error,cached.energy.online?"Telemetria expirada":(cached.error[0]?cached.error:"Telemetria indisponivel"),sizeof(out.error));
 }
 xSemaphoreGive(mutex);
}

void readGpus(Gpus& out){
 out=Gpus();
 if(!mutex||!task){strlcpy(out.error,"Sem RAM para recolha",sizeof(out.error));return;}
 xSemaphoreTake(mutex,portMAX_DELAY);out=cached.gpus;
 out.online=enabled.load()&&out.online&&(uint32_t)(millis()-cached.received)<6500;
 if(!out.online){out.count=0;if(!out.error[0])strlcpy(out.error,cached.error[0]?cached.error:"Telemetria GPU expirada",sizeof(out.error));}
 xSemaphoreGive(mutex);
}

}
