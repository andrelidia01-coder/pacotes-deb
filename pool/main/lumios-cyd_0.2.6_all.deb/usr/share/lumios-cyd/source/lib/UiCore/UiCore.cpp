#include "UiCore.h"

#include "lumios_version.h"

namespace {
constexpr uint16_t BG = 0x0863;
constexpr uint16_t PANEL = 0x10E4;
constexpr uint16_t DIM = 0x8CB4;
constexpr uint16_t CYAN = 0x073F;
}

UiCore::UiCore(TFT_eSPI& tft) : tft_(tft) {}

void UiCore::boot() {
  tft_.fillScreen(BG);
  tft_.setTextDatum(MC_DATUM);
  tft_.setTextColor(CYAN, BG);
  tft_.drawString(LUMIOS_NAME, 160, 92, 4);
  tft_.setTextColor(TFT_WHITE, BG);
  tft_.drawString("Primeiro arranque", 160, 130, 2);
  tft_.setTextColor(DIM, BG);
  tft_.drawString("A verificar o armazenamento...", 160, 158, 2);
}

void UiCore::header(const char* title) {
  tft_.fillScreen(BG);
  tft_.fillRoundRect(5, 5, 310, 30, 6, PANEL);
  tft_.setTextDatum(ML_DATUM);
  tft_.setTextColor(CYAN, PANEL);
  tft_.drawString(title, 14, 20, 2);
  tft_.setTextDatum(MR_DATUM);
  tft_.setTextColor(DIM, PANEL);
  tft_.drawString(LUMIOS_VERSION, 306, 20, 2);
  tft_.fillRoundRect(5, 42, 310, 190, 7, PANEL);
}

void UiCore::row(int y, const char* label, const String& value, uint16_t color) {
  tft_.setTextDatum(ML_DATUM);
  tft_.setTextColor(DIM, PANEL);
  tft_.drawString(label, 14, y, 2);
  tft_.setTextDatum(MR_DATUM);
  tft_.setTextColor(color, PANEL);
  tft_.drawString(value, 306, y, 2);
}

String UiCore::sizeText(uint64_t bytes) const {
  if (!bytes) return "--";
  return String(static_cast<double>(bytes) / (1024.0 * 1024.0 * 1024.0), 2) + " GB";
}

void UiCore::storagePage(const SdReport& report) {
  header("ARMAZENAMENTO");
  String state = "Nao verificado";
  uint16_t stateColor = TFT_YELLOW;
  if (report.state == SdState::Ready) {
    state = "Detetado";
    stateColor = TFT_GREEN;
  } else if (report.state == SdState::Missing) {
    state = "Sem cartao";
    stateColor = TFT_ORANGE;
  } else if (report.state == SdState::MountError) {
    state = "Nao montado";
    stateColor = TFT_RED;
  }

  row(68, "Estado", state, stateColor);
  row(96, "Capacidade", sizeText(report.capacityBytes), TFT_WHITE);
  row(124, "Utilizado", sizeText(report.usedBytes), TFT_WHITE);
  row(152, "Modo", "Somente leitura", CYAN);

  button(174, "VERIFICAR NOVAMENTE", 0x21A6);
  if (report.state == SdState::Ready) button(210, "APAGAR E TESTAR", TFT_RED);
}

bool UiCore::retryPressed(int16_t x, int16_t y) const {
  return x >= 65 && x <= 255 && y >= 168 && y <= 205;
}

bool UiCore::destructivePressed(int16_t x, int16_t y) const {
  return x >= 65 && x <= 255 && y >= 204 && y <= 239;
}
bool UiCore::confirmPressed(int16_t x, int16_t y) const {
  return x >= 65 && x <= 255 && y >= 174 && y <= 224;
}
void UiCore::button(int y, const char* text, uint16_t color) {
  tft_.fillRoundRect(65, y, 190, 30, 6, color);
  tft_.setTextDatum(MC_DATUM);
  tft_.setTextColor(TFT_WHITE, color);
  tft_.drawString(text, 160, y + 15, 2);
}
void UiCore::eraseWarning(uint8_t step) {
  header(step == 1 ? "ATENCAO" : "CONFIRMACAO FINAL");
  tft_.setTextDatum(MC_DATUM);
  tft_.setTextColor(TFT_RED, PANEL);
  tft_.drawString("TODOS OS DADOS SERAO", 160, 76, 2);
  tft_.drawString("APAGADOS", 160, 103, 4);
  tft_.setTextColor(TFT_WHITE, PANEL);
  tft_.drawString(step == 1 ? "Teste completo + formatacao"
                            : "Nao desligar durante o teste",
                  160, 143, 2);
  button(184, step == 1 ? "CONTINUAR" : "CONFIRMAR E APAGAR", TFT_RED);
}
void UiCore::testProgress(SdTestPhase phase, uint8_t percent, uint32_t errors) {
  const char* names[] = {"A escrever", "A verificar", "A formatar", "A preparar"};
  static int8_t drawnPhase = -1;
  if (drawnPhase != static_cast<int8_t>(phase)) {
    drawnPhase = static_cast<int8_t>(phase);
    header("TESTE FISICO SD");
    tft_.setTextDatum(MC_DATUM);
    tft_.setTextColor(TFT_WHITE, PANEL);
    tft_.drawString(names[static_cast<uint8_t>(phase)], 160, 80, 4);
    tft_.fillRoundRect(18, 120, 284, 16, 5, 0x2945);
  }
  tft_.fillRoundRect(18, 120, 284, 16, 5, 0x2945);
  if (percent) tft_.fillRoundRect(18, 120, max(3, static_cast<int>(2.84f * percent)), 16, 5, TFT_GREEN);
  tft_.fillRect(105, 142, 110, 38, PANEL);
  tft_.setTextDatum(MC_DATUM);
  tft_.setTextColor(TFT_WHITE, PANEL);
  tft_.drawString(String(percent) + "%", 160, 160, 4);
  tft_.fillRect(105, 187, 110, 25, PANEL);
  tft_.setTextColor(DIM, PANEL);
  tft_.drawString("Erros: " + String(errors), 160, 201, 2);
}
void UiCore::testResult(SdTestResult result) {
  header("RESULTADO SD");
  const bool ok = result == SdTestResult::Passed;
  tft_.setTextDatum(MC_DATUM);
  tft_.setTextColor(ok ? TFT_GREEN : TFT_RED, PANEL);
  tft_.drawString(ok ? "SAUDAVEL" : "FALHOU", 160, 92, 4);
  tft_.setTextColor(TFT_WHITE, PANEL);
  tft_.drawString(ok ? "Preparado para LumiOS" : "Consulte o monitor serie", 160, 140, 2);
  button(184, "VOLTAR", 0x21A6);
}
