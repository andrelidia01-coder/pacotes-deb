#include "ServerCore.h"
#include <HTTPClient.h>
#include <WiFi.h>
#include "DeviceConfig.h"
#include <cJSON.h>
#include <Preferences.h>
#include <ESPmDNS.h>
#include <sys/time.h>
#include <time.h>
#include "TimeValidity.h"

void ServerCore::begin(){
  if(worker_)return;
  if(!messageLock_)messageLock_=xSemaphoreCreateMutex();
  if(!messageLock_){Serial.println("Health worker: sem mutex");return;}
  if(xTaskCreate(workerEntry,"lumi-health",6144,this,1,&worker_)!=pdPASS){
    worker_=nullptr;online_=false;Serial.println("Health worker: sem RAM");
  }
}
void ServerCore::workerEntry(void* context){
  auto self=static_cast<ServerCore*>(context);
  uint32_t lastFinished=0;bool first=true;bool offlineAfterShutdown=false;
  for(;;){
    if(self->shutdownPending_.exchange(false)) {
      self->performShutdown();
      vTaskDelay(pdMS_TO_TICKS(100));continue;
    }
    if(!self->wifi_.load()){
      self->online_=false;first=true;
    }else if(first||(uint32_t)(millis()-lastFinished)>=5000){
      // Resolve the private service by this mini-PC's Ethernet MAC, not its old IP.
      int found=MDNS.queryService("lumicore","tcp");
      for(int i=0;i<found;i++){
        String mac=MDNS.txt(i,"mac");mac.toLowerCase();
        String expected=DeviceConfig::mac();expected.toLowerCase();
        if(mac!=expected||MDNS.port(i)!=8765)continue;
        IPAddress ip=MDNS.IP(i);
        if(ip!=IPAddress(0,0,0,0))DeviceConfig::setEndpoint(ip.toString()+":8765");
        break;
      }
      bool healthy=self->checkHealth();
      if(self->shutdownState_.load()==2&&!healthy)offlineAfterShutdown=true;
      if(healthy&&offlineAfterShutdown){self->shutdownState_=0;offlineAfterShutdown=false;}
      self->online_=healthy&&self->wifi_.load()&&WiFi.status()==WL_CONNECTED;
      lastFinished=millis();first=false;
    }
    vTaskDelay(pdMS_TO_TICKS(100));
  }
}
namespace {
String stringField(cJSON* j,const char* key){auto v=cJSON_GetObjectItemCaseSensitive(j,key);return cJSON_IsString(v)?String(v->valuestring):String();}
cJSON* getJson(const char* path){HTTPClient h;h.setConnectTimeout(1500);h.setTimeout(3000);
 if(!h.begin(String("http://")+DeviceConfig::endpoint()+path))return nullptr;
 const char* headers[]={"Date"};h.collectHeaders(headers,1);
 int code=h.GET();int n=h.getSize();String body;
 if(code==200&&n>0&&n<=4096)body=h.getString();
 if(code==200&&!LumiTime::valid(time(nullptr))){
   int64_t epoch=LumiTime::httpDate(h.header("Date").c_str());
   if(LumiTime::valid(epoch)){
     struct timeval value;value.tv_sec=static_cast<time_t>(epoch);value.tv_usec=0;
     settimeofday(&value,nullptr);Serial.println("Clock: sincronizado pelo LumiCore");
   }
 }
 h.end();
 if(body.length()!=unsigned(n)||code!=200)return nullptr;
 return cJSON_Parse(body.c_str());}
bool compatible(cJSON* j){return j&&stringField(j,"product")=="LumiCore"&&(stringField(j,"version").startsWith("0.2.")||stringField(j,"version")=="0.1.0");}
}
bool ServerCore::compatibleEndpoint(){
 auto identity=getJson("/v1/system");bool valid=compatible(identity);if(identity)cJSON_Delete(identity);
 return valid;
}
bool ServerCore::checkHealth(){
 if(!compatibleEndpoint())return false;
 auto health=getJson("/v1/health");
 bool ok=health&&stringField(health,"product")=="LumiCore"&&cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(health,"ok"));
 if(health)cJSON_Delete(health);return ok;
}
String ServerCore::systemInfo(){
 Preferences p;p.begin("lumi-system",false);String cached=p.getString("about","Sem identidade LumiCore");
 auto j=WiFi.status()==WL_CONNECTED?getJson("/v1/system"):nullptr;
 if(compatible(j)){
  String info=stringField(j,"hostname")+" | "+stringField(j,"instance")+"\nLumiCore "+stringField(j,"version")+"\n"+stringField(j,"os")+"\n"+stringField(j,"board_name");
  if(info!=cached)p.putString("about",info);cached=info;
 }else cached="Offline / incompativel\n"+cached;
 if(j)cJSON_Delete(j);p.end();return cached;
}
void ServerCore::update(bool wifi){
  // Called by the UI loop: never perform network I/O here.
  wifi_=wifi;if(!wifi)online_=false;
}
bool ServerCore::shutdown(){
 if(shutdownState_.load()==1||shutdownState_.load()==2)return true;
 if(!worker_||!online()||WiFi.status()!=WL_CONNECTED){
   setShutdownMessage("LumiCore offline / rede indisponivel");shutdownState_=3;return false;
 }
 if(DeviceConfig::controlKey().isEmpty()){
   setShutdownMessage("Chave ausente: repetir setup USB");shutdownState_=3;return false;
 }
 setShutdownMessage("A aguardar resposta do LumiCore");
 shutdownState_=1;shutdownPending_=true;return true;
}
void ServerCore::setShutdownMessage(const String& value){
 if(messageLock_)xSemaphoreTake(messageLock_,portMAX_DELAY);
 shutdownMessage_=value;
 if(messageLock_)xSemaphoreGive(messageLock_);
}
String ServerCore::shutdownMessage(){
 if(messageLock_)xSemaphoreTake(messageLock_,portMAX_DELAY);
 String value=shutdownMessage_;
 if(messageLock_)xSemaphoreGive(messageLock_);
 return value;
}
void ServerCore::performShutdown(){
 HTTPClient h;h.setConnectTimeout(1500);h.setTimeout(12000);
 if(!h.begin(String("http://")+DeviceConfig::endpoint()+"/v1/run")){
   setShutdownMessage("Endereco LumiCore invalido");shutdownState_=3;return;
 }
 h.addHeader("Content-Type","application/json");
 h.addHeader("X-Hipervisor-Key",DeviceConfig::controlKey());
 int code=h.POST("{\"command\":\"server.shutdown\",\"args\":{\"confirm\":true}}");
 int n=h.getSize();String body=code==200&&n>0&&n<=2048?h.getString():String();h.end();
 auto j=cJSON_Parse(body.c_str());auto result=j?cJSON_GetObjectItemCaseSensitive(j,"result"):nullptr;
 bool ok=code==200&&stringField(result,"scheduled")=="poweroff";
 String message;
 if(ok)message="Encerramento confirmado pelo LumiCore";
 else if(code==401||code==403)message="Chave recusada: repetir setup USB";
 else if(code<=0)message="Sem resposta; verificar estado do servidor";
 else {
   message="HTTP "+String(code);
   String reason=stringField(j,"error");
   if(reason.length()>0&&reason.length()<64)message+=" "+reason;
 }
 Serial.printf("Shutdown: HTTP %d; scheduled=%s\n",code,ok?"true":"false");
 if(j)cJSON_Delete(j);
 setShutdownMessage(message);shutdownState_=ok?2:3;
}


bool ServerCore::recoveryAction(const String& command,String& message){
  const char* allowed[]={"recovery.enter","backup.create","backup.restore","storage.partition","system.restore","factory.reset"};
  bool valid=false;for(const char* item:allowed)if(command==item){valid=true;break;}
  if(!valid){message="Acao invalida";return false;}
  if(!online()||WiFi.status()!=WL_CONNECTED){message="LumiCore offline / rede indisponivel";return false;}
  if(DeviceConfig::controlKey().isEmpty()){message="Chave ausente: repetir setup USB";return false;}
  HTTPClient h;h.setConnectTimeout(1800);h.setTimeout(8000);
  if(!h.begin(String("http://")+DeviceConfig::endpoint()+"/v1/run")){message="Endereco LumiCore invalido";return false;}
  h.addHeader("Content-Type","application/json");h.addHeader("X-Hipervisor-Key",DeviceConfig::controlKey());
  String body="{\"command\":\""+command+"\",\"args\":{\"confirm\":true}}";
  int code=h.POST(body);String response=code==200?h.getString():String();h.end();
  cJSON* j=cJSON_Parse(response.c_str());cJSON* result=j?cJSON_GetObjectItemCaseSensitive(j,"result"):nullptr;
  bool ok=code==200&&result!=nullptr&&!cJSON_IsNull(result);
  if(ok){cJSON* m=cJSON_GetObjectItemCaseSensitive(result,"message");cJSON* status=cJSON_GetObjectItemCaseSensitive(result,"status");if(cJSON_IsString(m))message=String(m->valuestring);else if(cJSON_IsString(status))message=String(status->valuestring);else message="Pedido recebido; verificar estado no servidor";}
  else if(code==401||code==403)message="Chave recusada";
  else if(code>0){cJSON* e=j?cJSON_GetObjectItemCaseSensitive(j,"error"):nullptr;message=cJSON_IsString(e)?String(e->valuestring):("HTTP "+String(code)+"; acao nao suportada?");}
  else message="Sem resposta do servidor";
  if(message.length()>60)message=message.substring(0,57)+"...";if(j)cJSON_Delete(j);return ok;
}
