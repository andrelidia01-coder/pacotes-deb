#include "OtaCore.h"
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <WiFi.h>
#include <Update.h>
#include <cJSON.h>
#include <mbedtls/sha256.h>
#include <time.h>
#include "github_ca.h"
#include "device_defaults.h"
#include "lumios_version.h"

namespace {
String field(cJSON* j,const char* key){auto v=cJSON_GetObjectItemCaseSensitive(j,key);return cJSON_IsString(v)?String(v->valuestring):String();}
bool firmwareUrl(const String& url){
 const String base="https://github.com/andrelidia01-coder/pacotes-deb/releases/download/";
 return url.startsWith(base)&&url.endsWith("/firmware.bin")&&url.indexOf("..")<0&&url.indexOf('?')<0;
}
}
bool OtaCore::install(){
 if(WiFi.status()!=WL_CONNECTED){message_="Wi-Fi indisponivel";return false;}
 // TLS needs a valid clock. Never disable certificate validation.
 uint32_t clockStart=millis();while(time(nullptr)<1735689600&&millis()-clockStart<10000){delay(100);}
 if(time(nullptr)<1735689600){message_="Sem hora NTP para HTTPS";return false;}
 WiFiClientSecure client;client.setCACert(GITHUB_ROOT_CA);client.setTimeout(15000);
 HTTPClient http;http.setConnectTimeout(10000);http.setTimeout(15000);
 http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
 if(!http.begin(client,LUMIOS_OTA_MANIFEST)){message_="URL OTA invalido";return false;}
 int status=http.GET(),length=http.getSize();
 if(status!=200||length<=0||length>2048){http.end();message_="Manifesto OTA indisponivel";return false;}
 String body=http.getString();http.end();client.stop();
 if(body.length()!=unsigned(length)){message_="Manifesto incompleto";return false;}
 // Bound nesting before parser allocation.
 int depth=0;bool quoted=false,escaped=false;
 for(unsigned i=0;i<body.length();i++){char c=body[i];if(quoted){if(escaped)escaped=false;else if(c=='\\')escaped=true;else if(c=='"')quoted=false;}else if(c=='"')quoted=true;else if(c=='{'||c=='['){if(++depth>4){message_="Manifesto complexo";return false;}}else if(c=='}'||c==']'){if(--depth<0){message_="Manifesto invalido";return false;}}}
 if(depth||quoted){message_="Manifesto invalido";return false;}
 auto j=cJSON_Parse(body.c_str());if(!j){message_="JSON OTA invalido";return false;}
 auto build=cJSON_GetObjectItemCaseSensitive(j,"build"),sz=cJSON_GetObjectItemCaseSensitive(j,"size");
 String url=field(j,"url"),hash=field(j,"sha256");
 bool valid=field(j,"product")=="LumiOS"&&field(j,"target")==LUMIOS_OTA_TARGET&&field(j,"lumicore")=="0.1.0"&&
  cJSON_IsNumber(build)&&build->valuedouble==build->valueint&&build->valueint>0&&
  cJSON_IsNumber(sz)&&sz->valuedouble==sz->valueint&&sz->valueint>0&&sz->valueint<=0x1D0000&&firmwareUrl(url)&&hash.length()==64;
 for(unsigned i=0;i<hash.length();i++)if(!isxdigit(hash[i]))valid=false;
 int next=cJSON_IsNumber(build)?build->valueint:0,bytes=cJSON_IsNumber(sz)?sz->valueint:0;cJSON_Delete(j);
 if(!valid){message_="Firmware incompativel/invalido";return false;}
 if(next<=LUMIOS_BUILD_NUMBER){message_="LumiOS ja atualizado";return false;}
 hash.toLowerCase();
 if(!http.begin(client,url)){message_="URL firmware invalido";return false;}
 http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
 status=http.GET();length=http.getSize();
 if(status!=200||length!=bytes){http.end();message_="Tamanho firmware incorreto";return false;}
 if(!Update.begin(bytes,U_FLASH)){http.end();message_="Sem particao OTA disponivel";return false;}
 mbedtls_sha256_context sha;mbedtls_sha256_init(&sha);mbedtls_sha256_starts_ret(&sha,0);
 uint8_t buf[1024];size_t received=0;bool ok=true;uint32_t lastData=millis();auto stream=http.getStreamPtr();
 while(received<unsigned(bytes)){
  int available=stream->available();if(available>0){
   size_t want=min(sizeof(buf),min(size_t(available),size_t(bytes)-received));int n=stream->read(buf,want);
   if(n<=0){ok=false;break;}
   mbedtls_sha256_update_ret(&sha,buf,n);
   if(Update.write(buf,n)!=unsigned(n)){ok=false;break;}
   received+=n;lastData=millis();
  }else if(!http.connected()||millis()-lastData>15000){ok=false;break;}
  delay(1);
 }
 uint8_t digest[32];mbedtls_sha256_finish_ret(&sha,digest);mbedtls_sha256_free(&sha);http.end();client.stop();
 char actual[65];for(unsigned i=0;i<32;i++)snprintf(actual+i*2,3,"%02x",digest[i]);actual[64]=0;
 if(!ok||received!=unsigned(bytes)||hash!=actual){Update.abort();message_="Firmware incompleto / SHA256";return false;}
 // Only select the new OTA slot after full size + digest verification.
 if(!Update.end(false)||!Update.isFinished()){Update.abort();message_="Falha ao validar firmware";return false;}
 message_="Atualizacao instalada";delay(300);ESP.restart();return true;
}
