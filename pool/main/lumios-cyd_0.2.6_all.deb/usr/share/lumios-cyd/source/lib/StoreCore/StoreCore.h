#pragma once
#include <Arduino.h>
#include <SdFat.h>
#include <TFT_eSPI.h>
struct StoreEntry { String id,name,path,icon; bool requiresServer=false; uint16_t* iconPixels=nullptr; };
class StoreCore {
 public:
 static constexpr unsigned MAX_APPS=48;
 StoreEntry entries[MAX_APPS]; unsigned count=0;
 uint64_t used=0,total=0; String message; bool mounted=false;
 bool mount(); void unmount(); bool refresh();
 bool install(const String& file);
 String packages[64]; unsigned packageCount=0; bool packageLimit=false;
 bool scanPackages();
 bool uninstallApp(unsigned index);
 bool deletePackage(const String& file);
 bool readScript(unsigned index,String& source);
 // Caller owns the mounted SD session. Extract only the package icon.
 bool cachePackageIcon(const String& filename,const String& destination);
 bool drawIcon(unsigned index,TFT_eSPI& tft,int x,int y);
 SdFat32 sd;
 private:
 bool manifest(const String& path,StoreEntry& out);
 bool prune(const String& path,unsigned depth=0);
};
