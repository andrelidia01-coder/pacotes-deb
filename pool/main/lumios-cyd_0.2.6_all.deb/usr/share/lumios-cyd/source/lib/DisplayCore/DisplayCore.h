#pragma once

#include <Arduino.h>
#include <TFT_eSPI.h>

class DisplayCore {
 public:
  void begin();
  void setOrientation(uint16_t degrees);
  uint16_t orientation() const { return orientation_; }
  TFT_eSPI& tft();
  void setBacklight(uint8_t level);

 private:
  TFT_eSPI display_;
  uint16_t orientation_ = 0;
};
