#include "SdShareCore.h"
#include "PackageRules.h"
#include <WiFi.h>

namespace {
String htmlEscape(String s){s.replace("&","&amp;");s.replace("<","&lt;");s.replace(">","&gt;");s.replace("\"","&quot;");s.replace("'","&#39;");return s;}
const char* INDEX="/.html/index.html";
const char* TEMP="/.html/index.tmp";
const char* BACKUP="/.html/index.bak";
const char* HEAD=R"HTML(<!doctype html><html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Lumi Store - Build 11</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#09131e;color:#e9f2fa;font:15px system-ui,sans-serif}main{max-width:1100px;margin:auto;padding:28px 20px}h1{margin:0;color:#70dfed;font-size:28px}h2{font-size:19px;margin:30px 0 16px}p{color:#a9bbc9;line-height:1.5}.top{display:flex;align-items:center;justify-content:space-between}.build{border:1px solid #385168;border-radius:16px;padding:5px 12px;color:#bed2e0}.upload{display:flex;flex-wrap:wrap;gap:12px;padding:18px;margin-top:22px;background:#132537;border-radius:12px}.notice{padding:12px 16px;border-left:3px solid #70dfed;background:#132537}.scroll{overflow-x:auto}.grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:14px;min-width:740px}.card{background:#122334;border:1px solid #294156;border-radius:12px;text-align:center;padding:18px 12px;min-width:0}.icon{width:56px;height:56px;margin:auto;display:grid;place-items:center;background:#1e374b;border-radius:12px}.icon img{width:32px;height:32px;object-fit:contain}.placeholder{font-size:12px;color:#8bd8e5}.name{font-weight:650;overflow-wrap:anywhere;min-height:44px;margin:14px 0 4px}.meta{font-size:12px;color:#9bb3c5;min-height:22px}.actions{display:flex;flex-direction:column;gap:8px;margin-top:12px}button{cursor:pointer;border:0;border-radius:7px;padding:9px 12px;font:inherit;color:#fff;background:#226eac}button:hover{filter:brightness(1.15)}button.danger{background:#572c37;color:#ffcad2}button.secondary{background:#334c60}form{margin:0}.actions button{width:100%}footer{border-top:1px solid #294156;margin-top:28px;padding-top:14px;font-size:13px;color:#9bb3c5}input{max-width:100%}
</style></head><body><main><div class="top"><h1>Lumi Store</h1><span class="build">Build 11</span></div><p>Aplicações no cartão SD</p>)HTML";
String hidden(const char* key,const String& value){return String("<input type='hidden' name='")+key+"' value='"+htmlEscape(value)+"'>";}
String iconTag(const String& name,bool available){
 return available?String("<div class='icon'><img alt='' src='/sd-icon?name=")+name+"'></div>":String("<div class='icon'><span class='placeholder'>APP</span></div>");
}
}

SdShareCore::SdShareCore():web_(80){}
bool SdShareCore::packageName(const String& n)const{
 return PackageRules::path(n.c_str())&&n.indexOf('/')<0&&(n.endsWith(".app")||n.endsWith(".zip"));
}
bool SdShareCore::start(bool wifi,bool ready){
 if(active_)return true;if(!wifi||!ready||!store_)return false;
 token_=String(esp_random(),HEX)+String(esp_random(),HEX);status_="";dirty_=true;
 if(!configured_){
  web_.on("/sd",HTTP_GET,[this](){page();});
  web_.on("/sd-icon",HTTP_GET,[this](){image();});
  web_.on("/upload",HTTP_POST,[this](){result();},[this](){upload();});
  web_.on("/install",HTTP_POST,[this](){
   if(!authorized()){web_.send(403,"text/plain","Sessao invalida");return;}
   store_->install(web_.arg("file"));status_=store_->message;dirty_=true;result();
  });
  web_.on("/delete",HTTP_POST,[this](){
   if(!authorized()){web_.send(403,"text/plain","Sessao invalida");return;}
   deletePackage(web_.arg("file"));dirty_=true;result();
  });
  web_.on("/remove",HTTP_POST,[this](){
   if(!authorized()){web_.send(403,"text/plain","Sessao invalida");return;}
   String id=web_.arg("id");bool ok=false;
   if(PackageRules::id(id.c_str())&&store_->mount()){
    store_->sd.mkdir("/LumiOS/trash");String dest="/LumiOS/trash/"+id+"-"+String(esp_random(),HEX)+".app";
    ok=!store_->sd.exists(dest.c_str())&&store_->sd.rename(("/LumiOS/apps/"+id+".app").c_str(),dest.c_str());
    if(ok)store_->sd.remove(("/.html/installed-"+id+".png").c_str());
    store_->unmount();
   }
   status_=ok?"Aplicacao desinstalada. Copia recuperavel em /LumiOS/trash.":"Nao foi possivel desinstalar.";
   dirty_=true;result();
  });
  web_.onNotFound([this](){web_.sendHeader("Location","/sd");web_.send(303);});configured_=true;
 }
 rebuild();web_.begin();active_=true;return true;
}
void SdShareCore::stop(){
 if(upload_){upload_.close();if(store_&&store_->mounted&&uploadTemp_.length())store_->sd.remove(uploadTemp_.c_str());}
 if(store_)store_->unmount();web_.stop();active_=false;dirty_=true;
}
void SdShareCore::loop(){if(active_)web_.handleClient();}
bool SdShareCore::write(File32& f,const String& s){return f.write((const uint8_t*)s.c_str(),s.length())==s.length();}

bool SdShareCore::copyIcon(const String& from,const String& to){
 File32 in=store_->sd.open(from.c_str(),O_RDONLY);uint8_t buf[512];
 static const uint8_t sig[8]={137,80,78,71,13,10,26,10};
 if(!in||in.fileSize()<33||in.fileSize()>65536||in.read(buf,24)!=24||memcmp(buf,sig,8)||
    memcmp(buf+8,"\0\0\0\rIHDR",8)||memcmp(buf+16,"\0\0\0\x20\0\0\0\x20",8)){
  in.close();store_->sd.remove(to.c_str());return false;
 }
 String temp=to+".tmp";File32 out=store_->sd.open(temp.c_str(),O_WRONLY|O_CREAT|O_TRUNC);
 bool ok=out&&in.seekSet(0);int n=0;
 while(ok&&(n=in.read(buf,sizeof(buf)))>0){ok=out.write(buf,n)==(size_t)n;yield();}
 ok=ok&&n>=0&&out.sync();in.close();out.close();
 if(ok&&store_->sd.exists(to.c_str()))ok=store_->sd.remove(to.c_str());
 if(ok)ok=store_->sd.rename(temp.c_str(),to.c_str());
 if(!ok){store_->sd.remove(temp.c_str());store_->sd.remove(to.c_str());}return ok;
}
bool SdShareCore::rebuild(){
 dirty_=true;if(!store_->refresh()||!store_->mount())return false;
 auto& sd=store_->sd;
 if(!sd.exists("/.html")&&!sd.mkdir("/.html")){store_->unmount();return false;}
 File32 html=sd.open(TEMP,O_WRONLY|O_CREAT|O_TRUNC);if(!html){store_->unmount();return false;}
 bool ok=write(html,HEAD);
 ok=ok&&write(html,"<form class='upload' method='POST' action='/upload?token="+token_+"' enctype='multipart/form-data'><input type='file' name='file' accept='.app,.zip' required><button>Carregar aplicacao</button></form>");
 if(status_.length())ok=ok&&write(html,"<p class='notice' role='status'>"+htmlEscape(status_)+"</p>");
 ok=ok&&write(html,"<h2>Pacotes disponíveis</h2><div class='scroll'><div class='grid'>");
 File32 dir=sd.open("/LumiOS/uploads",O_RDONLY),f;char name[128];unsigned packages=0;
 while(ok&&dir&&f.openNext(&dir,O_RDONLY)){
  bool regular=!f.isDir();f.getName(name,sizeof(name));uint32_t bytes=f.fileSize();f.close();String filename=name;
  if(!regular||!packageName(filename))continue;
  String cached="pkg-"+filename+".png";bool hasIcon=store_->cachePackageIcon(filename,"/.html/"+cached);
  String card="<article class='card'>"+iconTag(cached,hasIcon)+"<div class='name'>"+htmlEscape(filename)+"</div><div class='meta'>"+String((bytes+1023)/1024)+" KiB</div><div class='actions'>";
  card+="<form method='POST' action='/install'>"+hidden("token",token_)+hidden("file",filename)+"<button>Instalar</button></form>";
  card+="<form method='POST' action='/delete' onsubmit='return confirm(\"Apagar definitivamente este pacote e o icone temporario?\")'>"+hidden("token",token_)+hidden("file",filename)+"<button class='danger'>Apagar</button></form></div></article>";
  ok=write(html,card);++packages;yield();
 }
 dir.close();ok=ok&&write(html,"</div></div>");
 if(!packages)ok=ok&&write(html,"<p>Nenhum pacote carregado.</p>");
 ok=ok&&write(html,"<h2>Aplicações instaladas</h2><div class='scroll'><div class='grid'>");
 for(unsigned i=0;ok&&i<store_->count;i++){
  const auto& e=store_->entries[i];String cached="installed-"+e.id+".png";
  bool hasIcon=copyIcon(e.path+"/icon.png","/.html/"+cached);
  String card="<article class='card'>"+iconTag(cached,hasIcon)+"<div class='name'>"+htmlEscape(e.name)+"</div><div class='meta'>Instalada</div><div class='actions'>";
  card+="<form method='POST' action='/remove' onsubmit='return confirm(\"Desinstalar esta aplicacao?\")'>"+hidden("token",token_)+hidden("id",e.id)+"<button class='secondary'>Desinstalar</button></form></div></article>";
  ok=write(html,card);
 }
 ok=ok&&write(html,"</div></div>");
 if(!store_->count)ok=ok&&write(html,"<p>Nenhuma aplicação instalada.</p>");
 ok=ok&&write(html,"<footer>Apagar elimina o pacote enviado e o seu icone temporario. A copia instalada permanece.<br>Desinstalar move a copia instalada para /LumiOS/trash.<br>Saia da partilha no CYD para voltar ao launcher.</footer></main></body></html>");
 ok=ok&&html.sync();html.close();
 if(ok&&sd.exists(INDEX)){
  if(sd.exists(BACKUP))ok=sd.remove(BACKUP);
  if(ok)ok=sd.rename(INDEX,BACKUP);
 }
 if(ok){ok=sd.rename(TEMP,INDEX);if(!ok&&sd.exists(BACKUP)&&!sd.exists(INDEX))sd.rename(BACKUP,INDEX);}
 if(ok){if(sd.exists(BACKUP))sd.remove(BACKUP);dirty_=false;}else if(sd.exists(TEMP))sd.remove(TEMP);
 store_->unmount();return ok;
}
bool SdShareCore::sendFile(const String& path,const char* mime){
 if(!store_->mount())return false;File32 f=store_->sd.open(path.c_str(),O_RDONLY);
 if(!f||f.isDir()){f.close();store_->unmount();return false;}
 uint32_t remaining=f.fileSize();web_.sendHeader("Cache-Control","no-store");web_.sendHeader("X-Content-Type-Options","nosniff");
 web_.setContentLength(remaining);web_.send(200,mime,"");char buf[1024];
 while(remaining){int n=f.read(buf,min((uint32_t)sizeof(buf),remaining));if(n<=0)break;web_.sendContent(buf,n);remaining-=n;yield();}
 if(remaining)web_.client().stop();f.close();store_->unmount();return true;
}
void SdShareCore::page(){
 if(dirty_&&!rebuild()){web_.send(503,"text/plain","Nao foi possivel gerar /.html/index.html. Verifique o SD e o espaco livre.");return;}
 if(!sendFile(INDEX,"text/html; charset=utf-8")){dirty_=true;web_.send(503,"text/plain","SD ou index.html indisponivel");}
}
void SdShareCore::image(){
 String n=web_.arg("name");
 if(!n.length()||n.length()>160||n.indexOf('/')>=0||n.indexOf('\\')>=0||
    !(n.startsWith("pkg-")||n.startsWith("installed-"))||!n.endsWith(".png")){
  web_.send(404,"text/plain","Icone indisponivel");return;
 }
 for(unsigned i=0;i<n.length();i++){char c=n[i];if(!isalnum((unsigned char)c)&&c!='-'&&c!='_'&&c!='.'){web_.send(404,"text/plain","Icone indisponivel");return;}}
 if(!sendFile("/.html/"+n,"image/png"))web_.send(404,"text/plain","Icone indisponivel");
}
void SdShareCore::result(){
 if(dirty_&&!rebuild()){
  web_.send(503,"text/plain",status_+"\nNao foi possivel atualizar o HTML no SD. Reabra /sd para tentar novamente.");return;
 }
 web_.sendHeader("Location","/sd");web_.send(303,"text/plain",status_);
}
bool SdShareCore::deletePackage(const String& name){
 if(!packageName(name)){status_="Nome de pacote invalido.";return false;}
 if(!store_->mount()){status_="SD indisponivel.";return false;}
 String path="/LumiOS/uploads/"+name,icon="/.html/pkg-"+name+".png";
 File32 f=store_->sd.open(path.c_str(),O_RDONLY);bool regular=f&&!f.isDir();f.close();
 bool ok=regular&&store_->sd.remove(path.c_str());
 if(ok){bool removed=!store_->sd.exists(icon.c_str())||store_->sd.remove(icon.c_str());
  String temp=icon+".tmp";removed=(!store_->sd.exists(temp.c_str())||store_->sd.remove(temp.c_str()))&&removed;
  status_=removed?"Pacote e icone temporario apagados definitivamente.":"Pacote apagado; falha ao apagar o icone temporario.";
 }else status_="Nao foi possivel apagar o pacote.";
 store_->unmount();return ok;
}
void SdShareCore::upload(){
 HTTPUpload& u=web_.upload();
 if(u.status==UPLOAD_FILE_START){
  uploadOk_=false;status_="Falha no upload";uploadTemp_="";uploadPath_="";
  if(!authorized()){status_="Sessao invalida";return;}
  if(!packageName(u.filename)){status_="Nome ou extensao invalida";return;}
  if(!store_->mount())return;
  store_->sd.mkdir("/LumiOS");store_->sd.mkdir("/LumiOS/uploads");uploadPath_="/LumiOS/uploads/"+u.filename;
  if(store_->sd.exists(uploadPath_.c_str())){status_="Ficheiro ja existe. Apague o pacote anterior ou escolha outro nome.";store_->unmount();return;}
  uploadTemp_=String("/LumiOS/uploads/upload-")+String(esp_random(),HEX)+".part";
  upload_=store_->sd.open(uploadTemp_.c_str(),O_WRONLY|O_CREAT|O_EXCL);uploadOk_=(bool)upload_;
 }else if(u.status==UPLOAD_FILE_WRITE){
  if(!upload_||!uploadOk_)return;
  if(upload_.fileSize()+u.currentSize>4*1024*1024||upload_.write(u.buf,u.currentSize)!=u.currentSize){uploadOk_=false;status_="Limite de 4 MiB ou erro de escrita";}
 }else if(u.status==UPLOAD_FILE_END||u.status==UPLOAD_FILE_ABORTED){
  if(upload_){uploadOk_=uploadOk_&&u.status==UPLOAD_FILE_END&&upload_.sync();upload_.close();}else uploadOk_=false;
  if(uploadOk_)uploadOk_=store_->sd.rename(uploadTemp_.c_str(),uploadPath_.c_str());
  if(!uploadOk_&&uploadTemp_.length()&&store_->mounted)store_->sd.remove(uploadTemp_.c_str());
  if(uploadOk_)status_="Pacote carregado. Escolha Instalar para o adicionar ao launcher.";
  store_->unmount();dirty_=true;
 }
}
