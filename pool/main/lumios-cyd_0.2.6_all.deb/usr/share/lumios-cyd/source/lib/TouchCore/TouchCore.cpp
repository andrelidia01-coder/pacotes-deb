#include "TouchCore.h"

#include <SPI.h>

#include "hardware_pins.h"

TouchCore::TouchCore()
    : touch_(HardwarePins::TOUCH_CS, HardwarePins::TOUCH_IRQ) {}

void TouchCore::begin() {
  // Configure the CYD touch SPI bus before initializing the XPT2046.
  // This is the sequence validated by LumiOS Touch Diagnostic.
  restoreBus();
  pinMode(HardwarePins::TOUCH_IRQ, INPUT);
  touch_.begin();
  touch_.setRotation(1);
}

void TouchCore::restoreBus() {
  SPI.end();
  SPI.begin(HardwarePins::TOUCH_SCLK, HardwarePins::TOUCH_MISO,
            HardwarePins::TOUCH_MOSI, HardwarePins::TOUCH_CS);
  pinMode(HardwarePins::TOUCH_CS, OUTPUT);
  digitalWrite(HardwarePins::TOUCH_CS, HIGH);
}

bool TouchCore::read(TouchPoint& point) {
  if (!touch_.touched() || millis() - lastTouchMs_ < 180) return false;
  TS_Point raw = touch_.getPoint();
  lastTouchMs_ = millis();
  const int16_t lx = constrain(map(raw.x, 200, 3900, 0, 320), 0, 319);
  const int16_t ly = constrain(map(raw.y, 200, 3900, 0, 240), 0, 239);
  // TFT_eSPI goes from rotation 1 (landscape) to rotation 2 (portrait).
  // In that transition (x, y) becomes (y, 319-x). The old code applied
  // the inverse transformation, sending touches to the opposite control.
  if (orientation_ == 90) { point.x = ly; point.y = 319 - lx; }
  else if (orientation_ == 180) { point.x = 319 - lx; point.y = 239 - ly; }
  else if (orientation_ == 270) { point.x = 239 - ly; point.y = lx; }
  else { point.x = lx; point.y = ly; }
  point.pressure = raw.z;
  return true;
}
