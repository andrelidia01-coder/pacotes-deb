#pragma once

#include <Arduino.h>
#include <XPT2046_Touchscreen.h>

struct TouchPoint {
  int16_t x = 0;
  int16_t y = 0;
  int16_t pressure = 0;
};

class TouchCore {
 public:
  TouchCore();
  void begin();
  void setOrientation(uint16_t degrees) { orientation_ = (degrees / 90 * 90) % 360; }
  void restoreBus();
  bool read(TouchPoint& point);
  bool pressed() { return touch_.touched(); }

 private:
  XPT2046_Touchscreen touch_;
  uint32_t lastTouchMs_ = 0;
  uint16_t orientation_ = 0;
};
