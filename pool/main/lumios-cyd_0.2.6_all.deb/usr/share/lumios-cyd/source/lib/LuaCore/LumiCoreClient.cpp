#include "LumiCoreClient.h"
#include "ServerCore.h"
#include <Arduino.h>
#include <HTTPClient.h>
#include <WiFi.h>
#include <cJSON.h>
#include <atomic>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>

namespace LumiCoreClient { namespace {
struct Snapshot {
 double gpuTemp=-1,gpuPower=-1,cpuTemp=-1,wallPower=-1;
 char profile[24]="--",error[64]="A aguardar servidor";
 uint32_t updated=0;
};
SemaphoreHandle_t mutex=nullptr;
TaskHandle_t task=nullptr;
std::atomic<bool> enabled{false};
Snapshot cached;

bool query(const char* name,double* number,char* label,size_t labelSize){
 HTTPClient http;http.setConnectTimeout(700);http.setTimeout(1100);
 if(!http.begin(String("http://")+ServerCore().endpoint()+"/v1/run"))return false;
 http.addHeader("Content-Type","application/json");
 char body[96];snprintf(body,sizeof(body),"{\"command\":\"%s\",\"args\":{}}",name);
 int status=http.POST((uint8_t*)body,strlen(body));
 int length=http.getSize();
 if(status!=200||length<=0||length>192){http.end();return false;}
 String response=http.getString();http.end();
 if(response.length()!=unsigned(length))return false;
 cJSON* root=cJSON_Parse(response.c_str());
 cJSON* value=root?cJSON_GetObjectItemCaseSensitive(root,"result"):nullptr;
 bool valid=false;
 if(number&&cJSON_IsNumber(value)){*number=value->valuedouble;valid=true;}
 if(label&&cJSON_IsString(value)&&strlen(value->valuestring)<labelSize){strlcpy(label,value->valuestring,labelSize);valid=true;}
 if(root)cJSON_Delete(root);
 return valid;
}
void worker(void*){
 for(;;){
  if(enabled.load()){
   Snapshot next;
   bool ok=WiFi.status()==WL_CONNECTED && ServerCore::compatibleEndpoint() &&
           query("gpu.profile",nullptr,next.profile,sizeof(next.profile));
   if(ok){
    query("gpu.temp",&next.gpuTemp,nullptr,0);
    query("gpu.power",&next.gpuPower,nullptr,0);
    query("cpu.temp",&next.cpuTemp,nullptr,0);
    query("power.wall",&next.wallPower,nullptr,0);
   }
   strlcpy(next.error,ok?"":"LumiCore indisponivel",sizeof(next.error));
   if(ok)next.updated=millis();
   xSemaphoreTake(mutex,portMAX_DELAY);if(enabled.load())cached=next;xSemaphoreGive(mutex);
  }
  vTaskDelay(pdMS_TO_TICKS(2000));
 }
}
int start(lua_State* L){
 if(!mutex)mutex=xSemaphoreCreateMutex();
 if(!mutex){lua_pushboolean(L,0);return 1;}
 if(!task&&xTaskCreate(worker,"lumi-lumicore",6144,nullptr,1,&task)!=pdPASS)task=nullptr;
 enabled=task!=nullptr;lua_pushboolean(L,enabled.load());return 1;
}
int read(lua_State* L){
 Snapshot data;
 if(mutex){xSemaphoreTake(mutex,portMAX_DELAY);data=cached;xSemaphoreGive(mutex);}
 lua_newtable(L);
 bool fresh=enabled.load()&&data.updated&&millis()-data.updated<8000;
 lua_pushboolean(L,fresh);lua_setfield(L,-2,"online");
 lua_pushstring(L,data.error);lua_setfield(L,-2,"error");
 lua_pushstring(L,data.profile);lua_setfield(L,-2,"profile");
 auto metric=[&](const char* key,double value){if(fresh&&value>=0)lua_pushnumber(L,value);else lua_pushnil(L);lua_setfield(L,-2,key);};
 metric("gpu_temp",data.gpuTemp);metric("gpu_power",data.gpuPower);
 metric("cpu_temp",data.cpuTemp);metric("wall_power",data.wallPower);
 return 1;
}
}
void stop(){enabled=false;if(mutex){xSemaphoreTake(mutex,portMAX_DELAY);cached=Snapshot();xSemaphoreGive(mutex);}}
void install(lua_State* L){const luaL_Reg api[]={{"start",start},{"read",read},{nullptr,nullptr}};luaL_newlib(L,api);lua_setglobal(L,"lumicore");}
}
