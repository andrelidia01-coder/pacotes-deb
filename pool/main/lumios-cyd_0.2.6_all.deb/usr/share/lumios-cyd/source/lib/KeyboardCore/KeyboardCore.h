#pragma once

#include <Arduino.h>
#include <TFT_eSPI.h>

enum class KeyboardAction : uint8_t { None, Cancel, Submit };

class KeyboardCore {
 public:
  explicit KeyboardCore(TFT_eSPI& tft) : tft_(tft) {}
  void begin(const String& ssid);
  void draw(bool wifiOnline, bool sdReady);
  KeyboardAction touch(int16_t x, int16_t y);
  const String& password() const { return password_; }

 private:
  TFT_eSPI& tft_;
  String ssid_;
  String password_;
  bool upper_ = false;
  bool symbols_ = false;
  void drawHeader(bool wifiOnline, bool sdReady);
  void drawPassword();
  void drawKeys();
  void key(int x, int y, int w, const char* text);
  char keyAt(const char* row, uint8_t length, int x, int startX, int width) const;
};
