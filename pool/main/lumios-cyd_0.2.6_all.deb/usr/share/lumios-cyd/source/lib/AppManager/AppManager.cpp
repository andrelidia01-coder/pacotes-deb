#include "AppManager.h"
#include <SdFat.h>
#include <SPI.h>
#include "hardware_pins.h"

namespace{
const char* IDS[]={"gpu","energia","ia","discos","fans","oc"};
const char* NAMES[]={"GPU","Energia","IA","Discos","Fans","OC"};
SdSpiConfig cfg(){return SdSpiConfig(HardwarePins::SD_CS,DEDICATED_SPI|USER_SPI_BEGIN,SD_SCK_MHZ(12),&SPI);}
void bus(){SPI.end();SPI.begin(HardwarePins::SD_SCLK,HardwarePins::SD_MISO,HardwarePins::SD_MOSI,HardwarePins::SD_CS);}
}
const char* AppManager::name(uint8_t i)const{return i<COUNT?NAMES[i]:"";}
bool AppManager::existsOnSd(const char* id){
  SdFat32 sd;bus();if(!sd.begin(cfg())){SPI.end();return false;}String p=String("/LumiOS/apps/")+id+"/manifest.json";
  bool ok=sd.exists(p.c_str());sd.end();SPI.end();return ok;
}
bool AppManager::begin(bool ready){prefs_.begin("lumios-apps",false);movedMask_=prefs_.getUChar("moved",0);return refresh(ready);}
bool AppManager::refresh(bool ready){for(uint8_t i=0;i<COUNT;i++){bool moved=movedMask_&(1U<<i);locations_[i]=moved?(ready&&existsOnSd(IDS[i])?AppLocation::Sd:AppLocation::Unavailable):AppLocation::Internal;}return true;}
bool AppManager::moveToSd(uint8_t i){
  if(i>=COUNT)return false;SdFat32 sd;bus();if(!sd.begin(cfg())){SPI.end();return false;}
  sd.mkdir("/LumiOS");sd.mkdir("/LumiOS/apps");String dir=String("/LumiOS/apps/")+IDS[i];sd.mkdir(dir.c_str());
  String temp=dir+"/manifest.tmp",dest=dir+"/manifest.json";File32 f=sd.open(temp.c_str(),O_WRONLY|O_CREAT|O_TRUNC);
  bool ok=f&&f.print(String("{\"id\":\"")+IDS[i]+"\",\"name\":\""+NAMES[i]+"\",\"version\":\"1.0\",\"minLumios\":30,\"lumicoreVersion\":\"0.1.0\",\"requires\":\"lumicore\"}");
  if(f){f.sync();f.close();}if(ok){sd.remove(dest.c_str());ok=sd.rename(temp.c_str(),dest.c_str());}if(!ok)sd.remove(temp.c_str());
  sd.end();SPI.end();if(ok){locations_[i]=AppLocation::Sd;movedMask_|=1U<<i;prefs_.putUChar("moved",movedMask_);}return ok;
}
