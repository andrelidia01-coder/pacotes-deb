#pragma once
#include <Arduino.h>
#include <WebServer.h>
#include "StoreCore.h"
class SdShareCore{
 public:
 SdShareCore();
 void attach(StoreCore& store){store_=&store;}
 bool start(bool wifiOnline,bool sdReady);
 void stop();
 void loop();
 bool active()const{return active_;}
 private:
 WebServer web_;StoreCore* store_=nullptr;File32 upload_;
 bool active_=false,uploadOk_=false,configured_=false,dirty_=true;String token_,uploadPath_,uploadTemp_,status_;
 void page();void upload();
 void result();void image();
 bool rebuild();bool sendFile(const String& path,const char* mime);
 bool write(File32& file,const String& text);
 bool packageName(const String& name)const;
 bool deletePackage(const String& name);
 bool copyIcon(const String& from,const String& to);
 bool authorized(){return web_.arg("token")==token_;}
};
