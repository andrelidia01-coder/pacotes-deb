#include "HttpWakeCore.h"
#include <WiFi.h>

namespace {
constexpr const char* HOSTNAME = "lumios-cyd";
constexpr uint32_t RESPONSE_GRACE_MS = 150;
}

String HttpWakeCore::page() {
  // This page is deliberately self-contained: after it reaches the browser,
  // the ESP32 can shut its HTTP server down. The 7-second wait is in the
  // browser, not on the ESP32.
  return R"HTML(<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>A iniciar IA...</title>
<style>
html,body{height:100%;margin:0}
body{display:flex;align-items:center;justify-content:center;background:#111;color:#fff;font-family:Arial,sans-serif;text-align:center}
main{padding:32px}
h1{font-size:28px;margin:0 0 14px}
p{font-size:18px;opacity:.8}
</style>
</head>
<body>
<div style="font-family:Arial,sans-serif;text-align:center;padding:40px 20px">
  <h2>A iniciar o servidor IA...</h2>
  <div style="width:100%;max-width:360px;height:12px;border:1px solid #aaa;border-radius:8px;margin:28px auto 14px;overflow:hidden">
    <div id="bar" style="height:100%;width:0%;transition:width .2s linear;background:#4caf50"></div>
  </div>
  <div id="count">15</div>
  <p>Aguarde enquanto o servidor termina de arrancar.</p>
</div>
<script>
(function(){
  var total=15, left=total, bar=document.getElementById('bar'), count=document.getElementById('count');
  var start=Date.now();
  var timer=setInterval(function(){
    var elapsed=(Date.now()-start)/1000;
    left=Math.max(0, Math.ceil(total-elapsed));
    bar.style.width=Math.min(100, elapsed/total*100)+'%';
    count.textContent=left;
    if(left<=0) clearInterval(timer);
  },200);
  setTimeout(function(){ window.location.replace('http://ia.local/'); },15000);
})();
</script>
</body>
</html>)HTML";
}

void HttpWakeCore::begin(WolCore* wol) {
  if (running_ || startedOnce_ || WiFi.status() != WL_CONNECTED) return;
  wol_ = wol;

  // ia.local belongs exclusively to the mini-PC; keep the CYD name separate.
  if (!MDNS.begin(HOSTNAME)) {
    Serial.println("HttpWake: MDNS.begin falhou");
    return;
  }
  MDNS.addService("http", "tcp", 80);

  server_.on("/", HTTP_GET, [this]() { handleRoot(); });
  server_.onNotFound([this]() { handleNotFound(); });
  server_.begin();
  running_ = true;
  startedOnce_ = true;
  stopPending_ = false;
  Serial.println("HttpWake: http://lumios-cyd.local/ (destino: ia.local)");
}

void HttpWakeCore::handleRoot() {
  bool wolOk = wol_ && wol_->send();
  Serial.printf("HttpWake: WoL %s\n", wolOk ? "OK" : "FALHOU");

  // Finish the HTTP response first. Do not stop the server from inside the
  // request handler; that was the reason the page could fail to arrive.
  server_.send(200, "text/html; charset=utf-8", page());

  stopPending_ = true;
  stopAt_ = millis() + RESPONSE_GRACE_MS;
}

void HttpWakeCore::handleNotFound() {
  server_.send(404, "text/plain; charset=utf-8", "LumiOS HTTP Wake");
}

void HttpWakeCore::scheduleStop() {
  stopPending_ = false;
  stop();
}

void HttpWakeCore::loop() {
  if (!running_) return;
  server_.handleClient();

  if (stopPending_ && (int32_t)(millis() - stopAt_) >= 0) {
    scheduleStop();
  }
}

void HttpWakeCore::stop() {
  if (!running_) return;
  server_.stop();
  // Release ia.local immediately after the launcher page has been delivered.
  // Keep mDNS running for LumiCore service discovery.
  running_ = false;
  stopPending_ = false;
  Serial.println("HttpWake: HTTP OFF; mDNS discovery active");
}
