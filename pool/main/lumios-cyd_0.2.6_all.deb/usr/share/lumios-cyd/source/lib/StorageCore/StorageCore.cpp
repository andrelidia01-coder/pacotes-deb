#include "StorageCore.h"

#include <SdFat.h>
#include <SPI.h>
#include "hardware_pins.h"

namespace {
SdSpiConfig sdConfig() {
  return SdSpiConfig(HardwarePins::SD_CS, DEDICATED_SPI | USER_SPI_BEGIN,
                     SD_SCK_MHZ(12), &SPI);
}
void startSdBus() {
  SPI.end();
  SPI.begin(HardwarePins::SD_SCLK, HardwarePins::SD_MISO,
            HardwarePins::SD_MOSI, HardwarePins::SD_CS);
  pinMode(HardwarePins::SD_CS, OUTPUT);
  digitalWrite(HardwarePins::SD_CS, HIGH);
}
uint8_t patternByte(uint32_t sector, uint16_t offset) {
  uint32_t x = sector * 2654435761UL + offset * 40503UL + 0x4C554D49UL;
  x ^= x >> 16;
  x *= 2246822519UL;
  return static_cast<uint8_t>(x ^ (x >> 13));
}
void fillPattern(uint8_t* data, uint32_t firstSector, uint8_t sectors) {
  for (uint8_t s = 0; s < sectors; ++s)
    for (uint16_t i = 0; i < 512; ++i)
      data[s * 512U + i] = patternByte(firstSector + s, i);
}
}  // namespace

SdReport StorageCore::probeReadOnly() {
  SdReport report;
  SdFat32 sd;
  startSdBus();
  if (!sd.begin(sdConfig())) {
    report.state = SdState::MountError;
    sd.end(); SPI.end(); return report;
  }
  report.cardType = 1;
  report.state = SdState::Ready;
  report.capacityBytes = static_cast<uint64_t>(sd.card()->sectorCount()) * 512ULL;
  const uint64_t freeBytes = static_cast<uint64_t>(sd.freeClusterCount()) *
                             sd.bytesPerCluster();
  report.usedBytes = report.capacityBytes > freeBytes
                         ? report.capacityBytes - freeBytes : 0;
  sd.end(); SPI.end();
  return report;
}

SdTestResult StorageCore::destructiveFullTest(SdProgressCallback progress) {
  constexpr uint8_t kBlockSectors = 8;
  static uint8_t buffer[kBlockSectors * 512];
  SdFat32 sd;
  startSdBus();
  if (!sd.begin(sdConfig())) return SdTestResult::InitError;
  const uint32_t total = sd.card()->sectorCount();
  uint8_t last = 255;

  for (uint32_t sector = 0; sector < total;) {
    const uint8_t count = min<uint32_t>(kBlockSectors, total - sector);
    fillPattern(buffer, sector, count);
    if (!sd.card()->writeSectors(sector, buffer, count)) {
      sd.end(); SPI.end(); return SdTestResult::WriteError;
    }
    sector += count;
    const uint8_t pct = static_cast<uint8_t>((static_cast<uint64_t>(sector) * 100) / total);
    if (pct != last) { last = pct; progress(SdTestPhase::Writing, pct, 0); }
    yield();
  }

  last = 255;
  for (uint32_t sector = 0; sector < total;) {
    const uint8_t count = min<uint32_t>(kBlockSectors, total - sector);
    if (!sd.card()->readSectors(sector, buffer, count)) {
      sd.end(); SPI.end(); return SdTestResult::ReadError;
    }
    for (uint8_t s = 0; s < count; ++s)
      for (uint16_t i = 0; i < 512; ++i)
        if (buffer[s * 512U + i] != patternByte(sector + s, i)) {
          sd.end(); SPI.end(); return SdTestResult::VerifyError;
        }
    sector += count;
    const uint8_t pct = static_cast<uint8_t>((static_cast<uint64_t>(sector) * 100) / total);
    if (pct != last) { last = pct; progress(SdTestPhase::Reading, pct, 0); }
    yield();
  }

  progress(SdTestPhase::Formatting, 0, 0);
  if (!sd.format(&Serial)) {
    sd.end(); SPI.end(); return SdTestResult::FormatError;
  }
  sd.end();
  startSdBus();
  if (!sd.begin(sdConfig())) { SPI.end(); return SdTestResult::PrepareError; }
  progress(SdTestPhase::Preparing, 20, 0);
  const bool ok = sd.mkdir("/LumiOS") && sd.mkdir("/LumiOS/apps") &&
                  sd.mkdir("/LumiOS/config") && sd.mkdir("/LumiOS/logs") &&
                  sd.mkdir("/LumiOS/themes") && sd.mkdir("/LumiOS/cache") &&
                  sd.mkdir("/LumiOS/recovery");
  progress(SdTestPhase::Preparing, 100, 0);
  sd.end(); SPI.end();
  return ok ? SdTestResult::Passed : SdTestResult::PrepareError;
}
