#include "KeyboardCore.h"

namespace {
constexpr uint16_t BG=0x0863, PANEL=0x10E4, CYAN=0x073F, BLUE=0x24BF;
constexpr uint16_t GREEN=0x07E0, DIM=0x7BEF;
}

void KeyboardCore::begin(const String& ssid) {
  ssid_ = ssid;
  password_ = "";
  upper_ = false;
  symbols_ = false;
}

void KeyboardCore::drawHeader(bool wifi, bool sd) {
  tft_.fillRect(0,0,320,32,PANEL);
  tft_.setTextDatum(ML_DATUM); tft_.setTextColor(CYAN,PANEL);
  tft_.drawString("<",10,16,4);
  tft_.drawRect(45,12,14,11,TFT_WHITE);
  tft_.drawTriangle(43,13,52,5,61,13,TFT_WHITE);
  tft_.drawString("Wi-Fi",72,16,2);
  tft_.setTextDatum(MR_DATUM); tft_.setTextColor(sd?GREEN:DIM,PANEL);
  tft_.drawString(sd?"SD  WIFI":"WIFI",310,16,1);
  tft_.drawCircle(307,16,2,wifi?GREEN:TFT_RED);
}

void KeyboardCore::key(int x,int y,int w,const char* text) {
  tft_.fillRoundRect(x,y,w,23,3,PANEL);
  tft_.drawRoundRect(x,y,w,23,3,DIM);
  tft_.setTextDatum(MC_DATUM); tft_.setTextColor(TFT_WHITE,PANEL);
  tft_.drawString(text,x+w/2,y+12,2);
}

void KeyboardCore::drawPassword() {
  tft_.fillRect(8,34,304,39,BG);
  tft_.setTextDatum(ML_DATUM); tft_.setTextColor(TFT_WHITE,BG);
  String shown=ssid_; if(shown.length()>25) shown=shown.substring(0,22)+"...";
  tft_.drawString(shown,10,44,2);
  String visible=password_;
  if(visible.length()>34) visible="..."+visible.substring(visible.length()-31);
  if(!visible.length()) visible="Palavra-passe";
  tft_.setTextColor(password_.length()?CYAN:DIM,BG); tft_.drawString(visible,10,64,2);
}

void KeyboardCore::drawKeys() {
  tft_.fillRect(0,74,320,166,BG);
  const char* rows[3];
  if(symbols_){ rows[0]="1234567890";rows[1]="@#%&*()-_";rows[2]=".!?/:;+="; }
  else { rows[0]="qwertyuiop";rows[1]="asdfghjkl";rows[2]="zxcvbnm"; }
  for(uint8_t r=0;r<3;r++){
    int len=strlen(rows[r]), w=28, gap=3, total=len*w+(len-1)*gap;
    int start=(320-total)/2;
    for(int i=0;i<len;i++){
      char text[2]={rows[r][i],0};
      if(upper_&&!symbols_) text[0]=toupper(text[0]);
      key(start+i*(w+gap),76+r*27,w,text);
    }
  }
  key(5,158,49,symbols_?"ABC":"123"); key(58,158,52,upper_?"abc":"SHIFT");
  key(114,158,132,"ESPACO"); key(250,158,65,"APAGAR");
  tft_.fillRoundRect(5,187,124,43,5,DIM); tft_.fillRoundRect(133,187,182,43,5,BLUE);
  tft_.setTextDatum(MC_DATUM);tft_.setTextColor(TFT_WHITE);
  tft_.drawString("CANCELAR",67,208,2);tft_.drawString("LIGAR",224,208,2);
}

void KeyboardCore::draw(bool wifi,bool sd) {
  tft_.fillScreen(BG);drawHeader(wifi,sd);drawPassword();drawKeys();
}

char KeyboardCore::keyAt(const char* row,uint8_t len,int x,int start,int width) const {
  for(uint8_t i=0;i<len;i++) if(x>=start+i*31 && x<start+i*31+width) return row[i];
  return 0;
}

KeyboardAction KeyboardCore::touch(int16_t x,int16_t y) {
  if(y>=187){ return x<131?KeyboardAction::Cancel:KeyboardAction::Submit; }
  if(y>=158&&y<183){
    if(x<56){symbols_=!symbols_;upper_=false;drawKeys();}
    else if(x<112){upper_=!upper_;drawKeys();}
    else if(x<248&&password_.length()<63){password_+=' ';drawPassword();}
    else if(x>=248&&password_.length()){password_.remove(password_.length()-1);drawPassword();}
    return KeyboardAction::None;
  }
  if(y<76||y>=157) return KeyboardAction::None;
  uint8_t row=(y-76)/27;
  const char* rows[3];
  if(symbols_){rows[0]="1234567890";rows[1]="@#%&*()-_";rows[2]=".!?/:;+=";}
  else {rows[0]="qwertyuiop";rows[1]="asdfghjkl";rows[2]="zxcvbnm";}
  uint8_t len=strlen(rows[row]); int total=len*28+(len-1)*3, start=(320-total)/2;
  char c=keyAt(rows[row],len,x,start,28);
  if(c&&password_.length()<63){if(upper_&&!symbols_)c=toupper(c);password_+=c;drawPassword();}
  return KeyboardAction::None;
}
