#include "DisplayCore.h"

#include "hardware_pins.h"

void DisplayCore::begin() {
  pinMode(HardwarePins::BACKLIGHT, OUTPUT);
  setBacklight(255);
  display_.init();
  setOrientation(0);
  display_.fillScreen(TFT_BLACK);
}

TFT_eSPI& DisplayCore::tft() { return display_; }

void DisplayCore::setBacklight(uint8_t level) {
  analogWrite(HardwarePins::BACKLIGHT, level);
}


void DisplayCore::setOrientation(uint16_t degrees) {
  degrees = (degrees / 90 * 90) % 360;
  orientation_ = degrees;
  display_.resetViewport();
  // The established LumiOS landscape is TFT_eSPI rotation 1.
  display_.setRotation((1 + degrees / 90) & 3);
}
