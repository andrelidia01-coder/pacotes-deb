#pragma once
#include <Arduino.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include "WolCore.h"

class HttpWakeCore {
public:
  void begin(WolCore* wol);
  void loop();
  void stop();
  bool running() const { return running_; }

private:
  WebServer server_{80};
  WolCore* wol_ = nullptr;
  bool running_ = false;
  bool startedOnce_ = false;
  bool stopPending_ = false;
  uint32_t stopAt_ = 0;

  void handleRoot();
  void handleNotFound();
  void scheduleStop();
  static String page();
};
