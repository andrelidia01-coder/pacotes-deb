// LUMIOS_PNG_ZLIB_FIX
#include "StoreCore.h"
#include "PackageRules.h"
#include "hardware_pins.h"
#include <SPI.h>
#include <cJSON.h>
#include <miniz.h>
namespace {
constexpr size_t ZIP_MAX=4*1024*1024, EXPANDED_MAX=8*1024*1024;
size_t readZip(void* p,mz_uint64 off,void* b,size_t n){
 File32* f=(File32*)p; if(off>UINT32_MAX||!f->seekSet((uint32_t)off))return 0;
 int r=f->read(b,n);return r>0?r:0;
}
size_t writeZip(void* p,mz_uint64 off,const void* b,size_t n){
 File32* f=(File32*)p;if(off!=f->curPosition())return 0;
 size_t r=f->write(b,n);yield();return r;
}
struct Budget { size_t used=0; };
union AllocationHeader {size_t size;uint64_t alignment;void* pointer;};
void* allocZip(void* ctx,size_t n,size_t s){
 if(s&&n>SIZE_MAX/s)return nullptr;size_t bytes=n*s;Budget* b=(Budget*)ctx;
 if(bytes>96*1024-b->used)return nullptr;
 AllocationHeader* p=(AllocationHeader*)malloc(bytes+sizeof(AllocationHeader));if(!p)return nullptr;
 p->size=bytes;b->used+=bytes;return p+1;
}
void freeZip(void* ctx,void* ptr){if(ptr){auto p=(AllocationHeader*)ptr-1;((Budget*)ctx)->used-=p->size;free(p);}}
void* resizeZip(void* ctx,void* ptr,size_t n,size_t s){
 if(s&&n>SIZE_MAX/s)return nullptr;size_t bytes=n*s;size_t old=ptr?((AllocationHeader*)ptr-1)->size:0;
 Budget* b=(Budget*)ctx;if(bytes>96*1024-(b->used-old))return nullptr;
 AllocationHeader* p=(AllocationHeader*)realloc(ptr?(AllocationHeader*)ptr-1:nullptr,bytes+sizeof(AllocationHeader));
 if(!p)return nullptr;p->size=bytes;b->used=b->used-old+bytes;return p+1;
}
}
bool StoreCore::mount(){
 SPI.end();SPI.begin(HardwarePins::SD_SCLK,HardwarePins::SD_MISO,HardwarePins::SD_MOSI,HardwarePins::SD_CS);
 if(mounted)return true;
 mounted=sd.begin(SdSpiConfig(HardwarePins::SD_CS,DEDICATED_SPI|USER_SPI_BEGIN,SD_SCK_MHZ(12),&SPI));
 if(!mounted){sd.end();SPI.end();message="SD indisponivel";}return mounted;
}
void StoreCore::unmount(){sd.end();SPI.end();mounted=false;}
bool StoreCore::manifest(const String& path,StoreEntry& out){
 File32 f=sd.open((path+"/manifest.json").c_str(),O_RDONLY);
 if(!f||f.fileSize()>2048){f.close();return false;}
 char buf[2049];int n=f.read(buf,2048);f.close();if(n<=0)return false;buf[n]=0;
 // Bound JSON recursion before calling the SDK parser.
 unsigned depth=0;bool quoted=false,escaped=false;
 for(int i=0;i<n;i++){char c=buf[i];if(quoted){if(escaped)escaped=false;else if(c=='\\')escaped=true;else if(c=='"')quoted=false;}
 else if(c=='"')quoted=true;else if(c=='{'||c=='['){if(++depth>8)return false;}else if(c=='}'||c==']'){if(!depth)return false;--depth;}}
 if(quoted||depth)return false;
 cJSON* j=cJSON_Parse(buf);if(!j)return false;
 auto id=cJSON_GetObjectItemCaseSensitive(j,"id"),name=cJSON_GetObjectItemCaseSensitive(j,"name"),
 entry=cJSON_GetObjectItemCaseSensitive(j,"entry"),ver=cJSON_GetObjectItemCaseSensitive(j,"minLumios"),ic=cJSON_GetObjectItemCaseSensitive(j,"icon"),
 perm=cJSON_GetObjectItemCaseSensitive(j,"permissions"),req=cJSON_GetObjectItemCaseSensitive(j,"requires");
 auto core=cJSON_GetObjectItemCaseSensitive(j,"lumicoreVersion");
 bool ok=cJSON_IsString(core)&&!strcmp(core->valuestring,"0.1.0")&&cJSON_IsString(id)&&PackageRules::id(id->valuestring)&&cJSON_IsString(name)&&strlen(name->valuestring)>0&&strlen(name->valuestring)<=32&&
 cJSON_IsString(entry)&&!strcmp(entry->valuestring,"main.lua")&&cJSON_IsNumber(ver)&&ver->valuedouble==30&&
 (!ic||cJSON_IsString(ic)&&strlen(ic->valuestring)>0&&strlen(ic->valuestring)<=16)&&(!perm||cJSON_IsArray(perm))&&(!req||(cJSON_IsString(req)&&!strcmp(req->valuestring,"lumicore")));
 if(ok&&perm){cJSON* p=nullptr;cJSON_ArrayForEach(p,perm){if(!cJSON_IsString(p)||(strcmp(p->valuestring,"display")&&strcmp(p->valuestring,"touch")))ok=false;}}
 if(ok){out.id=id->valuestring;out.name=name->valuestring;out.icon=ic?ic->valuestring:out.id;out.path=path;out.requiresServer=req!=nullptr;
 File32 script=sd.open((path+"/main.lua").c_str(),O_RDONLY);ok=script&&script.fileSize()>0&&script.fileSize()<=32768;script.close();}
 cJSON_Delete(j);return ok;
}
bool StoreCore::refresh(){
 for(unsigned i=0;i<count;i++){free(entries[i].iconPixels);entries[i].iconPixels=nullptr;}
 count=0;used=total=0;if(!mount())return false;
 File32 dir=sd.open("/LumiOS/apps",O_RDONLY),f;char name[128];
 while(dir&&count<MAX_APPS&&f.openNext(&dir,O_RDONLY)){
  f.getName(name,sizeof(name));bool isdir=f.isDir();f.close();
  String base=name;if(!isdir||!base.endsWith(".app")||!PackageRules::path(name))continue;
  StoreEntry e;if(manifest("/LumiOS/apps/"+base,e)){bool duplicate=false;for(unsigned i=0;i<count;i++)if(entries[i].id==e.id)duplicate=true;
  if(!duplicate)entries[count++]=e;}
 }
 dir.close();
 total=(uint64_t)sd.clusterCount()*sd.bytesPerCluster();
 int32_t free=sd.freeClusterCount();if(free>=0)used=total-(uint64_t)free*sd.bytesPerCluster();
 unmount();return true;
}
bool StoreCore::prune(const String& path,unsigned depth){
 if(depth>12)return false;File32 d=sd.open(path.c_str(),O_RDONLY);if(!d)return true;
 if(!d.isDir()){d.close();return sd.remove(path.c_str());}
 File32 f;char name[128];bool ok=true;
 while(f.openNext(&d,O_RDONLY)){f.getName(name,sizeof(name));f.close();if(!PackageRules::path(name)||!prune(path+"/"+name,depth+1)){ok=false;break;}}
 d.close();return ok&&sd.rmdir(path.c_str());
}
bool StoreCore::install(const String& file){
 message="Pacote invalido";
 if(count>=MAX_APPS){message="Limite de 48 apps";return false;}
 if(!PackageRules::path(file.c_str())||file.indexOf('/')>=0||!(file.endsWith(".app")||file.endsWith(".zip")))return false;
 if(!mount())return false;
 File32 archive=sd.open(("/LumiOS/uploads/"+file).c_str(),O_RDONLY);
 mz_zip_archive zip={};Budget budget;zip.m_pRead=readZip;zip.m_pIO_opaque=&archive;
 zip.m_pAlloc=allocZip;zip.m_pFree=freeZip;zip.m_pRealloc=resizeZip;zip.m_pAlloc_opaque=&budget;
 bool opened=false,ok=false;String staging, prefix;uint64_t expanded=0;unsigned n=0,mi=0,manifestCount=0;
 do{
  if(!archive||archive.fileSize()>ZIP_MAX)break;
  if(!(opened=mz_zip_reader_init(&zip,archive.fileSize(),0)))break;
  n=mz_zip_reader_get_num_files(&zip);if(!n||n>64)break;
  bool valid=true;
  for(unsigned i=0;i<n;i++){
   mz_zip_archive_file_stat s;if(!mz_zip_reader_file_stat(&zip,i,&s)||!PackageRules::path(s.m_filename)||s.m_is_encrypted||!s.m_is_supported||
     ((s.m_external_attr>>16)&01150000)==0120000){valid=false;break;}
   String p=s.m_filename;
   if(s.m_is_directory&&!p.endsWith("/")){valid=false;break;}
   if(s.m_uncomp_size>EXPANDED_MAX||expanded+s.m_uncomp_size>EXPANDED_MAX){valid=false;break;}
   expanded+=s.m_uncomp_size;
   if(p=="manifest.json"||p.endsWith("/manifest.json")){mi=i;manifestCount++;prefix=p.substring(0,p.length()-13);}
  }
  if(!valid||manifestCount!=1)break;
  for(unsigned i=0;i<n;i++){
   mz_zip_archive_file_stat s;mz_zip_reader_file_stat(&zip,i,&s);String p=s.m_filename;
   if(!p.startsWith(prefix)){valid=false;break;}
   String relative=p.substring(prefix.length());
   if(relative.length()&&!PackageRules::path(relative.c_str())){valid=false;break;}
   for(unsigned k=0;k<i;k++){mz_zip_archive_file_stat prev;mz_zip_reader_file_stat(&zip,k,&prev);if(!strcasecmp(s.m_filename,prev.m_filename)){valid=false;break;}}
  }
  if(!valid)break;
  mz_zip_archive_file_stat ms;mz_zip_reader_file_stat(&zip,mi,&ms);if(ms.m_uncomp_size>2048)break;
  int32_t free=sd.freeClusterCount();
  if(free<0||(uint64_t)free*sd.bytesPerCluster()<expanded+(n+4)*sd.bytesPerCluster()){message="Sem espaco SD";break;}
  sd.mkdir("/LumiOS");sd.mkdir("/LumiOS/apps");sd.mkdir("/LumiOS/staging");
  staging=String("/LumiOS/staging/install-")+String(esp_random(),HEX);
  if(sd.exists(staging.c_str())||!sd.mkdir(staging.c_str())){staging="";break;}
  for(unsigned i=0;i<n&&valid;i++){
   mz_zip_archive_file_stat s;mz_zip_reader_file_stat(&zip,i,&s);String rel=String(s.m_filename).substring(prefix.length());if(!rel.length())continue;
   String dest=staging+"/"+rel;
   if(s.m_is_directory){dest.remove(dest.length()-1);if(!sd.exists(dest.c_str())&&!sd.mkdir(dest.c_str(),true))valid=false;continue;}
   int slash=dest.lastIndexOf('/');String parent=dest.substring(0,slash);
   if(!sd.exists(parent.c_str())&&!sd.mkdir(parent.c_str(),true)){valid=false;break;}
   File32 out=sd.open(dest.c_str(),O_WRONLY|O_CREAT|O_EXCL);
   if(!out){valid=false;break;}
   valid=mz_zip_reader_extract_to_callback(&zip,i,writeZip,&out,0)&&out.sync();out.close();yield();
  }
  if(!valid){message="Falha na extracao/CRC";break;}
  StoreEntry e;if(!manifest(staging,e)){message="Manifesto ou script invalido";break;}
  String dest="/LumiOS/apps/"+e.id+".app";
  if(sd.exists(dest.c_str())){message="App ja instalada; preservada";break;}
  if(!sd.rename(staging.c_str(),dest.c_str())){message="Falha ao publicar app";break;}
  staging="";ok=true;message="Instalada: "+e.name;
 }while(false);
 if(opened)mz_zip_reader_end(&zip);archive.close();
 if(staging.length()&&!prune(staging))message+=" (temporario retido)";
 unmount();if(ok)refresh();return ok;
}
bool StoreCore::readScript(unsigned i,String& source){
 source="";if(i>=count||!mount())return false;
 File32 f=sd.open((entries[i].path+"/main.lua").c_str(),O_RDONLY);
 bool ok=f&&f.fileSize()>0&&f.fileSize()<=32768;
 if(ok)ok=source.reserve(f.fileSize()+1);
 char buf[1024];int n;
 if(ok){while((n=f.read(buf,sizeof(buf)))>0){if(!source.concat(buf,n)){ok=false;break;}}if(n<0)ok=false;}
 f.close();unmount();return ok;
}

bool StoreCore::cachePackageIcon(const String& filename,const String& destination){
 if(!mounted||!PackageRules::path(filename.c_str())||filename.indexOf('/')>=0||
    !(filename.endsWith(".app")||filename.endsWith(".zip"))||
    !(destination==String("/.html/pkg-")+filename+".png"))return false;
 File32 archive=sd.open(("/LumiOS/uploads/"+filename).c_str(),O_RDONLY);
 mz_zip_archive zip={};Budget budget;zip.m_pRead=readZip;zip.m_pIO_opaque=&archive;
 zip.m_pAlloc=allocZip;zip.m_pFree=freeZip;zip.m_pRealloc=resizeZip;zip.m_pAlloc_opaque=&budget;
 bool opened=false,ok=false;String temp=destination+".tmp";
 do{
  if(!archive||archive.fileSize()>ZIP_MAX)break;
  opened=mz_zip_reader_init(&zip,archive.fileSize(),0);if(!opened)break;
  unsigned n=mz_zip_reader_get_num_files(&zip);if(!n||n>64)break;
  String prefix;unsigned manifests=0;bool valid=true;
  for(unsigned k=0;k<n;k++){
   mz_zip_archive_file_stat st;
   if(!mz_zip_reader_file_stat(&zip,k,&st)||!PackageRules::path(st.m_filename)){valid=false;break;}
   String p=st.m_filename;
   if(p=="manifest.json"||p.endsWith("/manifest.json")){prefix=p.substring(0,p.length()-13);++manifests;}
  }
  if(!valid||manifests!=1)break;
  unsigned icons=0,index=0;
  for(unsigned k=0;k<n;k++){
   mz_zip_archive_file_stat st;mz_zip_reader_file_stat(&zip,k,&st);
   if(String(st.m_filename)==prefix+"icon.png"){
    if(st.m_is_directory||st.m_is_encrypted||!st.m_is_supported||st.m_uncomp_size<33||st.m_uncomp_size>65536||
       ((st.m_external_attr>>16)&01150000)==0120000){valid=false;break;}
    index=k;++icons;
   }
  }
  if(!valid||icons!=1)break;
  File32 out=sd.open(temp.c_str(),O_WRONLY|O_CREAT|O_TRUNC);if(!out)break;
  ok=mz_zip_reader_extract_to_callback(&zip,index,writeZip,&out,0)&&out.sync();out.close();
  if(!ok)break;
  uint8_t header[24];File32 png=sd.open(temp.c_str(),O_RDONLY);
  static const uint8_t signature[8]={137,80,78,71,13,10,26,10};
  ok=png&&png.read(header,sizeof(header))==sizeof(header)&&!memcmp(header,signature,8)&&
     !memcmp(header+8,"\0\0\0\rIHDR",8)&&!memcmp(header+16,"\0\0\0\x20\0\0\0\x20",8);png.close();
  if(!ok)break;
  if(sd.exists(destination.c_str())&&!sd.remove(destination.c_str())){ok=false;break;}
  ok=sd.rename(temp.c_str(),destination.c_str());
 }while(false);
 if(opened)mz_zip_reader_end(&zip);archive.close();
 if(sd.exists(temp.c_str()))sd.remove(temp.c_str());
 if(!ok&&sd.exists(destination.c_str()))sd.remove(destination.c_str());
 return ok;
}

bool StoreCore::drawIcon(unsigned i,TFT_eSPI& tft,int x,int y){
 if(i<count&&entries[i].iconPixels){tft.pushImage(x,y,32,32,entries[i].iconPixels);return true;}
 if(i>=count||!mount())return false;File32 f=sd.open((entries[i].path+"/icon.png").c_str(),O_RDONLY);
 bool ok=f&&f.fileSize()<=16384;uint8_t* file=nullptr;size_t len=ok?f.fileSize():0;
 if(ok){file=(uint8_t*)malloc(len);ok=file&&f.read(file,len)==(int)len;}f.close();unmount();
 if(!ok){free(file);return false;}
 auto be16=[](const uint8_t*p)->uint16_t{return (uint16_t(p[0])<<8)|p[1];};auto be32=[](const uint8_t*p)->uint32_t{return (uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|p[3];};
 static const uint8_t sig[8]={137,80,78,71,13,10,26,10};if(len<33||memcmp(file,sig,8)){free(file);return false;}
 uint32_t w=0,h=0;uint8_t depth=0,type=0,interlace=1;size_t at=8,idat=0;uint32_t idatLen=0;
 while(at+12<=len){uint32_t n=be32(file+at);if(n>len-at-12){free(file);return false;}const uint8_t* kind=file+at+4;const uint8_t* data=file+at+8;
  if(!memcmp(kind,"IHDR",4)&&n>=13){w=be32(data);h=be32(data+4);depth=data[8];type=data[9];interlace=data[12];}
  if(!memcmp(kind,"IDAT",4)){if(idatLen+n>len){free(file);return false;}if(!idat){idat=(size_t)malloc(len);if(!idat){free(file);return false;}}memcpy((uint8_t*)idat+idatLen,data,n);idatLen+=n;}
  at+=12+n;if(!memcmp(kind,"IEND",4))break;
 }
 if(w!=32||h!=32||depth!=8||(type!=2&&type!=6)||interlace||!idatLen){free((void*)idat);free(file);return false;}
 size_t bpp=type==6?4:3,row=w*bpp,rawLen=(row+1)*h;uint8_t* raw=(uint8_t*)malloc(rawLen);uint16_t* pix=(uint16_t*)malloc(32*32*2);bool good=raw&&pix;
 if(good)good=tinfl_decompress_mem_to_mem(raw,rawLen,(uint8_t*)idat,idatLen,TINFL_FLAG_PARSE_ZLIB_HEADER)==rawLen;
 if(good){uint8_t* prev=(uint8_t*)calloc(1,row);if(!prev)good=false;for(unsigned yy=0;yy<32&&good;yy++){uint8_t* cur=raw+yy*(row+1)+1;uint8_t filter=raw[yy*(row+1)];for(size_t q=0;q<row;q++){uint8_t a=q>=bpp?cur[q-bpp]:0,b=prev[q],c=q>=bpp?prev[q-bpp]:0;uint8_t v=cur[q];if(filter==1)v+=a;else if(filter==2)v+=b;else if(filter==3)v+=(uint8_t)((a+b)/2);else if(filter==4){int p=int(a)+int(b)-int(c),pa=abs(p-int(a)),pb=abs(p-int(b)),pc=abs(p-int(c));v+=(pa<=pb&&pa<=pc?a:(pb<=pc?b:c));}else if(filter)good=false;cur[q]=v;}if(good){for(unsigned xx=0;xx<32;xx++){uint8_t r=cur[xx*bpp],g=cur[xx*bpp+1],b8=cur[xx*bpp+2];pix[yy*32+xx]=((r&248)<<8)|((g&252)<<3)|(b8>>3);}memcpy(prev,cur,row);}}free(prev);}
 if(good){entries[i].iconPixels=pix;tft.pushImage(x,y,32,32,pix);}else free(pix);
 free(raw);free((void*)idat);free(file);return good;
}

// On-device application manager: each operation owns and closes its SD session.
bool StoreCore::scanPackages(){
 packageCount=0;packageLimit=false;if(!mount())return false;
 File32 dir=sd.open("/LumiOS/uploads",O_RDONLY),f;char name[128];
 while(dir&&f.openNext(&dir,O_RDONLY)){
  bool regular=!f.isDir();f.getName(name,sizeof(name));f.close();String n=name;
  if(!regular||!PackageRules::path(name)||n.indexOf('/')>=0||!(n.endsWith(".app")||n.endsWith(".zip")))continue;
  if(packageCount==64){packageLimit=true;break;}
  packages[packageCount++]=n;
 }
 dir.close();unmount();return true;
}
bool StoreCore::deletePackage(const String& file){
 if(!PackageRules::path(file.c_str())||file.indexOf('/')>=0||!(file.endsWith(".app")||file.endsWith(".zip"))){message="Nome invalido";return false;}
 if(!mount())return false;
 String path="/LumiOS/uploads/"+file;
 File32 f=sd.open(path.c_str(),O_RDONLY);bool regular=f&&!f.isDir();f.close();
 bool ok=regular&&sd.remove(path.c_str());
 if(ok){
  String icon="/.html/pkg-"+file+".png";
  bool clean=!sd.exists(icon.c_str())||sd.remove(icon.c_str());
  String tmp=icon+".tmp";clean=(!sd.exists(tmp.c_str())||sd.remove(tmp.c_str()))&&clean;
  message=clean?"Pacote apagado":"Pacote apagado; icone retido";
 }else message="Nao foi possivel apagar";
 unmount();refresh();scanPackages();return ok;
}
bool StoreCore::uninstallApp(unsigned index){
 if(index>=count){message="Selecao invalida";return false;}
 String id=entries[index].id,path=entries[index].path;
 if(!PackageRules::id(id.c_str())||path!="/LumiOS/apps/"+id+".app"){message="Caminho da app invalido";return false;}
 if(!mount())return false;
 sd.mkdir("/LumiOS/staging");
 String trash="/LumiOS/staging/remove-"+id+"-"+String(esp_random(),HEX);
 bool ok=!sd.exists(trash.c_str())&&sd.rename(path.c_str(),trash.c_str());
 if(ok){
  bool clean=prune(trash);String icon="/.html/installed-"+id+".png";
  clean=(!sd.exists(icon.c_str())||sd.remove(icon.c_str()))&&clean;
  message=clean?"App desinstalada":"Desinstalada; restos em staging";
 }else message="Falha; app preservada";
 unmount();refresh();return ok;
}
