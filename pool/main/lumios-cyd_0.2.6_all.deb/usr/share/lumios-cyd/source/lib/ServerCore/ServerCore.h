#pragma once
#include <Arduino.h>
#include "DeviceConfig.h"
#include <atomic>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>

class ServerCore {
 public:
  void begin();
  void update(bool wifiOnline);
  bool online() const { return wifi_.load() && online_.load(); }
  bool shutdown();
  bool recoveryAction(const String& command,String& message);
  int shutdownState() const { return shutdownState_.load(); }
  String shutdownMessage();
  String systemInfo();
  static bool compatibleEndpoint();
  String endpoint() const { return DeviceConfig::endpoint(); }
 private:
  std::atomic<bool> online_{false}, wifi_{false};
  TaskHandle_t worker_=nullptr;
  std::atomic<bool> shutdownPending_{false};
  std::atomic<int> shutdownState_{0}; // 0 idle, 1 pending, 2 scheduled, 3 failure
  SemaphoreHandle_t messageLock_=nullptr;
  String shutdownMessage_;
  static void workerEntry(void* context);
  bool checkHealth();
  void performShutdown();
  void setShutdownMessage(const String& message);
};
