#pragma once
#include <Arduino.h>
namespace DisksTelemetry {
constexpr unsigned MAX_ROWS=32;
struct Row {
 char mount[97]={},device[97]={},fs[25]={};
 double total=0,used=0,free=0,available=0,percent=0;
 bool valid=false,readOnly=false;
};
struct Page {
 Row rows[3];unsigned count=0,page=0,pages=1,total=0;
 bool online=false;char error[64]={};
};
struct Energy {
 double cpu=-1,gpu=-1,total=-1,limit=-1;
 bool online=false,warning=false;char error[64]={};
};
constexpr unsigned MAX_GPUS=8;
struct Gpu {
 char name[97]={},uuid[81]={},vendor[33]={},chip[33]={};
 double temp=-1,usage=-1,power=-1,limit=-1,clock=-1,memoryClock=-1,fan=-1;
 double memoryUsed=-1,memoryTotal=-1;
 int tech[5]={-1,-1,-1,-1,-1};
 char techVersion[5][32]={}; // GPU_TECH_VERSIONS_V1
};
struct Gpus {Gpu rows[MAX_GPUS];unsigned count=0;bool online=false;char error[64]={};};
void readGpus(Gpus& result);
void readEnergy(Energy& result);
void start();
void stop();
void read(unsigned page,Page& result);
}
