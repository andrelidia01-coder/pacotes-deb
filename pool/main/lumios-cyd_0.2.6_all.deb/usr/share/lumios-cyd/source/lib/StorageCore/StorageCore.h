#pragma once

#include <Arduino.h>

enum class SdState { NotChecked, Missing, MountError, Ready };
enum class SdTestResult { NotRun, Passed, InitError, WriteError, ReadError,
                          VerifyError, FormatError, PrepareError };
enum class SdTestPhase { Writing, Reading, Formatting, Preparing };
using SdProgressCallback = void (*)(SdTestPhase phase, uint8_t percent,
                                    uint32_t errors);

struct SdReport {
  SdState state = SdState::NotChecked;
  uint64_t capacityBytes = 0;
  uint64_t usedBytes = 0;
  uint8_t cardType = 0;
};

class StorageCore {
 public:
  SdReport probeReadOnly();
  SdTestResult destructiveFullTest(SdProgressCallback progress);
};
