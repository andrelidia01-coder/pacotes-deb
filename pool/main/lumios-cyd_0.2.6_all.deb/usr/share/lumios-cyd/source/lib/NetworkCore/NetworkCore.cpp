#include "NetworkCore.h"
#include <time.h>
#include "local_config.h"

void NetworkCore::begin() {
  WiFi.persistent(false);
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  configTzTime("CET-1CEST,M3.5.0,M10.5.0/3", "pool.ntp.org", "time.nist.gov");
  prefs_.begin("lumios-net", false);
  if (prefs_.getString("configrev", "") != LUMIOS_CONFIG_REV && strlen(LUMIOS_WIFI_SSID)) {
    prefs_.putString("ssid", LUMIOS_WIFI_SSID);
    prefs_.putString("pass", LUMIOS_WIFI_PASSWORD);
    prefs_.putString("configrev", LUMIOS_CONFIG_REV);
  }
  savedSsid_ = prefs_.getString("ssid", "");
  savedPassword_ = prefs_.getString("pass", "");
  if (savedSsid_.length()) {
    WiFi.begin(savedSsid_.c_str(), savedPassword_.c_str());
  }
}

bool NetworkCore::scan() {
  count_ = 0;
  const int16_t found = WiFi.scanNetworks(false, true);
  if (found < 0) return false;
  for (int16_t i = 0; i < found && count_ < MAX_NETWORKS; ++i) {
    const String name = WiFi.SSID(i);
    if (!name.length()) continue;
    bool duplicate = false;
    for (uint8_t n = 0; n < count_; ++n) {
      if (entries_[n].ssid == name) { duplicate = true; break; }
    }
    if (duplicate) continue;
    entries_[count_].ssid = name;
    entries_[count_].rssi = WiFi.RSSI(i);
    entries_[count_].secured = WiFi.encryptionType(i) != WIFI_AUTH_OPEN;
    ++count_;
  }
  WiFi.scanDelete();
  return true;
}

bool NetworkCore::waitForConnection(uint32_t timeoutMs) {
  const uint32_t started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < timeoutMs) {
    delay(100);
  }
  return online();
}

bool NetworkCore::connect(const String& ssid, const String& password,
                          uint32_t timeoutMs) {
  WiFi.disconnect(false, false);
  delay(100);
  WiFi.begin(ssid.c_str(), password.c_str());
  if (!waitForConnection(timeoutMs)) return false;
  savedSsid_ = ssid;
  savedPassword_ = password;
  prefs_.putString("ssid", savedSsid_);
  prefs_.putString("pass", savedPassword_);
  return true;
}

void NetworkCore::forget() {
  WiFi.disconnect(true, false);
  prefs_.remove("ssid");
  prefs_.remove("pass");
  savedSsid_ = "";
  savedPassword_ = "";
  WiFi.mode(WIFI_STA);
}
