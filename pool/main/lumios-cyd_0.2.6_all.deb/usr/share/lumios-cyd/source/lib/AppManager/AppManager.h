#pragma once
#include <Arduino.h>
#include <Preferences.h>

enum class AppLocation:uint8_t{Internal,Sd,Unavailable};
class AppManager{
 public:
  static constexpr uint8_t COUNT=6;
  bool begin(bool sdReady);
  bool refresh(bool sdReady);
  bool moveToSd(uint8_t index);
  AppLocation location(uint8_t index)const{return locations_[index];}
  const char* name(uint8_t index)const;
 private:
  AppLocation locations_[COUNT];
  Preferences prefs_;
  uint8_t movedMask_=0;
  bool existsOnSd(const char* id);
};
