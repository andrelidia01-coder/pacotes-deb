#include "ShellCore.h"
#include "lumios_version.h"
#include <time.h>
#include "TimeValidity.h"

namespace {
constexpr uint16_t BG = 0x0863;
constexpr uint16_t PANEL = 0x10E4;
constexpr uint16_t CYAN = 0x073F;
constexpr uint16_t DIM = 0x7BEF;
constexpr uint16_t BLUE = 0x24BF;
constexpr uint16_t AMBER = 0xFD20;
constexpr uint16_t GREEN = 0x07E0;
constexpr uint16_t LOCKED = 0x4208;
const char* kNames[] = {"OC", "GPU", "Energia", "IA", "Discos",
                        "Fans", "Rede", "WoL", "Config"};
}

ShellCore::ShellCore(TFT_eSPI& tft) : tft_(tft) {}

void ShellCore::drawClock() {
  const int width=tft_.width(), center=width<300?width-30:width/2;
  char value[6] = "--:--";
  const time_t now = time(nullptr);
  if (LumiTime::valid(now)) {
    struct tm localTime;
    localtime_r(&now, &localTime);
    strftime(value, sizeof(value), "%H:%M", &localTime);
  }
  tft_.fillRect(center-28, 2, 56, 28, PANEL);
  tft_.setTextDatum(MC_DATUM);
  tft_.setTextColor(TFT_WHITE, PANEL);
  tft_.drawString(value, center, 16, 2);
}

void ShellCore::wifiIcon(int x, int y, uint16_t c) {
  tft_.drawCircle(x, y + 11, 2, c);
  tft_.drawArc(x, y + 10, 7, 6, 220, 320, c, PANEL);
  tft_.drawArc(x, y + 10, 12, 11, 220, 320, c, PANEL);
}
void ShellCore::bellIcon(int x, int y, uint16_t c) {
  tft_.drawCircle(x, y + 16, 2, c);
  tft_.drawLine(x - 6, y + 13, x + 6, y + 13, c);
  tft_.drawRoundRect(x - 5, y + 4, 10, 10, 5, c);
}
void ShellCore::header(const char* title, bool nav, bool wifi, bool sd) {
  const int width=tft_.width();
  tft_.fillRect(0, 0, width, 32, PANEL);
  tft_.setTextDatum(ML_DATUM);
  tft_.setTextColor(CYAN, PANEL);
  if (nav) {
    tft_.drawString("<", 10, 16, 4);
    tft_.drawRect(45, 12, 14, 11, TFT_WHITE);
    tft_.drawTriangle(43, 13, 52, 5, 61, 13, TFT_WHITE);
    String shortTitle=title;
    while(tft_.textWidth(shortTitle,2)>56&&shortTitle.length())shortTitle.remove(shortTitle.length()-1);
    tft_.drawString(shortTitle,72,16,2);
  } else {
    tft_.drawString("LumiOS", 10, 16, 4);
  }
  if(width<300){drawClock();return;}
  bellIcon(261, 5, AMBER);
  tft_.setTextDatum(MC_DATUM);
  tft_.setTextColor(sd ? GREEN : LOCKED, PANEL);
  tft_.drawString("SD", 285, 16, 1);
  wifiIcon(307, 5, wifi ? GREEN : TFT_RED);
  drawClock();
}

void ShellCore::label(const char* text, int x, int y, uint16_t c) {
  tft_.setTextDatum(MC_DATUM);
  tft_.setTextColor(c, BG);
  tft_.drawString(text, x, y, 2);
}

void ShellCore::icon(AppId id, int x, int y, uint16_t c) {
  switch (id) {
    case AppId::Wol:
      tft_.drawRoundRect(x + 3, y + 3, 26, 20, 3, c);
      tft_.drawLine(x + 10, y + 27, x + 22, y + 27, c);
      tft_.drawLine(x + 16, y + 23, x + 16, y + 27, c); break;
    case AppId::Gpu:
      tft_.drawRoundRect(x + 2, y + 5, 27, 20, 3, c);
      tft_.drawCircle(x + 18, y + 15, 6, c);
      for (int i=7;i<27;i+=5) tft_.drawLine(x+i,y+25,x+i,y+29,c); break;
    case AppId::Energy:
      tft_.fillTriangle(x+18,y+1,x+7,y+18,x+16,y+18,c);
      tft_.fillTriangle(x+16,y+14,x+26,y+14,x+12,y+31,c); break;
    case AppId::Ai:
      tft_.drawCircle(x+10,y+12,7,c); tft_.drawCircle(x+22,y+12,7,c);
      tft_.drawCircle(x+10,y+22,7,c); tft_.drawCircle(x+22,y+22,7,c);
      tft_.drawLine(x+16,y+5,x+16,y+29,c); break;
    case AppId::Disks:
      tft_.drawRoundRect(x+3,y+3,26,26,4,c); tft_.drawCircle(x+16,y+15,8,c);
      tft_.fillCircle(x+16,y+15,2,c); tft_.drawLine(x+16,y+15,x+23,y+9,c); break;
    case AppId::Fans:
      tft_.drawCircle(x+16,y+16,14,c); tft_.fillCircle(x+16,y+16,3,c);
      tft_.fillTriangle(x+16,y+13,x+12,y+3,x+20,y+3,c);
      tft_.fillTriangle(x+19,y+17,x+28,y+13,x+27,y+22,c);
      tft_.fillTriangle(x+14,y+19,x+12,y+29,x+5,y+23,c); break;
    case AppId::Network:
      tft_.drawCircle(x+16,y+15,12,c); tft_.drawLine(x+4,y+15,x+28,y+15,c);
      tft_.drawLine(x+16,y+3,x+16,y+27,c); tft_.drawEllipse(x+16,y+15,6,12,c); break;
    case AppId::Oc:
      tft_.drawArc(x+16,y+18,13,12,135,405,c,BG);
      tft_.drawLine(x+16,y+18,x+24,y+9,c); tft_.fillCircle(x+16,y+18,3,c); break;
    case AppId::Config:
      tft_.drawCircle(x+16,y+16,13,c); tft_.drawCircle(x+16,y+16,6,c);
      for(int a=0;a<8;a++){float r=a*PI/4;tft_.drawLine(x+16+cos(r)*13,y+16+sin(r)*13,x+16+cos(r)*16,y+16+sin(r)*16,c);} break;
    default: break;
  }
}

void ShellCore::home(bool wifi,bool sd,bool server,const StoreCore& apps,unsigned page){
 tft_.fillScreen(BG);header("LumiOS",false,wifi,sd);
 const bool portrait=tft_.width()<tft_.height();
 const unsigned pages=(apps.count+3+8)/9;page%=pages;
 tft_.setTextDatum(MC_DATUM);tft_.setTextColor(DIM,PANEL);
 tft_.drawString(String(page+1)+"/"+String(pages),218,portrait?42:16,1);
 const AppId system[]={AppId::Wol,AppId::Network,AppId::Config};
 const char* names[]={"WoL","Rede","Config"};
 for(unsigned slot=0;slot<9;slot++){
  unsigned index=page*9+slot;if(index>=apps.count+3)break;
  int x=portrait?40+(slot%3)*80:53+(slot%3)*107;
  int y=portrait?63+(slot/3)*83:39+(slot/3)*67;
  if(index<3){icon(system[index],x-16,y,BLUE);label(names[index],x,y+43,TFT_WHITE);}
  else{
   const auto& e=apps.entries[index-3];uint16_t c=e.requiresServer&&!server?LOCKED:CYAN;
   AppId app=AppId::None;
   String iconName=e.icon.length()?e.icon:e.id;
   if(iconName=="gpu")app=AppId::Gpu;else if(iconName=="energia")app=AppId::Energy;
   else if(iconName=="ia")app=AppId::Ai;else if(iconName=="discos")app=AppId::Disks;
   else if(iconName=="fans")app=AppId::Fans;else if(iconName=="oc")app=AppId::Oc;
   if(!const_cast<StoreCore&>(apps).drawIcon(index-3,tft_,x-16,y)){
    if(app!=AppId::None)icon(app,x-16,y,c);else {tft_.drawRoundRect(x-16,y,32,32,5,c);tft_.setTextDatum(MC_DATUM);tft_.setTextColor(c,BG);tft_.drawString("Lua",x,y+16,2);}
   }
   String name=e.name;while(tft_.textWidth(name,2)>(portrait?76:98)&&name.length())name.remove(name.length()-1);
   label(name.c_str(),x,y+43,c);
  }
 }
}
void ShellCore::luaPage(const char* name,bool wifi,bool sd){
 tft_.fillScreen(BG);header(name,true,wifi,sd);
}

AppId ShellCore::homeHit(int16_t x,int16_t y) const {
  if(y<50||y>135)return AppId::None;uint8_t col=min(2,max(0,x/107));
  return col==0?AppId::Wol:(col==1?AppId::Network:AppId::Config);
}
bool ShellCore::alertHit(int16_t x,int16_t y) const{return x>=240&&x<278&&y<32;}
bool ShellCore::backHit(int16_t x,int16_t y) const{return x<40&&y<32;}
bool ShellCore::homeButtonHit(int16_t x,int16_t y) const{return x>=40&&x<68&&y<32;}
bool ShellCore::storageRefreshHit(int16_t x,int16_t y) const{return x>=50&&x<=270&&y>=150&&y<=184;}
bool ShellCore::storageTestHit(int16_t x,int16_t y) const{return x>=50&&x<=270&&y>=194&&y<=230;}
bool ShellCore::confirmHit(int16_t x,int16_t y) const{
 if(tft_.width()<tft_.height())return x>=16&&x<=224&&y>=249&&y<=297;
 return x>=50&&x<=270&&y>=178&&y<=226;
}
bool ShellCore::networkScanHit(int16_t x,int16_t y) const{return x>=30&&x<=290&&y>=154&&y<=190;}
bool ShellCore::wolHit(int16_t x,int16_t y) const{
 if(tft_.width()<tft_.height())return x>=16&&x<=224&&y>=215&&y<=275;
 return x>=35&&x<=285&&y>=156&&y<=211;
}
int8_t ShellCore::appManagerRowHit(int16_t x,int16_t y) const{if(x<8||x>312||y<39||y>=219)return -1;return (y-39)/30;}
bool ShellCore::systemUpdateHit(int16_t x,int16_t y) const{
 if(tft_.width()<tft_.height()){
   const int top=tft_.height()-68;
   return x>=12&&x<tft_.width()-12&&y>=top&&y<top+40;
 }
 return x>=50&&x<=270&&y>=174&&y<=206;
}
bool ShellCore::networkForgetHit(int16_t x,int16_t y) const{return x>=30&&x<=290&&y>=198&&y<=232;}
int8_t ShellCore::networkRowHit(int16_t x,int16_t y) const{
  if(x<8||x>312||y<39||y>=199)return -1; return (y-39)/32;
}
int8_t ShellCore::networkPageHit(int16_t x,int16_t y) const{
  if(y<204||y>235)return 0;if(x<95)return -1;if(x>225)return 1;return 0;
}

void ShellCore::button(int y,const char* text,uint16_t color){
  tft_.fillRoundRect(50,y,220,32,6,color);label(text,160,y+16,TFT_WHITE);
}

void ShellCore::serverPage(bool wifi,bool sd,bool server,const char* mac){
  tft_.fillScreen(BG);header("WoL",true,wifi,sd);
  if(tft_.width()<tft_.height()){
   label("CONTROLO DE ENERGIA",120,65,CYAN);
   label(server?"SERVIDOR LIGADO":"SERVIDOR DESLIGADO",120,103,server?GREEN:TFT_RED);
   label(mac,120,138,DIM);
   label(wifi?"Wi-Fi pronto":"Ligue o Wi-Fi primeiro",120,180,wifi?GREEN:TFT_RED);
   tft_.fillRoundRect(16,215,208,60,8,wifi?(server?TFT_RED:BLUE):LOCKED);
   label(server?"DESLIGAR SERVIDOR":"LIGAR SERVIDOR",120,245,wifi?TFT_WHITE:DIM);
   label(server?"LumiCore ligado":"A aguardar o lumicore",120,299,server?GREEN:LOCKED);return;
  }
  label("CONTROLO DE ENERGIA",160,55,CYAN);label(server?"SERVIDOR LIGADO":"SERVIDOR DESLIGADO",160,82,server?GREEN:TFT_RED);
  label(mac,160,108,DIM);
  label(wifi?"Wi-Fi pronto":"Ligue o Wi-Fi primeiro",160,134,wifi?GREEN:TFT_RED);
  tft_.fillRoundRect(35,156,250,55,8,wifi?(server?TFT_RED:BLUE):LOCKED);
  label(server?"DESLIGAR SERVIDOR":"LIGAR SERVIDOR",160,183,wifi?TFT_WHITE:DIM);
  label(server?"LumiCore ligado":"A aguardar o lumicore",160,226,server?GREEN:LOCKED);
}
void ShellCore::powerResult(bool sent,bool shutdown,bool wifi,bool sd,const String& detail,bool pending){
  tft_.fillScreen(BG);header(shutdown?"Desligar":"Wake-on-LAN",true,wifi,sd);
  if(shutdown){
   const int width=tft_.width(),height=tft_.height(),center=width/2;
   label(pending?"A ENVIAR PEDIDO":(sent?"DESLIGAR AGENDADO":"PEDIDO FALHOU"),center,height<300?82:98,pending?AMBER:(sent?GREEN:TFT_RED));
   tft_.setTextFont(height<300?1:2);tft_.setTextColor(TFT_WHITE,BG);tft_.setTextDatum(TL_DATUM);
   tft_.setTextWrap(true,false);tft_.setCursor(14,height<300?115:140);
   tft_.println(detail);tft_.setTextWrap(false,false);
   const int y=height-71;
   tft_.fillRoundRect(16,y,width-32,48,6,BLUE);label("CONTINUAR",center,y+24,TFT_WHITE);
   return;
  }
  if(tft_.width()<tft_.height()){
   label(sent?(shutdown?"PEDIDO ENVIADO":"MAGIC PACKET ENVIADO"):"ENVIO NAO REALIZADO",120,100,sent?GREEN:TFT_RED);
   label(sent?(shutdown?"A aguardar o servidor":"O servidor deve arrancar"):"Servico indisponivel",120,157,TFT_WHITE);
   label(shutdown?"LumiCore: desligar":"UDP broadcast - porta 9",120,200,DIM);
   tft_.fillRoundRect(16,249,208,48,6,BLUE);label("CONTINUAR",120,273,TFT_WHITE);return;
  }
  label(sent?(shutdown?"PEDIDO ENVIADO":"MAGIC PACKET ENVIADO"):"ENVIO NAO REALIZADO",160,86,sent?GREEN:TFT_RED);
  label(sent?(shutdown?"A aguardar o servidor":"O servidor deve arrancar"):"Servico indisponivel",160,126,TFT_WHITE);
  label(shutdown?"LumiCore: desligar":"UDP broadcast - porta 9",160,155,DIM);button(184,"CONTINUAR",BLUE);
}
void ShellCore::shutdownWarning(uint8_t step,bool wifi,bool sd){
  tft_.fillScreen(BG);header(step==1?"Desligar servidor":"Confirmacao final",true,wifi,sd);
  if(tft_.width()<tft_.height()){
   label("DESLIGAR O SERVIDOR?",120,94,TFT_RED);
   label(step==1?"As tarefas terminarao":"Esta acao e imediata",120,145,TFT_WHITE);
   label(step==1?"Confirme para continuar":"Confirme novamente",120,191,DIM);
   tft_.fillRoundRect(16,249,208,48,6,TFT_RED);label(step==1?"CONTINUAR":"DESLIGAR",120,273,TFT_WHITE);return;
  }
  label("DESLIGAR O SERVIDOR?",160,73,TFT_RED);
  label(step==1?"As tarefas em curso terminarao":"Esta acao e imediata",160,116,TFT_WHITE);
  label(step==1?"Confirme para continuar":"Confirme novamente",160,145,DIM);
  button(184,step==1?"CONTINUAR":"DESLIGAR",TFT_RED);
}
void ShellCore::networkPage(const NetworkCore& net,bool sd){
  const bool wifi=net.online();
  tft_.fillScreen(BG);header("Rede",true,wifi,sd);
  label(wifi?"WI-FI LIGADO":"WI-FI DESLIGADO",160,54,wifi?GREEN:TFT_RED);
  if(wifi){
    String name=net.ssid();if(name.length()>25)name=name.substring(0,22)+"...";
    label(name.c_str(),160,82,TFT_WHITE);
    label(("IP: "+net.ip()).c_str(),160,106,DIM);
    label(("Sinal: "+String(net.rssi())+" dBm").c_str(),160,130,DIM);
  }else{
    label(net.hasSavedNetwork()?"A tentar rede guardada":"Nenhuma rede configurada",160,94,DIM);
  }
  tft_.fillRoundRect(30,154,260,36,6,BLUE);label("PROCURAR REDES",160,172,TFT_WHITE);
  if(wifi){tft_.fillRoundRect(30,198,260,34,6,TFT_RED);label("ESQUECER REDE",160,215,TFT_WHITE);}
}
void ShellCore::networkScanning(bool wifi,bool sd){
  tft_.fillScreen(BG);header("Rede",true,wifi,sd);label("A PROCURAR REDES...",160,105,CYAN);
  label("Aguarde alguns segundos",160,139,DIM);
}
void ShellCore::networkList(const NetworkCore& net,uint8_t first,bool sd){
  tft_.fillScreen(BG);header("Redes Wi-Fi",true,net.online(),sd);
  if(!net.count()){label("Nenhuma rede encontrada",160,105,TFT_RED);button(164,"PROCURAR NOVAMENTE",BLUE);return;}
  for(uint8_t row=0;row<5;row++){
    uint8_t i=first+row;if(i>=net.count())break;const WifiEntry& e=net.entry(i);
    int y=39+row*32;tft_.fillRoundRect(8,y,304,28,4,PANEL);
    String name=e.ssid;if(name.length()>22)name=name.substring(0,19)+"...";
    tft_.setTextDatum(ML_DATUM);tft_.setTextColor(TFT_WHITE,PANEL);tft_.drawString(name,15,y+14,2);
    tft_.setTextDatum(MR_DATUM);tft_.setTextColor(e.rssi>-65?GREEN:(e.rssi>-78?AMBER:TFT_RED),PANEL);
    tft_.drawString((String(e.rssi)+(e.secured?"  L":"  A")).c_str(),303,y+14,1);
  }
  tft_.setTextDatum(MC_DATUM);tft_.setTextColor(DIM,BG);
  tft_.drawString(first?"< ANTERIOR":"",54,220,2);
  tft_.drawString(first+5<net.count()?"SEGUINTE >":"",266,220,2);
}
void ShellCore::networkConnecting(const String& ssid,bool sd){
  tft_.fillScreen(BG);header("Rede",true,false,sd);label("A LIGAR...",160,91,CYAN);
  String name=ssid;if(name.length()>25)name=name.substring(0,22)+"...";label(name.c_str(),160,125,TFT_WHITE);
  label("Tempo limite: 15 segundos",160,161,DIM);
}
void ShellCore::networkResult(bool success,const String& ssid,bool sd){
  tft_.fillScreen(BG);header("Rede",true,success,sd);
  label(success?"LIGACAO CONCLUIDA":"NAO FOI POSSIVEL LIGAR",160,82,success?GREEN:TFT_RED);
  String name=ssid;if(name.length()>25)name=name.substring(0,22)+"...";label(name.c_str(),160,119,TFT_WHITE);
  label(success?"Credenciais guardadas":"Verifique a palavra-passe",160,151,DIM);
  button(184,"CONTINUAR",BLUE);
}
void ShellCore::configPage(bool wifi,bool sd){
  tft_.fillScreen(BG);header("Config",true,wifi,sd);
  const char* rows[]={"ECRA E BRILHO  >","CARTAO SD  >","GESTOR APLICACOES  >","PARTILHAR SD  >","RESET / RECOVERY  >","ACERCA  >"};
  const bool portrait=tft_.width()<tft_.height();
  for(uint8_t i=0;i<6;i++){int y=portrait?42+i*44:38+i*33;
   tft_.fillRoundRect(12,y,tft_.width()-24,portrait?38:28,5,PANEL);
   label(rows[i],tft_.width()/2,y+(portrait?19:14),i==4?TFT_RED:(i==5?DIM:TFT_WHITE));}
}
void ShellCore::resetPage(bool unavailable,bool wifi,bool sd){
 tft_.fillScreen(BG);header("Reset",true,wifi,sd);
 const bool portrait=tft_.width()<tft_.height();const int center=tft_.width()/2;
 const int first=portrait?68:54;const int step=portrait?29:23;
 const char* warning[]={"REPOR O SERVIDOR?","Ubuntu basico + setup","Remove contas e conversas","Remove configuracoes","Confirmar a reposicao?"};
 const char* pending[]={"RESET INDISPONIVEL","Imagem de recuperacao","ainda nao preparada.","Nada foi alterado.","Volte apos a preparacao."};
 for(int i=0;i<5;i++)label(unavailable?pending[i]:warning[i],center,first+i*step,i==0?TFT_RED:DIM);
 const int y=portrait?249:178;const int x=portrait?16:50;const int w=portrait?208:220;
 tft_.fillRoundRect(x,y,w,48,6,unavailable?BLUE:TFT_RED);
 label(unavailable?"VOLTAR":"CONFIRMAR RESET",center,y+24,TFT_WHITE);
}
void ShellCore::recoveryPage(uint8_t selected,bool wifi,bool sd){
 tft_.fillScreen(BG);header("Recovery",true,wifi,sd);
 const char* rows[]={"RECOVERY LINUX (RAM)","CRIAR BACKUP DATA", "RESTAURAR BACKUP", "PARTICIONAR SSD", "REPOR UBUNTU BASE", "RESET DE FABRICA"};
 const bool portrait=tft_.width()<tft_.height();const int top=portrait?39:37;const int step=portrait?42:29;const int height=portrait?36:25;
 for(uint8_t i=0;i<6;i++){int y=top+i*step;uint16_t c=(i==selected)?BLUE:PANEL;tft_.fillRoundRect(8,y,tft_.width()-16,height,4,c);tft_.setTextDatum(MC_DATUM);tft_.setTextColor((i>=2)?TFT_WHITE:TFT_WHITE,c);String labelText=rows[i];while(tft_.textWidth(labelText,2)>tft_.width()-30&&labelText.length())labelText.remove(labelText.length()-1);tft_.drawString(labelText,tft_.width()/2,y+height/2,2);}
}
void ShellCore::recoveryConfirmPage(uint8_t selected,bool wifi,bool sd){
 tft_.fillScreen(BG);header("Confirmar",true,wifi,sd);
 const char* names[]={"RECOVERY LINUX (RAM)","CRIAR BACKUP DATA", "RESTAURAR BACKUP", "PARTICIONAR SSD", "REPOR UBUNTU BASE", "RESET DE FABRICA"};
 const char* desc[]={"Reiniciar em Linux RAM","Copiar dados para backup","Substituir dados atuais","APAGA / recria particoes","Restaurar imagem Ubuntu","APAGA dados e conversas"};
 const bool portrait=tft_.width()<tft_.height();const int center=tft_.width()/2;
 label("CONFIRMACAO EXPLICITA",center,portrait?66:54,AMBER);label(names[selected],center,portrait?103:82,TFT_WHITE);label(desc[selected],center,portrait?135:109,(selected>=2)?TFT_RED:DIM);
 if(selected==3||selected==4||selected==5)label("OPERACAO DESTRUTIVA",center,portrait?165:132,TFT_RED);
 int y=portrait?230:164;int h=portrait?42:38;int margin=portrait?10:12;int gap=8;int w=(tft_.width()-2*margin-gap)/2;
 tft_.fillRoundRect(margin,y,w,h,5,BLUE);tft_.fillRoundRect(margin+w+gap,y,w,h,5,TFT_RED);
 tft_.setTextDatum(MC_DATUM);tft_.setTextColor(TFT_WHITE,BLUE);tft_.drawString("CANCELAR",margin+w/2,y+h/2,2);tft_.setTextColor(TFT_WHITE,TFT_RED);tft_.drawString("CONFIRMAR",margin+w+gap+w/2,y+h/2,2);
}
void ShellCore::recoveryResultPage(bool success,const String& message,bool wifi,bool sd){
 tft_.fillScreen(BG);header("Recovery",true,wifi,sd);label(success?"PEDIDO ACEITE":"PEDIDO RECUSADO",tft_.width()/2,tft_.height()<300?70:92,success?GREEN:TFT_RED);
 String m=message;if(m.length()>48)m=m.substring(0,45)+"...";label(m.c_str(),tft_.width()/2,tft_.height()/2,DIM);
 const bool portrait=tft_.width()<tft_.height();button(portrait?250:184,"VOLTAR",BLUE);
}
int8_t ShellCore::recoveryRowHit(int16_t x,int16_t y) const{if(x<8||x>tft_.width()-8)return -1;bool portrait=tft_.width()<tft_.height();int top=portrait?39:37,step=portrait?42:29,height=portrait?36:25;if(y<top||y>=top+6*step)return -1;int row=(y-top)/step;return y<top+row*step+height?row:-1;}
bool ShellCore::recoveryCancelHit(int16_t x,int16_t y) const{bool portrait=tft_.width()<tft_.height();int yy=portrait?230:164;int margin=portrait?10:12;int w=(tft_.width()-2*margin-8)/2;return y>=yy&&y<yy+(portrait?42:38)&&x>=margin&&x<margin+w;}
bool ShellCore::recoveryConfirmHit(int16_t x,int16_t y) const{bool portrait=tft_.width()<tft_.height();int yy=portrait?230:164;int margin=portrait?10:12;int w=(tft_.width()-2*margin-8)/2;return y>=yy&&y<yy+(portrait?42:38)&&x>=margin+w+8&&x<tft_.width()-margin;}

void ShellCore::appsPage(const StoreCore& apps,bool wifi,bool sd,unsigned page,bool packages){
 tft_.fillScreen(BG);header("Apps",true,wifi,sd);
 tft_.drawFastVLine(159,36,169,DIM);
 label("Mem interna",78,45,CYAN);label(packages?"Pacotes SD":"Instaladas SD",240,45,CYAN);
 label("WoL",78,76,TFT_WHITE);label("Rede",78,101,TFT_WHITE);label("Config",78,126,TFT_WHITE);
 label("Sistema fixo",78,153,DIM);
 unsigned count=packages?apps.packageCount:apps.count;
 unsigned pages=max(1U,(count+4)/5);page%=pages;
 for(unsigned i=0;i<5&&page*5+i<count;i++){
  String n=packages?apps.packages[page*5+i]:apps.entries[page*5+i].name;
  while(tft_.textWidth(n,2)>144&&n.length())n.remove(n.length()-1);
  tft_.fillRoundRect(164,59+i*23,152,21,3,PANEL);label(n.c_str(),240,69+i*23,TFT_WHITE);
 }
 if(!count)label(packages?"Sem pacotes":"Sem apps",240,84,DIM);
 label("<",180,185,CYAN);label((String(page+1)+"/"+String(pages)).c_str(),240,185,DIM);label(">",300,185,CYAN);
 tft_.fillRoundRect(5,174,148,25,3,BLUE);label(packages?"VER INSTALADAS":"VER PACOTES",79,186,TFT_WHITE);
 tft_.setTextDatum(MC_DATUM);tft_.setTextColor(DIM,BG);
 tft_.drawString("FW "+String(ESP.getSketchSize()/1024)+"/1856 KiB",80,211,1);
 tft_.drawString(sd?String(double(apps.used)/1048576.0,1)+"/"+String(double(apps.total)/1048576.0,1)+" MiB":"SD indisponivel",240,211,1);
 tft_.drawString(packages&&apps.packageLimit?"Limite: 64 pacotes; use o gestor web":"Toque numa app ou pacote para gerir",160,231,1);
}

void ShellCore::sdSharePage(bool active,bool wifi,bool sd,const String& address){
 tft_.fillScreen(BG);header("Partilhar SD",true,wifi,sd);label(active?"PARTILHA ATIVA":"PARTILHA INATIVA",160,68,active?GREEN:TFT_RED);
 label(address.c_str(),160,105,TFT_WHITE);label(active?"SD reservado pela rede":"Requer Wi-Fi e cartao SD",160,137,DIM);
 button(174,active?"PARAR E DESMONTAR":"INICIAR PARTILHA",active?TFT_RED:BLUE);
}
void ShellCore::systemPage(bool wifi,bool sd,const String& identity){
 tft_.fillScreen(BG);header("Acerca",true,wifi,sd);
 if(tft_.width()<tft_.height()){
   const int width=tft_.width(),height=tft_.height(),center=width/2;
   const int top=height-68;
   label("LumiOS " LUMIOS_VERSION,center,49,CYAN);
   // Confine wrapping to the body; long host/OS names cannot overlap the button.
   tft_.setViewport(12,68,width-24,top-84);
   tft_.setTextFont(2);tft_.setTextColor(TFT_WHITE,BG);
   tft_.setTextWrap(true,false);tft_.setCursor(0,0);
   tft_.println(identity);
   tft_.resetViewport();tft_.setTextWrap(false,false);
   tft_.fillRoundRect(12,top,width-24,40,6,wifi?BLUE:LOCKED);
   label("ATUALIZAR PELO GITHUB",center,top+20,wifi?TFT_WHITE:DIM);
   label("CYD | ia.local",center,height-12,DIM);
   return;
 }
 label("LumiOS " LUMIOS_VERSION " | CYD",160,49,CYAN);
 int start=0,y=73;while(start<int(identity.length())&&y<=145){int end=identity.indexOf('\n',start);if(end<0)end=identity.length();String line=identity.substring(start,end);if(line.length()>42)line=line.substring(0,42);label(line.c_str(),160,y,TFT_WHITE);start=end+1;y+=18;}
 button(174,"ATUALIZAR PELO GITHUB",wifi?BLUE:LOCKED);label("ia.local",160,220,DIM);
}
void ShellCore::otaProgress(bool wifi,bool sd){
 tft_.fillScreen(BG);header("Atualizacao OTA",false,wifi,sd);label("A CONTACTAR O GITHUB",160,96,CYAN);label("Nao desligar o LumiOS",160,137,AMBER);
}
void ShellCore::otaResult(bool success,const String& message,bool wifi,bool sd){
 tft_.fillScreen(BG);header("Atualizacao OTA",true,wifi,sd);label(success?"ATUALIZACAO CONCLUIDA":"ATUALIZACAO INDISPONIVEL",160,78,success?GREEN:TFT_RED);
 String text=message;if(text.length()>36)text=text.substring(0,36);label(text.c_str(),160,120,TFT_WHITE);button(184,"CONTINUAR",BLUE);
}
void ShellCore::drawBrightness(uint8_t value){
  if(tft_.width()<tft_.height()){
   tft_.fillRect(16,112,208,58,BG);tft_.fillRoundRect(25,130,190,14,5,LOCKED);
   tft_.fillRoundRect(25,130,map(value,5,100,3,190),14,5,CYAN);
   label((String(value)+"%").c_str(),120,160,TFT_WHITE);return;
  }
  tft_.fillRect(35,96,250,62,BG);tft_.fillRoundRect(45,112,230,14,5,LOCKED);
  int w=map(value,5,100,3,230);tft_.fillRoundRect(45,112,w,14,5,CYAN);
  label((String(value)+"%").c_str(),160,148,TFT_WHITE);
}
void ShellCore::displayPage(uint8_t value,bool wifi,bool sd,uint16_t orientation,bool superMemory){
  if(tft_.width()<tft_.height()){
   tft_.fillScreen(BG);header("Ecra",true,wifi,sd);label("BRILHO",120,88,TFT_WHITE);drawBrightness(value);
   tft_.fillRoundRect(12,190,216,43,5,BLUE);
   label((String("ORIENTACAO: ")+String(orientation)+" GRAUS").c_str(),120,211,TFT_WHITE);
   tft_.fillRoundRect(12,249,216,43,5,superMemory?GREEN:BLUE);
   label(superMemory?"LUA SUPER-MEMORY: SIM":"LUA SUPER-MEMORY: NAO",120,270,TFT_WHITE);return;
  }
  tft_.fillScreen(BG);header("Ecra",true,wifi,sd);label("BRILHO",160,72,TFT_WHITE);drawBrightness(value);
  button(170,(String("ORIENTACAO: ")+String(orientation)+" GRAUS").c_str(),BLUE);
  button(210,superMemory?"LUA SUPER-MEMORY: SIM":"LUA SUPER-MEMORY: NAO",superMemory?GREEN:BLUE);
}
void ShellCore::storagePage(const SdReport& r,bool wifi){
  tft_.fillScreen(BG);header("Cartao SD",true,wifi,r.state==SdState::Ready);
  label(r.state==SdState::Ready?"CARTAO PRONTO":"CARTAO INDISPONIVEL",160,55,r.state==SdState::Ready?GREEN:TFT_RED);
  String cap=r.capacityBytes?String((double)r.capacityBytes/1073741824.0,2)+" GB":"--";
  String used=r.capacityBytes?String((double)r.usedBytes/1048576.0,1)+" MB":"--";
  String freeText=r.capacityBytes?String((double)(r.capacityBytes-r.usedBytes)/1048576.0,1)+" MB":"--";
  label(("Capacidade: "+cap).c_str(),160,82,TFT_WHITE);
  label(("Usado: "+used+"   Livre: "+freeText).c_str(),160,109,DIM);
  button(150,"VERIFICAR NOVAMENTE",BLUE);
  if(r.state==SdState::Ready) button(194,"APAGAR E TESTAR",TFT_RED);
}
void ShellCore::storageWarning(uint8_t step,bool wifi,bool sd){
  tft_.fillScreen(BG);header(step==1?"Atencao":"Confirmacao final",true,wifi,sd);
  label("TODOS OS DADOS SERAO",160,70,TFT_RED);label("APAGADOS",160,101,TFT_RED);
  label(step==1?"Teste integral + formatacao":"Nao desligar durante o teste",160,143,TFT_WHITE);
  button(184,step==1?"CONTINUAR":"CONFIRMAR E APAGAR",TFT_RED);
}
void ShellCore::storageProgress(SdTestPhase phase,uint8_t pct){
  const char* names[]={"A ESCREVER","A VERIFICAR","A FORMATAR","A PREPARAR"};
  static int8_t old=-1;
  if(old!=static_cast<int8_t>(phase)){
    old=static_cast<int8_t>(phase);tft_.fillScreen(BG);header("Teste SD",false,false,true);
    label(names[static_cast<uint8_t>(phase)],160,77,TFT_WHITE);
  }
  tft_.fillRoundRect(20,111,280,18,5,LOCKED);
  if(pct)tft_.fillRoundRect(20,111,max(3,(int)(2.8f*pct)),18,5,GREEN);
  tft_.fillRect(110,143,100,42,BG);label((String(pct)+"%").c_str(),160,163,TFT_WHITE);
  label("NAO DESLIGAR",160,210,AMBER);
}
void ShellCore::storageResult(SdTestResult result,bool wifi,bool sd){
  tft_.fillScreen(BG);header("Resultado SD",true,wifi,sd);
  bool ok=result==SdTestResult::Passed;label(ok?"CARTAO SAUDAVEL":"TESTE FALHOU",160,82,ok?GREEN:TFT_RED);
  label(ok?"Preparado para LumiOS":"Consulte o monitor serie",160,126,TFT_WHITE);
  button(184,"VOLTAR AO GESTOR",BLUE);
}
void ShellCore::alertsPage(bool wifi,bool sd){
  tft_.fillScreen(BG);header("Alertas",true,wifi,sd);bellIcon(160,58,AMBER);label("Sem alertas locais",160,126,TFT_WHITE);
  label("LumiCore indisponivel",160,158,LOCKED);
}
void ShellCore::lockedNotice(){
  tft_.fillRoundRect(48,95,224,50,7,TFT_RED);label("LUMICORE INDISPONIVEL",160,120,TFT_WHITE);
}
