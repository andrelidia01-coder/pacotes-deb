#pragma once
#include <Arduino.h>

class OtaCore{
 public:
  bool install();
  const String& message()const{return message_;}
 private:
  String message_;
};
