#pragma once
#include <Arduino.h>
#include <TFT_eSPI.h>
#include <LuaWrapper.h>
class LuaCore {
 public:
 void begin() {}
 bool start(const String& source,TFT_eSPI& display,const String& appId="app",bool superMemory=false);
 void stop();
 void touch(int x,int y);
 void tick();
 const String& lastError()const{return error_;}
 bool active()const{return L_!=nullptr;}
 private:
 lua_State* L_=nullptr;TFT_eSPI* tft_=nullptr;size_t used_=0,limit_=64*1024;
 unsigned budget_=0,line_=0;uint32_t deadline_=0,lastTick_=0;bool dirty_=false;
 String error_,disksError_,storageNamespace_="app";
 static LuaCore* self(lua_State*);
 static void* allocate(void*,void*,size_t,size_t);
 static void hook(lua_State*,lua_Debug*);
 static int init(lua_State*);
 static int print(lua_State*);
 static int clear(lua_State*);
 static int text(lua_State*);
 static int button(lua_State*);
 static int redraw(lua_State*);
 static int millisFn(lua_State*);
 static int memoryInfo(lua_State*);
 static int storageGetNumber(lua_State*);
 static int storageSetNumber(lua_State*);
 static int pixel(lua_State*);
 static int line(lua_State*);
 static int rect(lua_State*);
 static int fillRect(lua_State*);
 static int circle(lua_State*);
 static int fillCircle(lua_State*);
 static int arc(lua_State*);
 static int fillArc(lua_State*);
 static int triangle(lua_State*);
 static int fillTriangle(lua_State*);
 TFT_eSprite* strip_=nullptr;int stripY_=32;bool stripActive_=false;
 static int beginStrip(lua_State*);
 static int stripRect(lua_State*);
 static int stripText(lua_State*);
 static int presentStrip(lua_State*);
 static int telemetryOnline(lua_State*);
 static int telemetryGet(lua_State*);
 static int telemetryPage(lua_State*);
 void pollDisks();
 struct DiskRow {String mount,device,fs;double total=0,used=0,free=0,percent=0;bool valid=false;};
 DiskRow disks_[3];unsigned diskCount_=0,diskPage_=0,diskPages_=1,diskTotal_=0;
 uint32_t diskPoll_=0;bool energyTopic_=false,disksRequested_=false,disksOnline_=false,disksPending_=true;
 bool call(const char* name,int args=0);
 bool result(int code);
 void draw();
};
