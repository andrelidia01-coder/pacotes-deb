#pragma once
#include <Arduino.h>
#include <WiFiUdp.h>

class WolCore {
 public:
  const char* mac() const;
  bool send();
 private:
  WiFiUDP udp_;
  bool parseMac(uint8_t mac[6]) const;
};
