#include "LuaCore.h"
#include "LumiCoreClient.h"
#include <esp_heap_caps.h>
#include <new>
#include <stdlib.h>
#include <HTTPClient.h>
#include <WiFi.h>
#include <cJSON.h>
#include <math.h>
#include <ctype.h>
#include <SdFat.h>
#include <SPI.h>
#include "ServerCore.h"
#include "DisksTelemetry.h"
#include "hardware_pins.h"

namespace {
bool validStorageKey(const char* key){
 if(!key)return false;size_t n=strlen(key);if(n<1||n>32)return false;
 for(size_t i=0;i<n;i++)if(!isalnum((unsigned char)key[i])&&key[i]!='_'&&key[i]!='-')return false;
 return true;
}
void beginLuaSd(){
 SPI.end();SPI.begin(HardwarePins::SD_SCLK,HardwarePins::SD_MISO,HardwarePins::SD_MOSI,HardwarePins::SD_CS);
 pinMode(HardwarePins::SD_CS,OUTPUT);digitalWrite(HardwarePins::SD_CS,HIGH);
}
void restoreLuaTouch(){
 SPI.end();SPI.begin(HardwarePins::TOUCH_SCLK,HardwarePins::TOUCH_MISO,HardwarePins::TOUCH_MOSI,HardwarePins::TOUCH_CS);
 pinMode(HardwarePins::TOUCH_CS,OUTPUT);digitalWrite(HardwarePins::TOUCH_CS,HIGH);
}
SdSpiConfig luaSdConfig(){return SdSpiConfig(HardwarePins::SD_CS,DEDICATED_SPI|USER_SPI_BEGIN,SD_SCK_MHZ(12),&SPI);}
}
LuaCore* LuaCore::self(lua_State* L){return *(LuaCore**)lua_getextraspace(L);}
void* LuaCore::allocate(void* ctx,void* ptr,size_t old,size_t n){
 LuaCore* c=(LuaCore*)ctx;if(!ptr)old=0;
 if(!n){free(ptr);c->used_-=old;return nullptr;}
 if(n>c->limit_-(c->used_-old))return nullptr;
 void* p=realloc(ptr,n);if(p)c->used_=c->used_-old+n;return p;
}
void LuaCore::hook(lua_State* L,lua_Debug*){
 LuaCore* c=self(L);
 if(++c->budget_>=80||(int32_t)(::millis()-c->deadline_)>=0)luaL_error(L,"Limite de execucao Lua");
}
int LuaCore::init(lua_State* L){
 LumiCoreClient::install(L);
 const luaL_Reg libs[]={{"_G",luaopen_base},{"table",luaopen_table},{"string",luaopen_string},{"math",luaopen_math},{nullptr,nullptr}};
 for(auto p=libs;p->name;p++){luaL_requiref(L,p->name,p->func,1);lua_pop(L,1);}
 const char* deny[]={"dofile","loadfile","load","collectgarbage","pcall","xpcall","setmetatable",nullptr};
 for(auto p=deny;*p;p++){lua_pushnil(L);lua_setglobal(L,*p);}
 lua_pushcfunction(L,print);lua_setglobal(L,"print");
 const luaL_Reg api[]={
  {"clear",clear},{"text",text},{"button",button},{"redraw",redraw},{"millis",millisFn},{"memory",memoryInfo},
  {"pixel",pixel},{"line",line},{"rect",rect},{"fillRect",fillRect},
  {"circle",circle},{"fillCircle",fillCircle},{"arc",arc},{"fillArc",fillArc},
  {"triangle",triangle},{"fillTriangle",fillTriangle},
  {"beginStrip",beginStrip},{"stripRect",stripRect},{"stripText",stripText},{"presentStrip",presentStrip},{nullptr,nullptr}};
 luaL_newlib(L,api);lua_setglobal(L,"ui");
 const luaL_Reg storageApi[]={{"getNumber",storageGetNumber},{"setNumber",storageSetNumber},{nullptr,nullptr}};
 luaL_newlib(L,storageApi);lua_setglobal(L,"storage");
 const luaL_Reg tel[]={{"online",telemetryOnline},{"get",telemetryGet},{"page",telemetryPage},{nullptr,nullptr}};
 luaL_newlib(L,tel);lua_pushinteger(L,2);lua_setfield(L,-2,"api");lua_pushboolean(L,1);lua_setfield(L,-2,"energy_supported");lua_pushboolean(L,1);lua_setfield(L,-2,"gpu_supported");lua_setglobal(L,"telemetry");return 0;
}
int LuaCore::print(lua_State* L){
 LuaCore* c=self(L);char line[121]={};size_t at=0;
 for(int i=1;i<=lua_gettop(L)&&at<120;i++){
  const char* s=lua_tostring(L,i);if(!s)s=lua_typename(L,lua_type(L,i));
  if(i>1&&at<120)line[at++]=' ';
  while(*s&&at<120)line[at++]=*s++;
 }
 line[at]=0;Serial.println(line);
 int y=42+(c->line_++%9)*20;c->tft_->fillRect(0,y,320,20,0x0863);
 c->tft_->setTextDatum(TL_DATUM);c->tft_->setTextColor(TFT_WHITE,0x0863);
 line[39]=0;c->tft_->drawString(line,6,y,2);return 0;
}
int LuaCore::clear(lua_State* L){auto c=self(L);int color=luaL_checkinteger(L,1);c->tft_->fillRect(0,32,320,208,(uint16_t)color);return 0;}
int LuaCore::text(lua_State* L){
 auto c=self(L);const char* s=luaL_checkstring(L,1);if(strlen(s)>120)return luaL_error(L,"Texto demasiado longo");
 int x=constrain((int)luaL_checkinteger(L,2),0,319),y=constrain((int)luaL_checkinteger(L,3),32,239);
 int font=luaL_optinteger(L,4,2),color=luaL_optinteger(L,5,65535);
 if(font!=1&&font!=2&&font!=4)return luaL_error(L,"Fonte: 1,2,4");
 c->tft_->setTextDatum(MC_DATUM);c->tft_->setTextColor((uint16_t)color);c->tft_->drawString(s,x,y,font);return 0;
}
int LuaCore::button(lua_State* L){
 auto c=self(L);const char* s=luaL_checkstring(L,1);if(strlen(s)>80)return luaL_error(L,"Legenda longa");
 int x=constrain((int)luaL_checkinteger(L,2),0,319),y=constrain((int)luaL_checkinteger(L,3),32,239);
 int w=constrain((int)luaL_checkinteger(L,4),1,320-x),h=constrain((int)luaL_checkinteger(L,5),1,240-y);
 uint16_t col=luaL_optinteger(L,6,0x24bf);
 c->tft_->fillRect(x,y,w,h,col);c->tft_->setTextDatum(MC_DATUM);c->tft_->setTextColor(TFT_WHITE,col);c->tft_->drawString(s,x+w/2,y+h/2,2);return 0;
}
int LuaCore::redraw(lua_State* L){self(L)->dirty_=true;return 0;}
int LuaCore::millisFn(lua_State* L){lua_pushinteger(L,::millis());return 1;}
// LUMIOS_MEMORY_API_V1: snapshot before allocating the result Lua table.
int LuaCore::memoryInfo(lua_State* L){
 auto c=self(L);const size_t limit=c->limit_,used=c->used_;
 const uint32_t caps=MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT;
 lua_createtable(L,0,7);
 auto value=[&](const char* key,size_t n){lua_pushinteger(L,(lua_Integer)n);lua_setfield(L,-2,key);};
 value("lua_used",used);value("lua_limit",limit);value("lua_available",used<limit?limit-used:0);
 value("heap_free",heap_caps_get_free_size(caps));value("heap_largest",heap_caps_get_largest_free_block(caps));
 value("heap_minimum",heap_caps_get_minimum_free_size(caps));value("strip_pixels_bytes",c->strip_?320*32*2:0);return 1;
}

// LUMIOS_STORAGE_API_V1: pequenos inteiros persistentes em /LumiOS/data no SD.
int LuaCore::storageGetNumber(lua_State* L){
 const char* key=luaL_checkstring(L,1);lua_Integer fallback=luaL_optinteger(L,2,0);
 if(!validStorageKey(key))return luaL_error(L,"Chave storage invalida");
 auto c=self(L);lua_Integer value=fallback;SdFat32 sd;beginLuaSd();
 if(sd.begin(luaSdConfig())){
  String path=String("/LumiOS/data/")+c->storageNamespace_+"/"+key+".dat";
  String readable=sd.exists(path.c_str())?path:path+".bak";File32 f=sd.open(readable.c_str(),O_RDONLY);
  if(f){char buf[17]={};int n=f.read(buf,16);f.close();
   if(n>0){char* end=nullptr;unsigned long parsed=strtoul(buf,&end,10);if(end!=buf&&parsed<=2147483647UL)value=(lua_Integer)parsed;}
  }
  sd.end();
 }
 restoreLuaTouch();lua_pushinteger(L,value);return 1;
}
int LuaCore::storageSetNumber(lua_State* L){
 const char* key=luaL_checkstring(L,1);lua_Integer value=luaL_checkinteger(L,2);
 if(!validStorageKey(key))return luaL_error(L,"Chave storage invalida");
 if(value<0||value>2147483647LL)return luaL_error(L,"Valor storage invalido");
 auto c=self(L);bool ok=false;SdFat32 sd;beginLuaSd();
 if(sd.begin(luaSdConfig())){
  sd.mkdir("/LumiOS");sd.mkdir("/LumiOS/data");String dir=String("/LumiOS/data/")+c->storageNamespace_;sd.mkdir(dir.c_str());
  String path=dir+"/"+key+".dat",temp=path+".tmp",backup=path+".bak";
  if(sd.exists(temp.c_str()))sd.remove(temp.c_str());
  File32 f=sd.open(temp.c_str(),O_WRONLY|O_CREAT|O_TRUNC);
  if(f){f.print((long)value);ok=f.sync();f.close();}
  if(ok&&sd.exists(backup.c_str()))ok=sd.remove(backup.c_str());
  bool hadOld=sd.exists(path.c_str());if(ok&&hadOld)ok=sd.rename(path.c_str(),backup.c_str());
  if(ok)ok=sd.rename(temp.c_str(),path.c_str());
  if(!ok&&hadOld&&!sd.exists(path.c_str())&&sd.exists(backup.c_str()))sd.rename(backup.c_str(),path.c_str());
  if(ok&&sd.exists(backup.c_str()))sd.remove(backup.c_str());
  if(!ok&&sd.exists(temp.c_str()))sd.remove(temp.c_str());
  sd.end();
 }
 restoreLuaTouch();lua_pushboolean(L,ok);return 1;
}

// LUMIOS_GRAPHICS_API_V1: primitives draw directly on the TFT and allocate no framebuffer.
int LuaCore::pixel(lua_State* L){auto c=self(L);int x=luaL_checkinteger(L,1),y=luaL_checkinteger(L,2);if(x<0||x>319||y<32||y>239)return 0;c->tft_->drawPixel(x,y,(uint16_t)luaL_checkinteger(L,3));return 0;}
int LuaCore::line(lua_State* L){auto c=self(L);int x1=luaL_checkinteger(L,1),y1=luaL_checkinteger(L,2),x2=luaL_checkinteger(L,3),y2=luaL_checkinteger(L,4);c->tft_->drawLine(x1,y1,x2,y2,(uint16_t)luaL_checkinteger(L,5));return 0;}
int LuaCore::rect(lua_State* L){auto c=self(L);int x=luaL_checkinteger(L,1),y=luaL_checkinteger(L,2),w=luaL_checkinteger(L,3),h=luaL_checkinteger(L,4);if(w<1||h<1||w>640||h>480)return luaL_error(L,"Retangulo invalido");c->tft_->drawRect(x,y,w,h,(uint16_t)luaL_checkinteger(L,5));return 0;}
int LuaCore::fillRect(lua_State* L){auto c=self(L);int x=luaL_checkinteger(L,1),y=luaL_checkinteger(L,2),w=luaL_checkinteger(L,3),h=luaL_checkinteger(L,4);if(w<1||h<1||w>640||h>480)return luaL_error(L,"Retangulo invalido");c->tft_->fillRect(x,y,w,h,(uint16_t)luaL_checkinteger(L,5));return 0;}
int LuaCore::circle(lua_State* L){auto c=self(L);int x=luaL_checkinteger(L,1),y=luaL_checkinteger(L,2),r=luaL_checkinteger(L,3);if(r<1||r>320)return luaL_error(L,"Raio invalido");c->tft_->drawCircle(x,y,r,(uint16_t)luaL_checkinteger(L,4));return 0;}
int LuaCore::fillCircle(lua_State* L){auto c=self(L);int x=luaL_checkinteger(L,1),y=luaL_checkinteger(L,2),r=luaL_checkinteger(L,3);if(r<1||r>320)return luaL_error(L,"Raio invalido");c->tft_->fillCircle(x,y,r,(uint16_t)luaL_checkinteger(L,4));return 0;}
int LuaCore::arc(lua_State* L){
 auto c=self(L);int x=luaL_checkinteger(L,1),y=luaL_checkinteger(L,2),r=luaL_checkinteger(L,3),a0=luaL_checkinteger(L,4),a1=luaL_checkinteger(L,5),th=luaL_optinteger(L,7,1);
 if(r<1||r>320||th<1||th>r||a0<0||a0>360||a1<0||a1>360||a0==a1)return luaL_error(L,"Arco invalido");
 uint16_t color=luaL_checkinteger(L,6);c->tft_->drawArc(x,y,r,r-th+1,a0,a1,color,color,false);return 0;
}
int LuaCore::fillArc(lua_State* L){
 auto c=self(L);int x=luaL_checkinteger(L,1),y=luaL_checkinteger(L,2),outer=luaL_checkinteger(L,3),inner=luaL_checkinteger(L,4),a0=luaL_checkinteger(L,5),a1=luaL_checkinteger(L,6);
 if(outer<1||outer>320||inner<0||inner>=outer||a0<0||a0>360||a1<0||a1>360||a0==a1)return luaL_error(L,"Arco invalido");
 uint16_t color=luaL_checkinteger(L,7);c->tft_->drawArc(x,y,outer,inner,a0,a1,color,color,false);return 0;
}
int LuaCore::triangle(lua_State* L){auto c=self(L);int x1=luaL_checkinteger(L,1),y1=luaL_checkinteger(L,2),x2=luaL_checkinteger(L,3),y2=luaL_checkinteger(L,4),x3=luaL_checkinteger(L,5),y3=luaL_checkinteger(L,6);c->tft_->drawTriangle(x1,y1,x2,y2,x3,y3,(uint16_t)luaL_checkinteger(L,7));return 0;}
int LuaCore::fillTriangle(lua_State* L){auto c=self(L);int x1=luaL_checkinteger(L,1),y1=luaL_checkinteger(L,2),x2=luaL_checkinteger(L,3),y2=luaL_checkinteger(L,4),x3=luaL_checkinteger(L,5),y3=luaL_checkinteger(L,6);c->tft_->fillTriangle(x1,y1,x2,y2,x3,y3,(uint16_t)luaL_checkinteger(L,7));return 0;}
void LuaCore::stop(){LumiCoreClient::stop();stripActive_=false;if(strip_){strip_->deleteSprite();delete strip_;strip_=nullptr;}DisksTelemetry::stop();disksRequested_=false;disksOnline_=false;diskCount_=0;diskPage_=0;diskPages_=1;diskTotal_=0;disksPending_=true;if(L_)lua_close(L_);L_=nullptr;used_=0;dirty_=false;}
bool LuaCore::result(int code){
 tft_->resetViewport();
 if(code==LUA_OK)return true;
 const char* e=lua_tostring(L_,-1);error_=e?String(e).substring(0,120):"Erro Lua";
 stop();Serial.println(error_);tft_->fillRect(0,32,320,208,0x0863);
 tft_->setTextDatum(TL_DATUM);tft_->setTextColor(TFT_RED,0x0863);
 tft_->drawString("Aplicacao interrompida",8,55,2);
 for(unsigned i=0;i<error_.length();i+=36)tft_->drawString(error_.substring(i,i+36),8,85+(i/36)*20,2);
 return false;
}
bool LuaCore::start(const String& source,TFT_eSPI& display,const String& appId,bool superMemory){
 stop();tft_=&display;error_="";line_=0;limit_=superMemory?96*1024:64*1024;storageNamespace_=appId.length()?appId:"app";
 L_=lua_newstate(allocate,this);if(!L_){error_="Sem RAM Lua";return false;}
 *(LuaCore**)lua_getextraspace(L_)=this;
 lua_pushcfunction(L_,init);if(!result(lua_pcall(L_,0,0,0)))return false;
 if(!result(luaL_loadbufferx(L_,source.c_str(),source.length(),"main.lua","t")))return false;
 budget_=0;deadline_=::millis()+100;lua_sethook(L_,hook,LUA_MASKCOUNT,500);
 tft_->setViewport(0,32,320,208,false);
 if(!result(lua_pcall(L_,0,0,0)))return false;
 lua_getglobal(L_,"telemetry_topic");
 energyTopic_=lua_isstring(L_,-1)&&!strcmp(lua_tostring(L_,-1),"energy");
 disksRequested_=lua_isstring(L_,-1)&&(!strcmp(lua_tostring(L_,-1),"disks")||!strcmp(lua_tostring(L_,-1),"energy")||!strcmp(lua_tostring(L_,-1),"gpus"));lua_pop(L_,1);
 if(disksRequested_){DisksTelemetry::start();pollDisks();}
 dirty_=true;draw();return L_!=nullptr;
}
bool LuaCore::call(const char* name,int args){
 if(!L_)return false;
 lua_getglobal(L_,name);
 if(!lua_isfunction(L_,-1)){lua_pop(L_,args+1);return true;}
 if(args)lua_insert(L_,-args-1);
 budget_=0;deadline_=::millis()+60;lua_sethook(L_,hook,LUA_MASKCOUNT,500);
 tft_->setViewport(0,32,320,208,false);
 return result(lua_pcall(L_,args,0,0));
}
void LuaCore::draw(){if(L_&&dirty_){dirty_=false;call("on_draw");}}
void LuaCore::touch(int x,int y){if(!L_||y<32)return;lua_pushinteger(L_,x);lua_pushinteger(L_,y);call("on_touch",2);draw();}
void LuaCore::tick(){if(!L_)return;if(disksRequested_)pollDisks();if(::millis()-lastTick_>=50){lastTick_=::millis();lua_pushinteger(L_,lastTick_);call("on_tick",1);}draw();}

// Only the opted-in Discos app polls; HTTP occurs outside timed Lua callbacks.
int LuaCore::telemetryOnline(lua_State* L){
 lua_getglobal(L,"telemetry_topic");bool gpuTopic=lua_isstring(L,-1)&&!strcmp(lua_tostring(L,-1),"gpus");lua_pop(L,1);
 if(gpuTopic){DisksTelemetry::Gpus g;DisksTelemetry::readGpus(g);lua_pushboolean(L,g.online);return 1;}
if(self(L)->energyTopic_){DisksTelemetry::Energy e;DisksTelemetry::readEnergy(e);lua_pushboolean(L,e.online);}else lua_pushboolean(L,self(L)->disksOnline_);return 1;}
int LuaCore::telemetryPage(lua_State* L){
 auto c=self(L);int page=luaL_checkinteger(L,1);
 unsigned next=constrain(page,0,(int)c->diskPages_-1);
 if(next!=c->diskPage_){c->diskPage_=next;c->disksPending_=true;}return 0;
}
int LuaCore::telemetryGet(lua_State* L){
 auto c=self(L);const char* topic=luaL_checkstring(L,1);
 if(!strcmp(topic,"energy")){
  DisksTelemetry::Energy e;DisksTelemetry::readEnergy(e);lua_newtable(L);
  lua_pushboolean(L,e.online);lua_setfield(L,-2,"available");
  lua_pushboolean(L,e.warning);lua_setfield(L,-2,"warning");
  lua_pushstring(L,e.error);lua_setfield(L,-2,"error");
  auto value=[&](const char* key,double n){if(e.online&&n>=0)lua_pushnumber(L,n);else lua_pushnil(L);lua_setfield(L,-2,key);};
  value("cpu_w",e.cpu);value("gpu_w",e.gpu);value("total_w",e.total);value("limit_w",e.limit);
  return 1;
 }
 if(!strcmp(topic,"gpus")){
  DisksTelemetry::Gpus data;DisksTelemetry::readGpus(data);lua_newtable(L);
  lua_pushboolean(L,data.online);lua_setfield(L,-2,"available");lua_pushstring(L,data.error);lua_setfield(L,-2,"error");
  for(unsigned i=0;i<data.count;i++){
   auto& g=data.rows[i];lua_newtable(L);
   auto str=[&](const char* k,const char* v){lua_pushstring(L,v);lua_setfield(L,-2,k);};
   auto num=[&](const char* k,double v){if(v>=0)lua_pushnumber(L,v);else lua_pushnil(L);lua_setfield(L,-2,k);};
   str("name",g.name);str("uuid",g.uuid);str("vendor",g.vendor);str("chip",g.chip);
   num("temp_c",g.temp);num("util_pct",g.usage);num("power_w",g.power);num("power_limit_w",g.limit);
   num("clock_mhz",g.clock);num("mem_mhz",g.memoryClock);num("fan_pct_reported",g.fan);
   num("memory_used_mb",g.memoryUsed);num("memory_total_mb",g.memoryTotal);
   lua_newtable(L);const char* keys[]={"cuda","opencl","vulkan","nvenc","ray_tracing"};
   for(unsigned j=0;j<5;j++){if(g.tech[j]>=0){lua_pushboolean(L,g.tech[j]);lua_setfield(L,-2,keys[j]);}}
   lua_setfield(L,-2,"technologies");
   lua_newtable(L);
   for(unsigned j=0;j<5;j++){if(g.techVersion[j][0]){lua_pushstring(L,g.techVersion[j]);lua_setfield(L,-2,keys[j]);}}
   lua_setfield(L,-2,"technology_versions");lua_rawseti(L,-2,i+1); // GPU_TECH_VERSIONS_V1
  }return 1;
 }
 if(strcmp(topic,"disks")){lua_pushnil(L);return 1;}
 lua_newtable(L);
 auto num=[&](const char* k,double v){lua_pushnumber(L,v);lua_setfield(L,-2,k);};
 num("page",c->diskPage_);num("pages",c->diskPages_);num("total_mounts",c->diskTotal_);
 lua_pushboolean(L,c->disksOnline_);lua_setfield(L,-2,"available");
 lua_pushstring(L,c->disksError_.c_str());lua_setfield(L,-2,"error");
 lua_newtable(L);
 for(unsigned i=0;i<c->diskCount_;i++){
  auto& d=c->disks_[i];lua_newtable(L);
  auto str=[&](const char* k,const String& v){lua_pushstring(L,v.c_str());lua_setfield(L,-2,k);};
  str("mount",d.mount);str("device",d.device);str("fs",d.fs);
  num("total_bytes",d.total);num("used_bytes",d.used);num("free_bytes",d.free);num("percent",d.percent);
  lua_pushboolean(L,d.valid);lua_setfield(L,-2,"available");lua_rawseti(L,-2,i+1);
 }
 lua_setfield(L,-2,"mounts");return 1;
}
void LuaCore::pollDisks(){
 // Cache only: no HTTP, parsing or SD access in the UI task.
 DisksTelemetry::Page page;DisksTelemetry::read(diskPage_,page);
 disksOnline_=page.online;disksError_=page.error;diskCount_=page.count;
 if(page.online){diskPage_=page.page;diskPages_=page.pages;diskTotal_=page.total;}
 for(unsigned i=0;i<diskCount_;i++){
  auto& d=disks_[i];const auto& row=page.rows[i];
  d.mount=row.mount;d.device=row.device;d.fs=row.fs;d.total=row.total;d.used=row.used;
  d.free=row.free;d.percent=row.percent;d.valid=row.valid;
 }
}


// LUMIOS_STRIP_BUFFER_V1: one reusable 320x32 RGB565 buffer (20 KiB).
int LuaCore::beginStrip(lua_State* L){
 auto c=self(L);int y=luaL_checkinteger(L,1);
 if(y<32||y>239)return luaL_error(L,"Faixa fora da app");
 if(!c->strip_){
  c->strip_=new(std::nothrow) TFT_eSprite(c->tft_);
  if(!c->strip_)return luaL_error(L,"Sem RAM para buffer");
  c->strip_->setColorDepth(16);
  if(!c->strip_->createSprite(320,32)){delete c->strip_;c->strip_=nullptr;return luaL_error(L,"Sem RAM: buffer 20 KiB");}
 }
 c->stripY_=y;c->stripActive_=true;
 c->strip_->fillSprite((uint16_t)luaL_optinteger(L,2,0));return 0;
}
int LuaCore::stripRect(lua_State* L){
 auto c=self(L);if(!c->stripActive_)return luaL_error(L,"Abra uma faixa primeiro");
 int x=luaL_checkinteger(L,1),y=luaL_checkinteger(L,2),w=luaL_checkinteger(L,3),h=luaL_checkinteger(L,4);
 if(w<0||w>320||h<0||h>240||x < -640||x>640||y < -480||y>480)return luaL_error(L,"Retangulo invalido");
 c->strip_->fillRect(x,y-c->stripY_,w,h,(uint16_t)luaL_checkinteger(L,5));return 0;
}
int LuaCore::stripText(lua_State* L){
 auto c=self(L);if(!c->stripActive_)return luaL_error(L,"Abra uma faixa primeiro");
 const char* text=luaL_checkstring(L,1);if(strlen(text)>80)return luaL_error(L,"Texto longo");
 int x=luaL_checkinteger(L,2),y=luaL_checkinteger(L,3),font=luaL_optinteger(L,4,2);
 if(font!=1&&font!=2&&font!=4)return luaL_error(L,"Fonte: 1,2,4");
 c->strip_->setTextDatum(MC_DATUM);c->strip_->setTextColor((uint16_t)luaL_optinteger(L,5,65535));
 c->strip_->drawString(text,x,y-c->stripY_,font);return 0;
}
int LuaCore::presentStrip(lua_State* L){
 auto c=self(L);if(!c->stripActive_)return luaL_error(L,"Abra uma faixa primeiro");
 c->tft_->resetViewport();c->strip_->pushSprite(0,c->stripY_);
 c->tft_->setViewport(0,32,320,208,false);c->stripActive_=false;return 0;
}
