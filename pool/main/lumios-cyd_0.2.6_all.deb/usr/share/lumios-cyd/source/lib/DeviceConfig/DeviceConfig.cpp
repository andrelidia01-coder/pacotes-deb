#include "DeviceConfig.h"
#include <Preferences.h>
#include "device_defaults.h"
#include "lumicore_key.h"
#include "local_config.h"
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
namespace DeviceConfig {
static String ep, addr, bc, key;
static SemaphoreHandle_t lock = nullptr;
void begin(){
 lock=xSemaphoreCreateMutex();
 Preferences p;p.begin("lumi-device",false);
 if(strcmp(LUMIOS_CONFIG_REV,"unconfigured")!=0 && p.getString("configrev","")!=LUMIOS_CONFIG_REV){
  p.putString("endpoint",LUMIOS_DEFAULT_ENDPOINT);
  p.putString("wolmac",LUMIOS_DEFAULT_MAC);
  p.putString("wolbc",LUMIOS_DEFAULT_BROADCAST);
  p.putString("controlkey",LUMIOS_LUMICORE_KEY);
  p.putString("configrev",LUMIOS_CONFIG_REV);
 }
 ep=p.getString("endpoint",LUMIOS_DEFAULT_ENDPOINT);
 addr=p.getString("wolmac",LUMIOS_DEFAULT_MAC);
 bc=p.getString("wolbc",LUMIOS_DEFAULT_BROADCAST);
 key=p.getString("controlkey",LUMIOS_LUMICORE_KEY);p.end();
}
String endpoint(){if(lock)xSemaphoreTake(lock,portMAX_DELAY);String v=ep;if(lock)xSemaphoreGive(lock);return v;}
void setEndpoint(const String& value){if(lock)xSemaphoreTake(lock,portMAX_DELAY);ep=value;if(lock)xSemaphoreGive(lock);}
const String& mac(){return addr;} const String& broadcast(){return bc;} const String& controlKey(){return key;}
}
