#include "WolCore.h"
#include <WiFi.h>
#include "DeviceConfig.h"
const char* WolCore::mac() const{return DeviceConfig::mac().c_str();}

bool WolCore::parseMac(uint8_t mac[6]) const {
  unsigned int b[6];
  if (sscanf(DeviceConfig::mac().c_str(), "%x:%x:%x:%x:%x:%x", &b[0], &b[1], &b[2],
             &b[3], &b[4], &b[5]) != 6) return false;
  for (uint8_t i=0;i<6;i++){if(b[i]>255)return false;mac[i]=static_cast<uint8_t>(b[i]);}
  return true;
}

bool WolCore::send() {
  if (WiFi.status()!=WL_CONNECTED) return false;
  uint8_t mac[6], packet[102]; if(!parseMac(mac)) return false;
  memset(packet,0xFF,6);
  for(uint8_t i=0;i<16;i++) memcpy(packet+6+i*6,mac,6);
  IPAddress ip=WiFi.localIP(), mask=WiFi.subnetMask();
  IPAddress broadcast;
  for(uint8_t i=0;i<4;i++) broadcast[i]=(ip[i]&mask[i])|static_cast<uint8_t>(~mask[i]);
  if(!udp_.begin(0)) return false;
  bool ok=udp_.beginPacket(broadcast,9)==1;
  if(ok) ok=udp_.write(packet,sizeof(packet))==sizeof(packet);
  if(ok) ok=udp_.endPacket()==1;
  udp_.stop(); return ok;
}
