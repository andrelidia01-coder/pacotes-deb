#pragma once
#include <LuaWrapper.h>
namespace LumiCoreClient { void install(lua_State*); void stop(); }
