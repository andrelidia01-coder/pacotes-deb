# LumiOS Build 31v5

Correção: o hostname correto do launcher é `ia.local` (não `ia.local`).

Fluxo:
1. ESP32 anuncia `ia.local` via mDNS.
2. GET `/` envia WoL.
3. ESP32 entrega a página de espera.
4. Após a resposta, desliga HTTP e mDNS.
5. A página espera 15 segundos no browser.
6. O browser abre `http://ia.local/`.

O acesso direto pelo IP do ESP32 continua sendo suportado para teste.
