#!/usr/bin/env python3
from getpass import getpass
from pathlib import Path
import json
key=getpass("Chave /etc/lumicore/control-key: ").strip()
if not key:raise SystemExit("Chave vazia")
(Path(__file__).parent/"include/lumicore_key.h").write_text("#pragma once\n#define LUMIOS_LUMICORE_KEY "+json.dumps(key)+"\n")
print("Chave usada na primeira configuracao NVS. OTA preserva a chave existente.")
