# LumiOS Build 31v4

Correção principal: o HttpWakeCore do v3 era criado, mas nunca era iniciado nem executado pelo `main.cpp`.

Agora o loop principal chama:
- `httpWake.begin(&wol)` quando Wi-Fi está ligado;
- `httpWake.loop()` em cada ciclo.

O HttpWakeCore é one-shot: depois de servir a página e desligar HTTP/mDNS, não volta a arrancar durante o mesmo boot.

Fluxo:
1. `ia.local` é anunciado pelo ESP32.
2. GET `/` envia WoL.
3. HTML é entregue ao browser.
4. Após 150 ms o HTTP e mDNS são desligados.
5. O JavaScript espera 15 segundos e abre `http://ia.local/`.
