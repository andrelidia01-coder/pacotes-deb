import json
import secrets
import time

class ProvisioningError(Exception):
    pass

class Rpc:
    def __init__(self, serial_port):
        self.serial = serial_port

    def request(self, command, timeout=10, **fields):
        request_id = secrets.token_hex(8)
        body = {'id': request_id, 'command': command, **fields}
        data = json.dumps(body,ensure_ascii=False).encode('utf-8')+b'\n'
        if len(data)>2048:
            raise ProvisioningError('Pedido USB demasiado longo.')
        try:
            self.serial.write(data)
            self.serial.flush()
        except OSError:
            raise ProvisioningError('Falha de comunicação USB; verifique o cabo.') from None
        end = time.monotonic()+timeout
        while time.monotonic()<end:
            try:
                line = self.serial.readline(32768)
            except OSError:
                raise ProvisioningError('Falha de comunicação USB; verifique o cabo.') from None
            if not line:
                continue
            try:
                response = json.loads(line)
            except (ValueError,UnicodeError):
                continue  # Boot diagnostics are not RPC responses.
            if not isinstance(response,dict) or response.get('id')!=request_id:
                continue
            if response.get('protocol')!=1:
                raise ProvisioningError('Protocolo USB incompatível.')
            if response.get('ok') is not True:
                # Never include request fields, which can contain passwords/keys.
                code=response.get('error','unknown_error')
                if not isinstance(code,str) or len(code)>80:
                    code='unknown_error'
                raise ProvisioningError('CYD: '+code)
            return response
        raise ProvisioningError('CYD sem resposta ao comando '+command+'.')

    def hello(self):
        value=self.request('hello')
        if value.get('device')!='LumiOS-CYD-Setup':
            raise ProvisioningError('O USB não respondeu como firmware mínimo do CYD.')
        return value
