#!/usr/bin/python3
import fcntl
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from usb_rpc import Rpc, ProvisioningError

ROOT=Path('/var/lib/lumios-cyd')
SOURCE=Path('/usr/share/lumios-cyd/source')
PROJECT=ROOT/'generic-project'
CONF=Path('/etc/lumicore/cyd/config.json')
KEY=Path('/etc/lumicore/control-key')

def run(args, **kw):
    return subprocess.run(args,check=True,**kw)

def secure_root():
    ROOT.mkdir(parents=True,exist_ok=True,mode=0o700);ROOT.chmod(0o700)

def write_private(path,text):
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    temp=path.with_suffix(path.suffix+'.tmp')
    fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(fd,'w') as f:f.write(text)
    temp.chmod(0o600);temp.replace(path)

def migrate():
    # Remove host-stored Wi-Fi credentials from the old package configuration.
    # Keep the shared LumiCore key and existing CYD NVS untouched.
    if CONF.exists():
        old=json.loads(CONF.read_text())
        clean={k:old[k] for k in ('interface','mac','chip','wifi_verified_at') if k in old}
        write_private(CONF,json.dumps(clean,indent=2)+'\n')
    # Retire the old credential-bearing compiled project, not the generic one.
    if (ROOT/'project').exists():shutil.rmtree(ROOT/'project')
    for name in ('firmware.bin','bootloader.bin','partitions.bin'):
        (ROOT/'firmware'/name).unlink(missing_ok=True)

def tool_python():return ROOT/'venv/bin/python'

def build():
    secure_root()
    with (ROOT/'build.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        PROJECT.mkdir(parents=True,exist_ok=True,mode=0o700)
        shutil.copytree(SOURCE,PROJECT,dirs_exist_ok=True)
        # Refuse any accidental household values in the firmware sources.
        key_header=(PROJECT/'include/lumicore_key.h').read_text()
        wifi_header=(PROJECT/'include/local_config.h').read_text()
        if '#define LUMIOS_LUMICORE_KEY ""' not in key_header or '#define LUMIOS_WIFI_PASSWORD ""' not in wifi_header:
            raise ValueError('A source contém valores pessoais; compilação recusada.')
        venv=ROOT/'venv'
        if not tool_python().exists():run([sys.executable,'-m','venv',str(venv)])
        run([str(tool_python()),'-m','pip','install','platformio==6.1.18','pyserial==3.5','esptool==4.8.1'])
        env=os.environ.copy();env['PLATFORMIO_CORE_DIR']=str(ROOT/'platformio')
        for target in ('cydsetup','cyd2usb'):
            run([str(venv/'bin/pio'),'run','-e',target],cwd=PROJECT,env=env)
            out=ROOT/'firmware'/target;out.mkdir(parents=True,exist_ok=True,mode=0o700)
            for name in ('firmware.bin','bootloader.bin','partitions.bin'):
                f=PROJECT/'.pio/build'/target/name
                if not f.exists():raise ValueError('Build sem '+name)
                shutil.copy2(f,out/name);(out/name).chmod(0o600)
            boot=ROOT/'platformio/packages/framework-arduinoespressif32/tools/partitions/boot_app0.bin'
            if not boot.exists():raise ValueError('boot_app0.bin não encontrado no framework.')
            shutil.copy2(boot,out/'boot_app0.bin');(out/'boot_app0.bin').chmod(0o600)
        setup=(ROOT/'firmware/cydsetup/partitions.bin').read_bytes()
        normal=(ROOT/'firmware/cyd2usb/partitions.bin').read_bytes()
        if setup!=normal:raise ValueError('As tabelas de partições não coincidem; gravação recusada.')
        manifest={'generic':True,'targets':['cydsetup','cyd2usb'],'normal':'Build031v14-RECOVERY',
                  'sha256':{}}
        for p in (ROOT/'firmware').glob('*/*.bin'):
            manifest['sha256'][str(p.relative_to(ROOT/'firmware'))]=hashlib.sha256(p.read_bytes()).hexdigest()
        write_private(ROOT/'firmware/build.json',json.dumps(manifest,indent=2)+'\n')
        print('Os dois firmwares genéricos estão compilados. Nenhum USB foi gravado.')

def validate_port(port):
    p=Path(port)
    if not str(p).startswith('/dev/') or not p.exists() or not p.resolve().is_char_device():
        raise ValueError('Indique uma porta válida em /dev/serial/by-id/.')
    target=p.resolve()
    units=run(['systemctl','list-units','--state=active','--plain','--type=service','--no-legend','h81-fan-bridge@*.service'],capture_output=True,text=True).stdout
    for line in units.splitlines():
        unit=line.split()[0]
        if '@' not in unit:continue
        device=unit.split('@',1)[1].removesuffix('.service')
        if Path('/dev',device).resolve()==target:
            raise ValueError('Porta reservada ao H81 Fan Controller. Gravação recusada.')
    return str(p)

def esptool(port,command):
    return run([str(tool_python()),'-m','esptool','--chip','esp32','--port',port,
                '--baud','460800',*command])

def check_images():
    manifest=json.loads((ROOT/'firmware/build.json').read_text())
    if manifest.get('generic') is not True:raise ValueError('Firmwares genéricos ainda não compilados.')
    for name,digest in manifest['sha256'].items():
        p=ROOT/'firmware'/name
        if not p.resolve().is_relative_to((ROOT/'firmware').resolve()):raise ValueError('Manifesto inválido.')
        if hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise ValueError('Firmware alterado; recompile.')
    if (ROOT/'firmware/cydsetup/partitions.bin').read_bytes()!=(ROOT/'firmware/cyd2usb/partitions.bin').read_bytes():
        raise ValueError('Partições diferentes.')
    bounds={'bootloader.bin':0x7000,'partitions.bin':0x1000,
            'boot_app0.bin':0x2000,'firmware.bin':0x1D0000}
    for target in ('cydsetup','cyd2usb'):
        for name,limit in bounds.items():
            size=(ROOT/'firmware'/target/name).stat().st_size
            if not 0<size<=limit:raise ValueError('Imagem ultrapassa a região de flash: '+target+'/'+name)

def flash(port,target):
    base=ROOT/'firmware'/target
    # Explicit ranges: NVS is [0x9000, 0xE000), never written or erased here.
    esptool(port,['write_flash','--flash_mode','dio','--flash_freq','40m','--flash_size','4MB',
                  '0x1000',str(base/'bootloader.bin'),
                  '0x8000',str(base/'partitions.bin'),
                  '0xe000',str(base/'boot_app0.bin'),
                  '0x10000',str(base/'firmware.bin')])

def choose_interface(explicit=None):
    old=json.loads(CONF.read_text()) if CONF.exists() else {}
    candidates=[]
    for p in Path('/sys/class/net').iterdir():
        if (p/'device').exists() and not (p/'wireless').exists() and (p/'type').read_text().strip()=='1':
            candidates.append(p.name)
    if explicit:
        iface=explicit
    else:
        default=old.get('interface','enp3s0')
        if default not in candidates:default=candidates[0] if len(candidates)==1 else ''
        print('Interfaces Ethernet disponíveis: '+', '.join(sorted(candidates)))
        iface=input('Interface do mini-PC para WoL ['+default+']: ').strip() or default
    if iface not in candidates:raise ValueError('Escolha uma interface Ethernet física.')
    mac=(Path('/sys/class/net')/iface/'address').read_text().strip().lower()
    if not re.fullmatch(r'(?:[0-9a-f]{2}:){5}[0-9a-f]{2}',mac) or mac=='00:00:00:00:00:00':
        raise ValueError('MAC Ethernet inválido.')
    return iface,mac

def control_key():
    if not KEY.exists():
        KEY.parent.mkdir(parents=True,exist_ok=True)
        fd=os.open(KEY,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as f:f.write(secrets.token_hex(32)+'\n')
        print('Chave LumiCore criada; valor não apresentado.')
    key=KEY.read_text().strip()
    if not 16<=len(key)<=128 or any(ord(ch)<32 for ch in key):raise ValueError('Chave LumiCore inválida.')
    return key

def publish(mac):
    root=ET.Element('service-group')
    ET.SubElement(root,'name').text='LumiCore CYD '+mac
    service=ET.SubElement(root,'service')
    ET.SubElement(service,'type').text='_lumicore._tcp'
    ET.SubElement(service,'port').text='8765'
    ET.SubElement(service,'txt-record').text='mac='+mac
    p=Path('/etc/avahi/services/lumicore-cyd.service');p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text('<?xml version="1.0" standalone="no"?>\n<!DOCTYPE service-group SYSTEM "avahi-service.dtd">\n'+ET.tostring(root,encoding='unicode')+'\n')
    p.chmod(0o644)
    run(['systemctl','enable','--now','avahi-daemon.service'],stdout=subprocess.DEVNULL)
    run(['systemctl','reload','avahi-daemon.service'])

def wol():
    c=json.loads(CONF.read_text());iface=c['interface']
    if (Path('/sys/class/net')/iface/'address').read_text().strip().lower()!=c['mac']:
        raise ValueError('MAC mudou; repita a configuração.')
    run(['ethtool','-s',iface,'wol','g'])
    value=run(['ethtool',iface],capture_output=True,text=True).stdout
    if not re.search(r'^\s*Wake-on:\s*g\s*$',value,re.M):raise ValueError('WoL não confirmado pelo driver.')
    print('WoL confirmado na interface '+iface+'.')

def configure_wifi(rpc):
    choices=None
    while True:
        if choices is None:
            try:
                result=rpc.request('scan',timeout=30)
            except ProvisioningError as e:
                print(str(e)+' A pesquisa falhou; não é necessário voltar a gravar.')
                input('Enter para repetir a pesquisa; Ctrl+C para cancelar: ')
                continue
            networks=result.get('networks',[])
            seen=set();choices=[]
            for item in networks:
                if not isinstance(item,dict) or not isinstance(item.get('ssid'),str):continue
                if item['ssid'] in seen:continue
                seen.add(item['ssid']);choices.append(item)
        for i,item in enumerate(choices,1):
            # repr avoids terminal escapes from an untrusted SSID.
            print(f"{i:2d}. {item['ssid']!r} | {item.get('rssi','?')} dBm | "+('protegida' if item.get('secured') else 'aberta'))
        selected=input('Número da rede (R para pesquisar novamente): ').strip()
        if selected.lower()=='r':choices=None;continue
        if not selected.isdigit() or not 1<=int(selected)<=len(choices):
            print('Seleção inválida.');continue
        item=choices[int(selected)-1]
        while True:
            password=getpass.getpass('Palavra-passe Wi-Fi: ') if item.get('secured') else ''
            if item.get('secured') and not (8<=len(password.encode())<=63 or re.fullmatch(r'[0-9a-fA-F]{64}',password)):
                print('Palavra-passe inválida: use 8-63 bytes ou PSK hexadecimal de 64 caracteres.')
                password='';continue
            print('O CYD está a testar a ligação (até 25 segundos)…')
            try:
                connected=rpc.request('connect',timeout=35,ssid=item['ssid'],password=password)
                print('Ligação Wi-Fi confirmada pelo CYD; IP '+str(connected.get('ip','?')))
                return
            except ProvisioningError as e:
                print(str(e)+' Pode corrigir a palavra-passe sem pesquisar nem gravar novamente.')
            finally:
                password=''
            action=input('Enter = repetir nesta rede; L = escolher da lista; R = nova pesquisa: ').strip().lower()
            if action=='r':choices=None;break
            if action=='l':break

def open_setup(port):
    import serial
    s=serial.Serial(port=None,baudrate=115200,timeout=0.5,write_timeout=5,exclusive=True)
    s.dtr=False;s.rts=False;s.port=port;s.open()
    try:
        time.sleep(0.3);s.reset_input_buffer()
        # Read-only identity query protects an inactive fan controller too.
        s.write(b'IDENTIFY\n');s.flush()
        deadline=time.monotonic()+1.2
        while time.monotonic()<deadline:
            if b'H81-FAN-CONTROLLER' in s.readline(4096):
                raise ValueError('O USB identificou-se como H81 Fan Controller. Gravação recusada.')
        rpc=Rpc(s)
        try:
            hello=rpc.request('hello',timeout=3)
        except ProvisioningError as e:
            if str(e).startswith('CYD sem resposta'):
                s.close();return None
            raise ValueError('O USB respondeu com erro: '+str(e)) from None
        if hello.get('device')!='LumiOS-CYD-Setup':
            raise ValueError('Dispositivo USB identificado com outro protocolo; gravação recusada.')
        return s,rpc,hello
    except Exception:
        s.close();raise

def prepare_setup(port):
    running=open_setup(port)
    if running is not None:
        print('Firmware mínimo já ativo: a retomar por USB, sem voltar a gravar.')
        return running
    backup=ROOT/'backups';backup.mkdir(exist_ok=True,mode=0o700)
    nvs=backup/('nvs-'+time.strftime('%Y%m%d-%H%M%S')+'.bin')
    esptool(port,['read_flash','0x9000','0x5000',str(nvs)])
    nvs.chmod(0o600)
    print('Backup NVS local guardado. Pode conter credenciais antigas.')
    flash(port,'cydsetup');time.sleep(2)
    running=open_setup(port)
    if running is None:raise ProvisioningError('O firmware mínimo foi gravado mas não respondeu. Repita testar para retomar.')
    return running

def acquire_usb_lock(lock):
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise ValueError('Outra operação USB do lumios-cyd já está em curso; nenhuma gravação iniciada.') from None

def acquire_build_lock(lock):
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        print('Compilação em curso; a aguardar antes de continuar…',flush=True)
        fcntl.flock(lock,fcntl.LOCK_EX)
        print('Compilação concluída; a validar os firmwares.',flush=True)

def test(port,iface=None):
    secure_root()
    with (ROOT/'usb.lock').open('w') as usb_lock, (ROOT/'build.lock').open('w') as build_lock:
        acquire_usb_lock(usb_lock)
        acquire_build_lock(build_lock)
        port=validate_port(port);check_images()
        print('Porta escolhida: '+port)
        print('Isto grava o CYD com ecrã. Não desligue o controlador das ventoinhas.')
        if input('Confirme o dispositivo escrevendo CYD: ')!='CYD':
            print('Cancelado; nenhum USB gravado.');return
        iface,mac=choose_interface(iface)
        s,rpc,hello=prepare_setup(port)
        try:
            chip=hello.get('chip','')
            if not isinstance(chip,str) or not re.fullmatch(r'[0-9A-F]{12}',chip):
                raise ProvisioningError('Identidade do ESP32 inválida.')
            print('Firmware mínimo confirmado no ESP32 '+chip+'.')
            configure_wifi(rpc)
            key=control_key()
            result=rpc.request('apply',timeout=15,control_key=key,wol_mac=mac)
            key=''
            if result.get('key_saved') is not True or result.get('wol_mac')!=mac:
                raise ProvisioningError('Configuração não confirmada pelo CYD.')
            status=rpc.request('status')
            if status.get('configured') is not True:raise ProvisioningError('NVS não confirmou a configuração.')
        finally:
            s.close()
        clean={'interface':iface,'mac':mac,'chip':chip,'wifi_verified_at':time.strftime('%Y-%m-%dT%H:%M:%S')}
        CONF.parent.mkdir(parents=True,exist_ok=True,mode=0o700);CONF.parent.chmod(0o700)
        write_private(CONF,json.dumps(clean,indent=2)+'\n')
        publish(mac)
        run(['systemctl','enable','lumios-cyd-wol.service'])
        try:run(['systemctl','restart','lumios-cyd-wol.service'])
        except subprocess.CalledProcessError:print('AVISO: WoL não confirmado. Consulte o journal da unidade.')
        print('Wi-Fi e emparelhamento guardados no CYD. A gravar LumiOS normal…')
        flash(port,'cyd2usb')
        print('LumiOS normal gravado. Verifique no ecrã a ligação ao Wi-Fi/LumiCore.')
        print('O teste confirmou Wi-Fi no mínimo; a ligação do LumiOS normal ainda exige validação física.')

def finish(port):
    secure_root()
    with (ROOT/'usb.lock').open('w') as usb_lock, (ROOT/'build.lock').open('w') as build_lock:
        acquire_usb_lock(usb_lock);acquire_build_lock(build_lock)
        port=validate_port(port);check_images()
        if input('Regravar apenas LumiOS normal, mantendo NVS. Escreva CYD: ')!='CYD':return
        running=open_setup(port)
        if running is not None:running[0].close()
        flash(port,'cyd2usb')

def main():
    if os.geteuid()!=0:raise ValueError('Execute com sudo.')
    os.umask(0o077)
    args=sys.argv[1:]
    if args==['build']:build()
    elif args==['migrate']:migrate()
    elif args==['wol']:wol()
    elif args==['compilar']:run(['systemctl','restart','--no-block','lumios-cyd-build.service'])
    elif len(args) in (2,3) and args[0]=='testar':test(args[1],args[2] if len(args)==3 else None)
    elif len(args)==2 and args[0]=='finalizar':finish(args[1])
    else:print('Uso: sudo lumios-cyd compilar | testar PORTA [INTERFACE] | finalizar PORTA')

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:
        print('\nInterrompido. Se ficou no firmware mínimo, repita testar ou use finalizar após configuração.',file=sys.stderr)
        sys.exit(130)
    except (OSError,ValueError,KeyError,ProvisioningError,subprocess.CalledProcessError) as e:
        print('ERRO: '+str(e),file=sys.stderr)
        print('Nenhuma instrução de erase_flash foi executada. Consulte o estado antes de repetir.',file=sys.stderr)
        sys.exit(1)
