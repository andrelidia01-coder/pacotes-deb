let cfg=null, editable=false, selected='cpu', disks=[], fans={}, available=new Set();
let platformFanState={}, h81Settings=null, setupMode=false, hardwareSnapshot=null, hardwareLayoutSig='';
const $=id=>document.getElementById(id), key=()=>sessionStorage.getItem('hipervisorKey')||'';
async function api(path,opt={}){const r=await fetch(path,{...opt,headers:{'X-Hipervisor-Key':key(),...(opt.headers||{})}});const d=await r.json();if(!r.ok)throw Error(d.error||`HTTP ${r.status}`);return d}
async function live(c){return (await api('/api/live/'+c)).result}
const fmt=(v,u='')=>v==null?'--':`${typeof v==='number'&&!Number.isInteger(v)?v.toFixed(1):v}${u}`;
function msg(t,e=false){$('message').textContent=t;$('message').style.color=e?'#ff6680':'#7aa4bd'}
function gpuSpec(n){return n===0?cfg.gpu:cfg['gpu'+n]}
function gpuProfiles(n){return n===0?cfg.profiles:(cfg['gpu'+n]?.profiles||{})}
function gpuPrefix(n){return n===0?'gpu':'gpu'+n}
function gpuEnabled(n){return n===0?cfg.gpu?.enabled!==false:!!cfg['gpu'+n]?.enabled}
function zonePosition(name){const z=cfg.case_fans?.zones?.[name]||{};return String(z.position||name).toLowerCase()}
function findZone(...terms){for(const [name,z] of Object.entries(cfg.case_fans?.zones||{})){if(z.enabled===false)continue;const p=zonePosition(name);if(terms.some(t=>p.includes(t)||name.toLowerCase().includes(t)))return name}return null}
function diskType(d){const p=String(d.path||'');if(p==='/')return'ssd';if(p.includes('ai-models')||p.includes('/mnt/'))return'hdd';return null}
function setVisible(sel,on){const e=document.querySelector(sel);if(e)e.hidden=!on}
async function buildHardware(){
 const stack=$('gpuStack');stack.innerHTML='';
 // A configuração vem do system.dat, exposta pela API do Web.
 // GPU configurada continua visível quando a sua telemetria falha.
 for(let n=0;n<4;n++){
  if(!gpuEnabled(n))continue;
  const top=47.5+n*6;
  const unit=document.createElement('div');unit.className='gpu-unit';unit.style.top=top+'%';
  const label=document.createElement('span');label.textContent='GPU '+n;unit.appendChild(label);stack.appendChild(unit);
  const point=document.createElement('button');point.className='part hotspot gpu-point';
  point.dataset.component='gpu'+n;point.title='GPU '+n;point.setAttribute('aria-label','Telemetria da GPU '+n);
  point.style.left='29%';point.style.top=(top+2.2)+'%';stack.appendChild(point);
 }
 try{const value=await live('storage.list');disks=Array.isArray(value)?value:[]}catch{disks=[]}
 setVisible('.part.ssd',disks.some(d=>diskType(d)==='ssd'));
 setVisible('.part.hdd',disks.some(d=>diskType(d)==='hdd'));
 // RAM é instalada se a capacidade for positiva; falha de leitura não apaga um módulo configurado.
 try{const total=await live('ram.total');setVisible('.part.ram',Number(total)>0)}catch{setVisible('.part.ram',true)}
 const h81Present=!!platformFanState?.present;
 const caseEnabled=!!cfg.case_fans?.enabled;
 const rear=findZone('rear','traseira','exhaust'),side=findZone('side','lateral'),front=findZone('front','frontal');
 const rearOn=caseEnabled&&!!rear,frontOn=caseEnabled&&!!front,sideOn=h81Present||(caseEnabled&&!!side);
 setVisible('.casefan.rear',rearOn);setVisible('.casefan.side',sideOn);setVisible('.casefan.front',frontOn);
 $('fanRearAsset').hidden=!rearOn;$('fanFrontAsset').hidden=!frontOn;
 document.querySelector('.casefan.rear').dataset.zone=rear||'';
 document.querySelector('.casefan.side').dataset.zone=h81Present?'side':(side||'');
 document.querySelector('.casefan.front').dataset.zone=front||'';
 document.querySelectorAll('.part').forEach(x=>x.onclick=()=>select(x.dataset.component,x));
 const visible=document.querySelector(`[data-component="${selected}"]:not([hidden])`);
 if(!visible){const first=document.querySelector('.part:not([hidden])');if(first)select(first.dataset.component,first)}else select(selected,visible);
}

function rows(r){const el=$('detailMetrics');el.replaceChildren();for(const [name,value] of r){const line=document.createElement('div');line.className='metric';const a=document.createElement('span'),b=document.createElement('strong');a.textContent=name;b.textContent=value??'--';line.append(a,b);el.appendChild(line)}}
function select(c,node){selected=c;document.querySelectorAll('.part').forEach(x=>x.classList.toggle('active',x===node));refreshDetail()}
async function refreshDetail(){
 if(setupMode&&hardwareSnapshot)return renderHardwareDetail();
 const c=selected;let title=c.toUpperCase(),r=[];
 try{
  if(c.startsWith('gpu')){const n=Number(c.slice(3)),p=gpuPrefix(n);title='GPU'+n;r=[['Modelo',await live(p+'.name')||'--'],['Perfil',String(await live(p+'.profile')||'--').toUpperCase()],['Temperatura',fmt(await live(p+'.temp'),' °C')],['Consumo',fmt(await live(p+'.power'),' W')],['Utilização',fmt(await live(p+'.usage'),' %')],['Core',fmt(await live(p+'.clock'),' MHz')],['Memória',fmt(await live(p+'.memory_clock'),' MHz')],['Ventoinha',fmt(await live(p+'.fan'),n===1?' RPM':' %')]]}
  else if(c==='cpu'){title='CPU';r=[['Temperatura',fmt(await live('cpu.temp'),' °C')],['Consumo',fmt(await live('cpu.power'),' W')],['Utilização',fmt(await live('cpu.usage'),' %')],['Frequência',fmt(await live('cpu.clock'),' MHz')]]}
  else if(c==='ram'){title='Memória RAM';r=[['Uso',fmt(await live('ram.usage'),' %')],['Em uso',fmt(await live('ram.used'),' MB')],['Total',fmt(await live('ram.total'),' MB')]]}
  else if(c==='psu'){title='PSU';r=[['Total DC',fmt(await live('power.total'),' W')],['Tomada',fmt(await live('power.wall'),' W')],['Carga',fmt(await live('power.load'),' %')],['Capacidade',fmt(cfg.power.capacity_w,' W')]]}
  else if(c==='ssd'||c==='hdd'){title=c==='ssd'?'SSD · Sistema':'HDD';const d=disks.find(x=>diskType(x)===c);r=d?[['Montagem',d.path||'--'],['Sistema',d.fstype||'--'],['Uso',fmt(d.usage_pct,' %')],['Usado',fmt(d.used_gb,' GB')],['Total',fmt(d.total_gb,' GB')]]:[['Estado','Não detetado']]}
  else if(c.startsWith('fan-')){const el=document.querySelector(`[data-component="${c}"]`),z=el?.dataset.zone;title=c==='fan-front'?'Ventoinhas frontais':c==='fan-side'?'Ventoinha lateral':'Extração traseira';const v=fans?.zones?.[z]||{};r=[['RPM',fmt(v.rpm)],['PWM',fmt(v.percent,' %')],['Canal',fmt(v.channel)],['Nível',fans.level||'--'],['Temp. controlo',fmt(fans.control_temp_c,' °C')],['Estado',fans.fail_safe?'FAIL-SAFE':'OK']]}
 }catch(e){r=[['Erro',e.message]]}
 $('detailTitle').textContent=title;rows(r)
}
async function refreshState(){try{const [state,p,f]=await Promise.all([live('state'),live('power.total'),live('fans.state').catch(()=>({}))]);fans=f||{};$('systemState').textContent=state;$('instantPower').textContent=fmt(p);$('coreDot').classList.toggle('offline',state==='FAULT');document.querySelector('.case').classList.toggle('fault',state==='FAULT');if(document.querySelector('.page.active')?.dataset.page==='home')refreshDetail();$('pTotal').textContent=fmt(p);$('pWall').textContent=fmt(await live('power.wall'));$('pLoad').textContent=fmt(await live('power.load'))}catch{$('coreDot').classList.add('offline')}}
function fieldsFor(p){return [['Potência W','power_limit_w'],['Clock MHz','clock_mhz'],['Memória MHz','memory_clock_mhz'],['Offset core','clock_offset_mhz'],['Offset memória','memory_offset_mhz']] .filter(([,k])=>k in p||k==='power_limit_w')}
function renderProfiles(){const root=$('profileGroups');root.innerHTML='';for(let n=0;n<4;n++){if(!gpuEnabled(n))continue;const sec=document.createElement('section');sec.className='gpu-profile';const profiles=gpuProfiles(n);sec.innerHTML=`<div class="profile-head"><div><small>GPU${n}</small><h2>${gpuSpec(n)?.name||'GPU'+n}</h2></div><span>Atual <strong id="current${n}">--</strong></span></div><div class="profile-grid">${Object.entries(profiles).map(([name,p])=>`<div class="profile-card"><h3>${name.toUpperCase()}</h3>${fieldsFor(p).map(([lab,k])=>`<label>${lab}<input type="number" data-gpu="${n}" data-profile="${name}" data-field="${k}" value="${p[k]??''}" ${editable?'':'disabled'}></label>`).join('')}<button data-apply="${n}:${name}" ${editable?'':'disabled'}>Aplicar</button></div>`).join('')}</div>`;root.appendChild(sec)}root.querySelectorAll('[data-apply]').forEach(b=>b.onclick=async()=>{if(!editable)return openAuth();const[n,name]=b.dataset.apply.split(':');try{await api('/api/profile/apply',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({gpu:'gpu'+n,name})});msg(`GPU${n}: ${name.toUpperCase()} aplicado.`);refreshProfilesCurrent()}catch(e){msg(e.message,true)}});refreshProfilesCurrent()}
async function refreshProfilesCurrent(){for(let n=0;n<4;n++){if(!gpuEnabled(n))continue;const e=$('current'+n);if(e)try{e.textContent=String(await live(gpuPrefix(n)+'.profile')||'--').toUpperCase()}catch{e.textContent='--'}}}
function fill(){ $('capacity').value=cfg.power.capacity_w;$('efficiency').value=cfg.power.efficiency*100;$('hardLimit').value=cfg.power.hard_limit_w;$('reserve').value=cfg.power.reserve_w;$('gpuTemp').value=cfg.thermal.gpu_limit_c;$('cpuTemp').value=cfg.thermal.cpu_limit_c;$('interval').value=cfg.server.interval_s;$('services').value=(cfg.services.allowed||[]).join('\n');renderProfiles()}
function collect(){cfg.power.capacity_w=+$('capacity').value;cfg.power.efficiency=+$('efficiency').value/100;cfg.power.hard_limit_w=+$('hardLimit').value;cfg.power.reserve_w=+$('reserve').value;cfg.thermal.gpu_limit_c=+$('gpuTemp').value;cfg.thermal.cpu_limit_c=+$('cpuTemp').value;cfg.server.interval_s=+$('interval').value;cfg.services.allowed=$('services').value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);document.querySelectorAll('[data-profile][data-field]').forEach(e=>{const n=+e.dataset.gpu,p=gpuProfiles(n)[e.dataset.profile],v=e.value.trim();p[e.dataset.field]=v===''?null:+v});if($('newKey').value)cfg.server.control_key=$('newKey').value;return cfg}
function setEditable(v){editable=v;$('sessionMode').textContent=v?'Gestão desbloqueada':'Modo leitura';$('authButton').textContent=v?'Bloquear gestão':'Autenticar';document.querySelectorAll('.form input,.form textarea,.actions button').forEach(e=>e.disabled=!v);if(cfg)renderProfiles();$('updatesEnabled').disabled=!v;$('updatesTime').disabled=!v;$('updatesSave').disabled=!v;$('fansSave').disabled=!v||!h81Settings;$('fansMax').disabled=!v||!h81Settings;document.querySelectorAll('#fansH81 input').forEach(x=>x.disabled=!v);if(setupMode){document.querySelectorAll('.page:not([data-page="fans"]) input,.page:not([data-page="fans"]) textarea,.page[data-page="profiles"] button,.page[data-page="config"] button,.page[data-page="updates"] button').forEach(x=>x.disabled=true);$('updatesEnabled').disabled=true;$('updatesTime').disabled=true;$('updatesSave').disabled=true}if(v){if(!setupMode)refreshUpdates();if(document.querySelector('.page.active')?.dataset.page==='fans')refreshFans()}else{$('updatesStatus').textContent='Autentica-te para consultar e alterar as actualizações.';$('updatesLog').textContent=''}}
function openAuth(){$('authModal').hidden=false;$('key').focus()}
$('authButton').onclick=()=>{if(editable){sessionStorage.removeItem('hipervisorKey');setEditable(false)}else openAuth()};$('authClose').onclick=()=>$('authModal').hidden=true;$('connect').onclick=async()=>{sessionStorage.setItem('hipervisorKey',$('key').value);try{await api('/api/auth');$('authModal').hidden=true;setEditable(true);msg('Gestão desbloqueada.')}catch(e){sessionStorage.removeItem('hipervisorKey');$('loginMessage').textContent='Chave inválida. Consulta sudo cat /etc/lumicore/control-key no servidor.'}};
$('validate').onclick=async()=>{try{await api('/api/config/validate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(collect())});msg('Configuração válida.')}catch(e){msg(e.message,true)}};$('save').onclick=async()=>{try{await api('/api/config/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(collect())});msg('Guardado; núcleo reiniciado.');setTimeout(()=>location.reload(),1800)}catch(e){msg(e.message,true)}};$('restart').onclick=async()=>{try{await api('/api/core/restart',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});msg('Núcleo reiniciado.')}catch(e){msg(e.message,true)}};
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.dataset.page===b.dataset.page));if(b.dataset.page==='profiles'&&!setupMode)refreshProfilesCurrent();if(b.dataset.page==='updates'&&editable&&!setupMode)refreshUpdates();if(b.dataset.page==='about')refreshSystem();if(b.dataset.page==='fans')refreshFans()});
(async()=>{try{
 const mode=await api('/api/setup').catch(()=>({state:'READY'}));
 setupMode=mode.state==='SETUP';
 if(setupMode){
   $('setupNotice').hidden=false;
   $('systemState').textContent='SETUP';
   $('instantPower').textContent='--';
   $('sessionMode').textContent='Configuração inicial · GPU em espera';
   // Keep the approved full UI and assets; select the only writable
   // controller during initial setup. Never synthesize GPU profiles.
   document.querySelectorAll('.page').forEach(p=>{
     if(!['fans','about'].includes(p.dataset.page)){
       const note=document.createElement('p');note.className='setup-note';
       note.textContent=p.dataset.page==='home'?'Telemetria ativa em modo leitura. A aprovação LHDB é necessária apenas para aplicar perfis de hardware.':'Hardware ainda não aprovado na LHDB. Os comandos desta área permanecem bloqueados até validação.';
       p.prepend(note);
     }
     p.classList.toggle('active',p.dataset.page==='home');
   });
   document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.page==='home'));
   try{platformFanState=await api('/api/fans')}catch{}
   try{await api('/api/auth');setEditable(true)}catch{setEditable(false)}
   await refreshFans();
   await refreshHardware();
   setInterval(refreshHardware,3000);
   setInterval(()=>{if(document.querySelector('.page.active')?.dataset.page==='fans')refreshFansStatus()},2500);
   return;
 }
 cfg=await api('/api/config');fill();try{platformFanState=await api('/api/fans')}catch{}
 await buildHardware();try{await api('/api/auth');setEditable(true)}catch{setEditable(false)}
 await refreshHardware();setInterval(refreshHardware,3000);
 await refreshState();setInterval(refreshState,2500);
 setInterval(()=>{if(document.querySelector('.page.active')?.dataset.page==='fans')refreshFansStatus()},2500);
 }catch(e){msg(e.message,true)}})();

async function refreshUpdates(){try{const d=await api('/api/updates');$('updatesEnabled').checked=d.enabled;$('updatesTime').value=d.time;$('updatesStatus').textContent=`Timer: ${d.timer?.ActiveState||'--'} · Próxima execução: ${d.timer?.NextElapseUSecRealtime||'--'} · Último resultado: ${d.service?.Result||'--'}`;$('updatesLog').textContent=d.log||'Sem execuções registadas.'}catch(e){msg(e.message,true)}}
$('updatesSave').onclick=async()=>{try{await api('/api/updates/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled:$('updatesEnabled').checked,time:$('updatesTime').value})});msg('Actualizações configuradas.');await refreshUpdates()}catch(e){msg(e.message,true)}};
async function refreshSystem(){try{const d=await api('/api/system'),r=$('systemInfo');r.replaceChildren();for(const [k,v] of [['Sistema',d.product+' '+d.version],['Máquina',d.hostname],['Instância',d.instance],['SO',d.os],['Kernel',d.kernel],['Motherboard',[d.board_vendor,d.board_name].filter(Boolean).join(' ')],['Rede',(d.interfaces||[]).map(x=>x.name+' · '+x.mac).join(' / ')]]){const row=document.createElement('p');row.textContent=k+': '+(v||'--');r.appendChild(row)}}catch(e){msg(e.message,true)}}


// LumiCore 0.2: platform-aware fan configuration; non-H81 systems keep
// existing firmware / it87 support and never receive H81 settings.
function fansFillCurve(settings){
 const root=$('fansCpuCurve');root.replaceChildren();
 const table=document.createElement('table');table.className='fans-table';
 table.innerHTML='<thead><tr><th>Patamar</th><th>Subir a (°C)</th><th>Descer a (°C)</th><th>Velocidade CPU (%)</th></tr></thead>';
 const body=document.createElement('tbody');
 for(let i=0;i<5;i++){
  const tr=document.createElement('tr');
  const a=document.createElement('td');a.textContent=i+1;tr.appendChild(a);
  for(const [type,value,min,max] of [
   ['up',i<4?settings.cpu.up_c[i]:null,25,85],
   ['down',i<4?settings.cpu.down_c[i]:null,20,85],
   ['speed',settings.cpu.speeds_pct[i],30,100]
  ]){
   const td=document.createElement('td');
   if(value===null){td.textContent='—'}
   else {const inp=document.createElement('input');inp.type='number';inp.min=min;inp.max=max;inp.step=1;
      inp.value=value;inp.dataset.fanField=type;inp.dataset.fanIndex=i;
      inp.disabled=!editable||type==='speed'&&i===4;td.appendChild(inp)}
   tr.appendChild(td);
  }
  body.appendChild(tr);
 }
 table.appendChild(body);root.appendChild(table);
}
function fansRenderSettings(){
 const c=h81Settings;if(!c)return;
 fansFillCurve(c);
 $('fansCpuMinRpm').value=c.cpu.rpm_min;
 $('fansCpuEmergency').value=c.cpu.temp_emergency_c;
 $('fansCaseStart').value=c.case.start_at_pct;
 $('fansCaseInitial').value=c.case.start_speed_pct;
 $('fansCaseFull').value=c.case.full_at_pct;
 $('fansCaseOff').value=c.case.off_below_pct;
 $('fansEnabled').checked=!!c.enabled;
 $('fansSave').disabled=!editable;
 $('fansMax').disabled=!editable;
 document.querySelectorAll('#fansH81 input').forEach(x=>x.disabled=!editable || x.dataset.fanField==='speed'&&x.dataset.fanIndex==='4');
}
function fansCollectSettings(){
 const c=JSON.parse(JSON.stringify(h81Settings));
 const int=id=>{const v=Number($(id).value);if(!Number.isInteger(v))throw Error('Valor inválido: '+id);return v};
 document.querySelectorAll('[data-fan-field]').forEach(input=>{
  const i=Number(input.dataset.fanIndex),v=Number(input.value);
  if(!Number.isInteger(v))throw Error('Curva CPU inválida');
  if(input.dataset.fanField==='up')c.cpu.up_c[i]=v;
  if(input.dataset.fanField==='down')c.cpu.down_c[i]=v;
  if(input.dataset.fanField==='speed')c.cpu.speeds_pct[i]=v;
 });
 c.cpu.rpm_min=int('fansCpuMinRpm');c.cpu.temp_emergency_c=int('fansCpuEmergency');
 c.case.start_at_pct=int('fansCaseStart');c.case.start_speed_pct=int('fansCaseInitial');
 c.case.full_at_pct=int('fansCaseFull');c.case.off_below_pct=int('fansCaseOff');
 c.enabled=$('fansEnabled').checked;
 return c;
}
async function refreshFansStatus(){
 try{
  const s=await api('/api/fans');platformFanState=s;
  $('fansDevice').textContent=s.present?'h81_fan':(cfg?.case_fans?.enabled?'hwmon nativo':'--');
  $('fansMode').textContent=s.present?('H81 · '+s.mode):'Política da plataforma atual';
  $('fansCpuRpm').textContent=fmt(s.cpu_rpm,' RPM');$('fansCpuPwm').textContent=fmt(s.cpu_target_pct,' % PWM');
  $('fansCaseRpm').textContent=fmt(s.case_rpm,' RPM');$('fansCasePwm').textContent=fmt(s.case_target_pct,' % PWM');
  $('fansReference').textContent=fmt(s.demand_pct,' %');$('fansReason').textContent=s.reason||'--';
  const show=s.platform==='h81'&&s.present;
  $('fansH81').hidden=!show;
  $('fansUnavailable').hidden=show;
  if(!show)$('fansUnavailable').textContent='Sem controlador H81 ligado. As regras e controladores nativos de outras motherboards continuam independentes.';
 }catch(e){$('fansUnavailable').hidden=false;$('fansUnavailable').textContent='Telemetria indisponível: '+e.message}
}
async function refreshFans(){
 await refreshFansStatus();
 if(!platformFanState?.present||!editable)return;
 try{
  const r=await api('/api/fans/settings');
  if(r.available&&r.settings){h81Settings=r.settings;fansRenderSettings()}
 }catch(e){msg(e.message,true)}
}
$('fansSave').onclick=async()=>{
 if(!editable)return openAuth();
 try{
  const config=fansCollectSettings();
  const saved=await api('/api/fans/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(config)});
  h81Settings=saved.settings;fansRenderSettings();await refreshFansStatus();msg('Curvas H81 guardadas.');
  $('fansSaveMessage').textContent='Curvas guardadas em /etc/lumicore/platforms/h81/fans.json';
 }catch(e){msg(e.message,true);$('fansSaveMessage').textContent=e.message}
};
$('fansMax').onclick=async()=>{
 if(!editable)return openAuth();
 if(!h81Settings)return;
 try{
  const safe=JSON.parse(JSON.stringify(h81Settings));safe.enabled=false;
  const saved=await api('/api/fans/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(safe)});
  h81Settings=saved.settings;fansRenderSettings();await refreshFansStatus();
  msg('H81: modo máximo pedido; curva automática desativada.');
 }catch(e){msg(e.message,true)}
};


// LumiCore 0.2.3: monitored hardware is always visible, even before LHDB approval.
// No GPU profiles are synthesised or activated. The approved chassis image is unchanged.
function hardwareSummaryTile(title,big,small){
 const card=document.createElement('article'),a=document.createElement('span'),b=document.createElement('strong'),c=document.createElement('small');
 a.textContent=title;b.textContent=big;c.textContent=small||'';card.append(a,b,c);return card;
}
function renderHardwareSummary(){
 const h=hardwareSnapshot;if(!h)return;
 const root=$('hardwareSummary');root.replaceChildren();
 const cpu=h.cpu||{},ram=h.ram||{},pl=cpu.pl||{};
 root.appendChild(hardwareSummaryTile('CPU',cpu.model||'Não identificado',`${cpu.physical_cores??'--'} núcleos / ${cpu.logical_cpus??'--'} threads · ${fmt(cpu.clock_mhz,' MHz')} · ${fmt(cpu.temp_c,' °C')}`));
 root.appendChild(hardwareSummaryTile('RAM',fmt(ram.used_mb,' MB')+' / '+fmt(ram.total_mb,' MB'),`${fmt(ram.usage_pct,' %')} em utilização`));
 const pls=pl.pl1_w==null?'PL indisponível':`PL1 ${fmt(pl.pl1_w,' W')} · PL2 ${fmt(pl.pl2_w,' W')}`;
 const lock=pl.lock===false?'MSR desbloqueado':pl.lock===true?'MSR bloqueado':'LOCK não identificado';
 root.appendChild(hardwareSummaryTile('PL Xeon (package)',pls,`${lock} · patch EFI não confirmado`));
 const gpus=h.gpus||[];
 root.appendChild(hardwareSummaryTile('GPU',gpus.length?gpus.map(g=>g.name).join(' / '):'Nenhuma GPU',gpus.length?gpus.map(g=>`Fan ${fmt(g.fan_pct,' %')} · ${fmt(g.temp_c,' °C')}`).join(' | '):'Deteção PCI'));
 const f=platformFanState||{};
 root.appendChild(hardwareSummaryTile('Ventoinhas',f.present?`CPU ${fmt(f.cpu_rpm,' RPM')}`:'Controlador indisponível',f.present?`CASE ${fmt(f.case_rpm,' RPM')} · ${f.mode||'--'}`:'A procurar hwmon'));
}
function renderHardwareDetail(){
 const h=hardwareSnapshot;if(!h)return;
 const cpu=h.cpu||{},ram=h.ram||{},gpus=h.gpus||[],pl=cpu.pl||{};
 let title=selected.toUpperCase(),r=[];
 if(selected==='cpu'){
  title=cpu.model||'CPU';
  r=[['Núcleos físicos',fmt(cpu.physical_cores)],['Threads / CPUs lógicos',fmt(cpu.logical_cpus)],['Temperatura',fmt(cpu.temp_c,' °C')],['Utilização',fmt(cpu.usage_pct,' %')],['Consumo estimado',fmt(cpu.power_w,' W')],['Frequência média',fmt(cpu.clock_mhz,' MHz')],['Clock mínimo reportado',fmt(cpu.min_mhz,' MHz')],['Clock máximo reportado',fmt(cpu.max_mhz,' MHz')],['Frequência máxima anunciada',fmt(cpu.rated_max_mhz,' MHz')],['Governor',cpu.governor||'--'],['Turbo',cpu.turbo_enabled==null?'Desconhecido':cpu.turbo_enabled?'Ativo':'Desativado'],['PL1 (CPU/package)',fmt(pl.pl1_w,' W')],['PL2 (CPU/package)',fmt(pl.pl2_w,' W')],['MSR PL LOCK',pl.lock==null?'Não disponível':pl.lock?'Bloqueado':'Desbloqueado'],['Leitura PL',pl.source||'--'],['Patch EFI','Não confirmado por esta telemetria']];
  for(const f of cpu.frequencies_mhz||[])r.push([`CPU lógico ${f.cpu}`,fmt(f.mhz,' MHz')]);
 }else if(selected==='ram'){
  title='Memória RAM';r=[['Utilização',fmt(ram.usage_pct,' %')],['Em uso',fmt(ram.used_mb,' MB')],['Total',fmt(ram.total_mb,' MB')]];
 }else if(selected.startsWith('gpu')){
  const id=Number(selected.slice(3)),g=gpus[id];title=g?.name||'GPU';
  r=g?[['Fabricante',g.vendor],['PCI',g.pci],['Driver',g.driver||'--'],['Temperatura',fmt(g.temp_c,' °C')],['Utilização',fmt(g.usage_pct,' %')],['Potência',fmt(g.power_w,' W')],['Core',fmt(g.core_mhz,' MHz')],['Memória',fmt(g.mem_mhz,' MHz')],['VRAM',`${fmt(g.vram_used_mb,' MB')} / ${fmt(g.vram_total_mb,' MB')}`],['Ventoinha',fmt(g.fan_pct,' %')],['RPM',fmt(g.fan_rpm)],['Telemetria',g.telemetry_ok?'Disponível':'Indisponível']]:[['Estado','Não encontrado']];
 }else if(selected==='fan-side'||selected==='fan-front'||selected==='fan-rear'){
  const f=platformFanState||{};title='Ventoinhas H81';r=[['CPU',fmt(f.cpu_rpm,' RPM')],['PWM CPU',fmt(f.cpu_target_pct,' %')],['CASE',fmt(f.case_rpm,' RPM')],['PWM CASE',fmt(f.case_target_pct,' %')],['Modo',f.mode||'--'],['Controlador',f.controller||'--']];
 }else if(selected==='ssd'||selected==='hdd'){
  const d=(h.disks||[]).find(x=>diskType(x)===selected);title='Armazenamento';r=d?[['Montagem',d.path],['Sistema',d.fstype],['Uso',fmt(d.usage_pct,' %')],['Ocupado',fmt(d.used_gb,' GB')],['Capacidade',fmt(d.total_gb,' GB')]]:[['Estado','Não encontrado']];
 }else if(selected==='psu'){
  title='Potência';r=[['CPU package',fmt(cpu.power_w,' W')],['GPU(s)',gpus.length?gpus.map(g=>fmt(g.power_w,' W')).join(' + '):'--'],['Tomada','Sem sensor ligado']];
 }
 $('detailTitle').textContent=title;rows(r);
}
function buildHardwareSetup(){
 const h=hardwareSnapshot;if(!h)return;
 const sig=JSON.stringify([(h.gpus||[]).map(g=>g.pci),(h.disks||[]).map(d=>d.path),Boolean(h.ram?.total_mb),Boolean(platformFanState?.present)]);
 if(sig===hardwareLayoutSig)return;
 hardwareLayoutSig=sig;
 const stack=$('gpuStack');stack.replaceChildren();
 (h.gpus||[]).forEach((gpu,n)=>{
  const top=47.5+n*6;
  const unit=document.createElement('div');unit.className='gpu-unit';unit.style.top=top+'%';
  const label=document.createElement('span');label.textContent=`GPU${n} · ${gpu.vendor}`;unit.appendChild(label);stack.appendChild(unit);
  const point=document.createElement('button');point.className='part hotspot gpu-point';
  point.dataset.component='gpu'+n;point.title=gpu.name;point.setAttribute('aria-label','Telemetria GPU '+n);
  point.style.left='29%';point.style.top=(top+2.2)+'%';stack.appendChild(point);
 });
 setVisible('.part.ram',Number(h.ram?.total_mb)>0);
 disks=h.disks||[];
 setVisible('.part.ssd',disks.some(x=>diskType(x)==='ssd'));
 setVisible('.part.hdd',disks.some(x=>diskType(x)==='hdd'));
 const on=!!platformFanState?.present;
 setVisible('.casefan.side',on);setVisible('.casefan.rear',false);setVisible('.casefan.front',false);
 $('fanRearAsset').hidden=true;$('fanFrontAsset').hidden=true;
 document.querySelectorAll('.part').forEach(x=>x.onclick=()=>select(x.dataset.component,x));
 const current=document.querySelector(`[data-component="${selected}"]:not([hidden])`);
 if(!current){selected='cpu'}
}
async function refreshHardware(){
 try{
  const [hardware, newFans]=await Promise.all([api('/api/hardware'),api('/api/fans').catch(()=>null)]);
  hardwareSnapshot=hardware;
  if(newFans)platformFanState=newFans;
  if(setupMode){buildHardwareSetup();$('systemState').textContent='SETUP · Leitura';}
  renderHardwareSummary();
  if(document.querySelector('.page.active')?.dataset.page==='home'&&setupMode)renderHardwareDetail();
 }catch(e){msg('Telemetria: '+e.message,true)}
}
