"""LumiCore first-run manager, including independent H81 fan commissioning."""
from __future__ import annotations
import json
import os
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from hipervisor.core.config import load

DB = '/var/lib/lumicore/lhdb.dat'
FLAG = Path('/etc/lumicore/hardware-approved')
CORE = 'http://127.0.0.1:8765'

HTML = r'''<!doctype html>
<html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>LumiCore 0.2 · Configuração e ventoinhas</title>
<style>
:root{color-scheme:dark;font-family:system-ui,sans-serif;background:#09141e;color:#e4f1fa}
*{box-sizing:border-box}body{max-width:1080px;margin:25px auto;padding:16px;line-height:1.5}
header{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;border-bottom:1px solid #254052;padding-bottom:16px}
h1{margin:0;color:#81d9ff;font-size:1.7rem}h2{font-size:1.2rem;color:#a6e3ff}
nav{display:flex;gap:10px;margin:20px 0}button{border:1px solid #4082a0;border-radius:7px;padding:9px 14px;color:#ebf9ff;background:#16465d;cursor:pointer}button:disabled{opacity:.45;cursor:not-allowed}
.panel{background:#112634;border:1px solid #2a5269;border-radius:12px;margin:16px 0;padding:22px}
.tab[hidden]{display:none}.tag{background:#25495d;padding:5px 9px;border-radius:6px;font-size:.8rem}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(195px,1fr));gap:12px}.metric{background:#09202d;border-radius:9px;padding:14px}.metric strong{display:block;font-size:1.6rem;color:#a2efff}
input[type=number],input[type=password]{background:#081925;color:#eef9ff;padding:8px;border:1px solid #54849b;border-radius:6px;max-width:155px}
input[type=password]{max-width:350px;width:100%}table{border-collapse:collapse;max-width:100%;width:100%}td,th{padding:8px;text-align:left;border-bottom:1px solid #2b4354}
.alert{background:#423523;padding:10px;border-radius:7px}small,.muted{color:#b3c9d7}.row{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.section{margin-top:20px}#message{white-space:pre-wrap}
</style></head><body>
<header><h1>LumiCore <small>0.2.1 · Configuração inicial</small></h1><span id="mode" class="tag">SETUP</span></header>
<nav><button data-tab="setup">Sistema</button><button data-tab="fans">Ventoinhas</button></nav>
<div id="setup" class="panel tab"><h2>Configuração de hardware</h2>
<p>O núcleo e a gestão web estão instalados. Os perfis de GPU e os limites de energia continuam inativos até serem validados na LHDB.</p>
<p><code>sudo lumicore-lhdb show</code> — examinar o estado da base.</p>
<p>Depois de validar os perfis GPU: <code>sudo lumicore-setup activate</code>.</p>
<p class="muted">As ventoinhas H81 podem ser geridas separadamente na aba Ventoinhas, sem aprovar os restantes perfis de hardware.</p></div>
<div id="fans" class="panel tab" hidden>
<h2>Ventoinhas · Perfil da plataforma</h2>
<p id="availability">A procurar o controlador Linux hwmon...</p>
<div class="grid">
<div class="metric">CPU · RPM<strong id="cpuRpm">—</strong><small id="cpuTarget">—</small></div>
<div class="metric">CASE · RPM<strong id="caseRpm">—</strong><small id="caseTarget">—</small></div>
<div class="metric">Temperatura CPU<strong id="temp">—</strong><small>Package id 0</small></div>
<div class="metric">Estado<strong id="fanMode">—</strong><small id="reason">—</small></div>
</div>
<div class="section row"><label>Chave de gestão <input type="password" id="key" autocomplete="off" placeholder="/etc/lumicore/control-key"></label><button id="unlock">Autenticar</button></div>
<div id="settings" hidden>
<p class="alert">O controlo automático é experimental. Não ativar sem supervisão e sem validar o fail-safe elétrico do ESP32. Se a telemetria de alguma ventoinha GPU estiver indisponível, a CASE fica a 100% por segurança.</p>
<h2>Curva CPU</h2>
<table><thead><tr><th>Etapa</th><th>Subir a °C</th><th>Descer abaixo de °C</th><th>PWM CPU</th></tr></thead><tbody id="cpuRows"></tbody></table>
<div class="section row"><label>RPM mínimas CPU <input id="minRpm" type="number" min="300" max="3000"></label><label>Emergência CPU °C <input id="emergency" type="number" min="55" max="85"></label></div>
<h2>Curva lateral</h2>
<p class="muted">Referência = maior PWM CPU/GPU. Abaixo de 50%: desligada; aos 50%: 30%; aos 75%: 100%.</p>
<div class="row"><label>Iniciar em % <input id="caseStart" type="number"></label><label>PWM inicial % <input id="caseInitial" type="number"></label><label>Máximo em % <input id="caseFull" type="number"></label><label>Desligar abaixo de % <input id="caseOff" type="number"></label></div>
<p><label><input type="checkbox" id="enabled"> Ativar curvas automáticas H81</label></p>
<div class="row"><button id="save">Guardar configuração</button><button id="max">Forçar MAX e desativar curvas</button></div>
</div>
<p id="message" role="status"></p></div>
<script>
'use strict';
const $=id=>document.getElementById(id);
let token='', profile=null;
for(const b of document.querySelectorAll('[data-tab]'))b.onclick=()=>{
 for(const x of document.querySelectorAll('.tab'))x.hidden=x.id!==b.dataset.tab;
};
async function request(url,opts={}){
 const r=await fetch(url,{cache:'no-store',...opts,headers:{...(opts.headers||{}),...(token?{'X-Hipervisor-Key':token}:{})}});
 const data=await r.json();if(!r.ok)throw Error(data.error||('HTTP '+r.status));return data;
}
const pretty=x=>(x===null||x===undefined)?'—':x;
async function poll(){
 try{
  const s=await request('/api/fans');
  $('availability').textContent=s.present?'Controlador encontrado: '+s.controller:'Controlador H81 ainda não encontrado. Verificar plataforma-h81 e a ponte USB.';
  $('cpuRpm').textContent=pretty(s.cpu_rpm);$('caseRpm').textContent=pretty(s.case_rpm);
  $('cpuTarget').textContent='PWM '+pretty(s.cpu_target_pct)+'%';$('caseTarget').textContent='PWM '+pretty(s.case_target_pct)+'%';
  $('temp').textContent=s.cpu_temp_c==null?'—':s.cpu_temp_c.toFixed(1)+' °C';
  $('fanMode').textContent=s.mode; $('reason').textContent=s.reason;
 }catch(e){$('availability').textContent=e.message;}
}
function showSettings(){
 if(!profile)return;
 $('settings').hidden=false;$('cpuRows').innerHTML='';
 for(let i=0;i<5;i++){
  const tr=document.createElement('tr');const first=document.createElement('td');first.textContent=i+1;tr.append(first);
  for(const [field,count] of [['up_c',4],['down_c',4],['speeds_pct',5]]){
   const td=document.createElement('td');
   if(i<count){const input=document.createElement('input');input.type='number';input.min=field==='speeds_pct'?'30':'20';input.max=field==='speeds_pct'?'100':'85';input.value=profile.cpu[field][i];input.dataset.field=field;input.dataset.index=i;td.append(input)}
   tr.append(td);
  }$('cpuRows').append(tr);
 }
 $('minRpm').value=profile.cpu.rpm_min;$('emergency').value=profile.cpu.temp_emergency_c;
 $('caseStart').value=profile.case.start_at_pct;$('caseInitial').value=profile.case.start_speed_pct;
 $('caseFull').value=profile.case.full_at_pct;$('caseOff').value=profile.case.off_below_pct;
 $('enabled').checked=profile.enabled;
}
function collect(){
 const c=JSON.parse(JSON.stringify(profile));
 for(const input of document.querySelectorAll('[data-field]'))c.cpu[input.dataset.field][Number(input.dataset.index)]=Number(input.value);
 c.cpu.rpm_min=Number($('minRpm').value);c.cpu.temp_emergency_c=Number($('emergency').value);
 c.case.start_at_pct=Number($('caseStart').value);c.case.start_speed_pct=Number($('caseInitial').value);
 c.case.full_at_pct=Number($('caseFull').value);c.case.off_below_pct=Number($('caseOff').value);
 c.enabled=$('enabled').checked;return c;
}
$('unlock').onclick=async()=>{
 token=$('key').value;try{const data=await request('/api/fans/settings');
 if(!data.available||!data.settings)throw Error('Controlador H81 não detetado');
 profile=data.settings;showSettings();$('message').textContent='Autenticado. Alterações ainda não aplicadas.';
 }catch(e){token='';$('message').textContent=e.message;}
};
$('save').onclick=async()=>{
 try{const r=await request('/api/fans/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(collect())});
 profile=r.settings;showSettings();$('message').textContent='Curvas guardadas. Estado: '+(profile.enabled?'automático':'MAX');
 }catch(e){$('message').textContent=e.message;}
};
$('max').onclick=async()=>{
 try{const c=collect();c.enabled=false;const r=await request('/api/fans/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(c)});
 profile=r.settings;showSettings();$('message').textContent='Modo MAX pedido.';
 }catch(e){$('message').textContent=e.message;}
};
setInterval(poll,2000);poll();
</script></body></html>'''


def ready():
    if not FLAG.is_file():
        return False
    try:
        cfg = load(DB)
        return Path(cfg['gpu']['adapter']).is_file()
    except Exception:
        return False


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def respond(self, data, mime='application/json', status=200):
        self.send_response(status)
        self.send_header('Content-Type', mime + '; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _proxy(self, target, method='GET'):
        headers = {}
        key = self.headers.get('X-Hipervisor-Key')
        if key:
            headers['X-Hipervisor-Key'] = key
        body = None
        if method == 'POST':
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 4096:
                return self.respond(b'{"error":"invalid_body"}', status=400)
            body = self.rfile.read(length)
            headers['Content-Type'] = 'application/json'
        try:
            req = urllib.request.Request(CORE + target, data=body, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=4) as res:
                self.respond(res.read(), status=res.status)
        except urllib.error.HTTPError as exc:
            self.respond(exc.read(), status=exc.code)
        except (OSError, TimeoutError):
            self.respond(b'{"error":"core_unavailable"}', status=502)

    def do_GET(self):
        path = self.path.split('?', 1)[0]
        if path in ('/', '/admin'):
            return self.respond(HTML.encode('utf-8'), mime='text/html')
        if path == '/health':
            return self.respond(json.dumps({'ok': True, 'version': '0.2.1',
                                            'state': 'SETUP', 'fans_independent': True}).encode())
        if path == '/api/system':
            return self._proxy('/v1/system')
        if path == '/api/fans':
            return self._proxy('/v1/fans')
        if path == '/api/fans/settings':
            return self._proxy('/v1/fans/settings')
        return self.respond(b'{"error":"setup_mode"}', status=409)

    def do_POST(self):
        if self.path == '/api/fans/settings':
            try:
                return self._proxy('/v1/fans/settings', method='POST')
            except ValueError:
                return self.respond(b'{"error":"invalid_body"}', status=400)
        return self.respond(b'{"error":"not_found"}', status=404)


def main():
    if ready():
        os.execv('/usr/bin/python3', ['/usr/bin/python3', '-m', 'hipervisor_web.app',
                                      '--config', DB])
    ThreadingHTTPServer(('0.0.0.0', 8766), Handler).serve_forever(poll_interval=0.5)


if __name__ == '__main__':
    main()
