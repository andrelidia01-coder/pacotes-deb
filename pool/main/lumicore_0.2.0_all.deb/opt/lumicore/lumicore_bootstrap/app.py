"""Safe first-boot API. No hardware control until explicit LHDB approval."""
import json, os, sys
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from hipervisor.identity import identity
from lumicore_fans import FanManager
from hipervisor.core.config import load
DB='/var/lib/lumicore/lhdb.dat'
APPROVED=Path('/etc/lumicore/hardware-approved')

def ready():
    if not APPROVED.is_file():return False,'awaiting_hardware_approval'
    try:
        cfg=load(DB)
        for item in [cfg['gpu']['adapter'],*(
            cfg[f'gpu{i}']['adapter'] for i in (1,2,3) if cfg.get(f'gpu{i}',{}).get('enabled'))]:
            if not Path(item).is_file():return False,'gpu_adapter_missing'
        return True,'configured'
    except Exception as exc:
        return False,'configuration_invalid'

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def _reply(self,code,obj):
        buf=json.dumps(obj).encode('utf-8')
        self.send_response(code);self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(buf)));self.send_header('Cache-Control','no-store')
        self.end_headers();self.wfile.write(buf)
    def do_GET(self):
        if self.path=='/v1/health':
            self._reply(200,{'ok':True,'product':'LumiCore','version':'0.2.0',
                'state':'SETUP','reason':self.server.reason})
        elif self.path=='/v1/system':
            d=identity({'instance_name':'Setup'})
            d['state']='SETUP'
            self._reply(200,d)
        elif self.path=='/v1/fans':self._reply(200,FanManager().status())
        elif self.path in ('/v1/commands','/v1/fans/settings'):
            self._reply(409,{'error':'setup_mode','reason':self.server.reason})
        else:self._reply(404,{'error':'not_found'})

def main():
    yes,reason=ready()
    if yes:
        os.execv('/usr/bin/python3', ['/usr/bin/python3','-m','hipervisor.app',
                                       '--database',DB])
    server=ThreadingHTTPServer(('0.0.0.0',8765),Handler)
    server.reason=reason
    print('LumiCore 0.2 em SETUP:',reason,flush=True)
    server.serve_forever(poll_interval=.5)

if __name__=='__main__':main()
