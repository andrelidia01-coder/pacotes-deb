# Hipervisor Web 1.3.1

Atualização independente da interface web. Não substitui nem modifica o núcleo
do Hipervisor.

## Novidade principal

A página **Resumo do sistema** apresenta uma vista lateral interativa inspirada
na montagem física do servidor. É possível selecionar diretamente:

- CPU;
- memória RAM;
- HDD de modelos na baia superior;
- SSD do sistema;
- GPU0 NVIDIA RTX 3060;
- GPU1 AMD RX 570;
- fonte de alimentação de 650 W.

Cada componente abre o respetivo painel de telemetria. Os alvos também podem ser
percorridos com `Tab` e ativados com `Enter` ou `Espaço`.

## Perfis independentes

A página **Perfis GPU** separa agora os controlos das duas placas:

- GPU0 NVIDIA: `gpu.profile.set`;
- GPU1 AMD: `gpu1.profile.set`.

Depois da autenticação, cada cartão tem um botão para aplicar diretamente
`ECO`, `MIN`, `MED`, `SWEET` ou `MAX`. A GPU1 apresenta e permite editar os
seus campos próprios: limite energético, Core DPM e VRAM DPM.

## Instalação

```bash
chmod +x install-web.sh
sudo ./install-web.sh
```

O instalador para apenas `hipervisor-web.service`, cria uma cópia recuperável
da interface anterior e instala a nova versão em `/opt/hipervisor/hipervisor_web`.

## Verificação

```bash
systemctl --no-pager --full status hipervisor-web
curl -sS http://127.0.0.1:8766/health
```

Resultado esperado do segundo comando:

```json
{"ok":true,"version":"1.3.1"}
```
