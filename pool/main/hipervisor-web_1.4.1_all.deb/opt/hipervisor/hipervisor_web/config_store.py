from __future__ import annotations

import hmac
import json
import shutil
import sqlite3
from copy import deepcopy
from pathlib import Path
from typing import Any

from hipervisor.core.config import load, validate

class ConfigStore:
    def __init__(self, path: str | Path):
        self.path = Path(path)

    def current(self) -> dict[str, Any]:
        return load(str(self.path))

    def public(self) -> dict[str, Any]:
        cfg = deepcopy(self.current())
        cfg['server']['control_key_configured'] = bool(cfg['server'].get('control_key'))
        cfg['server']['control_key'] = ''
        return cfg

    def authorized(self, supplied: str) -> bool:
        expected = str(self.current()['server'].get('control_key', ''))
        return bool(expected) and hmac.compare_digest(supplied, expected)

    def prepare(self, candidate: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(candidate, dict):
            raise ValueError('Configuração inválida')
        cfg = deepcopy(candidate)
        current = self.current()
        cfg.pop('instance_name', None)
        cfg.setdefault('server', {}).pop('control_key_configured', None)
        if not cfg['server'].get('control_key'):
            cfg['server']['control_key'] = current['server']['control_key']
        validate(cfg)
        return cfg

    def save(self, candidate: dict[str, Any]) -> None:
        cfg = self.prepare(candidate)
        shutil.copy2(self.path, self.path.with_suffix('.dat.bak'))
        with sqlite3.connect(self.path) as db:
            existing = {row[0] for row in db.execute('SELECT name FROM sections')}
            if set(cfg) != existing:
                raise ValueError('Secções de configuração diferentes da base instalada')
            db.executemany('UPDATE sections SET document=? WHERE name=?',
                [(json.dumps(value, ensure_ascii=False, sort_keys=True), name)
                 for name, value in cfg.items()])
