from __future__ import annotations
import json, mimetypes, subprocess, urllib.error, urllib.request
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse
from hipervisor_web import __version__
from hipervisor_web.config_store import ConfigStore

ASSETS=Path(__file__).with_name('static')
READ_COMMANDS=frozenset({
 'state','cpu.temp','cpu.power','cpu.usage','cpu.clock','ram.used','ram.total','ram.usage',
 'power.total','power.wall','power.load','power.history','storage.list','fans.state','fans.front','fans.exhaust',
 *[f'{p}.{s}' for p in ('gpu','gpu1','gpu2','gpu3') for s in ('name','temp','power','usage','clock','memory_clock','fan','profile')],
 'gpu.vram.used','gpu.vram.total'
})
CONTROL_COMMANDS=frozenset({f'{p}.profile.set' for p in ('gpu','gpu1','gpu2','gpu3')})

class ManagementServer(ThreadingHTTPServer):
 daemon_threads=True
 def __init__(self,address,config_path): self.store=ConfigStore(config_path); super().__init__(address,ManagementHandler)

class ManagementHandler(BaseHTTPRequestHandler):
 server:ManagementServer; protocol_version='HTTP/1.1'
 def log_message(self,fmt,*args): return
 def _path(self): return urlparse(self.path).path
 def _authorized(self): return self.server.store.authorized(self.headers.get('X-Hipervisor-Key',''))
 def _json(self,status,payload):
  body=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode(); self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(body)
 def _asset(self,name):
  path=(ASSETS/name).resolve()
  if not path.is_relative_to(ASSETS.resolve()) or not path.is_file(): self.send_error(404); return
  body=path.read_bytes(); self.send_response(200); self.send_header('Content-Type',mimetypes.guess_type(path.name)[0] or 'application/octet-stream'); self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-cache'); self.end_headers(); self.wfile.write(body)
 def _body(self):
  n=int(self.headers.get('Content-Length','0'))
  if n<=0 or n>65536: raise ValueError('Corpo inválido')
  return json.loads(self.rfile.read(n))
 def _core_request(self,path,payload=None,key=''):
  cfg=self.server.store.current(); url=f"http://127.0.0.1:{int(cfg['server']['port'])}{path}"; data=None; headers={}
  if payload is not None: data=json.dumps(payload).encode(); headers['Content-Type']='application/json'
  if key: headers['X-Hipervisor-Key']=key
  req=urllib.request.Request(url,data=data,method='POST' if payload is not None else 'GET',headers=headers)
  with urllib.request.urlopen(req,timeout=35.0) as r: return json.load(r)
 def _core_value(self,command,args=None):
  if command not in READ_COMMANDS: raise ValueError('Métrica não autorizada')
  return self._core_request('/v1/run',{'command':command,'args':args or {}}).get('result')
 def _core_control(self,command,args):
  if command not in CONTROL_COMMANDS: raise ValueError('Comando não autorizado')
  return self._core_request('/v1/run',{'command':command,'args':args},self.headers.get('X-Hipervisor-Key','')).get('result')
 def _apply_profile(self,p):
  if not isinstance(p,dict): raise ValueError('Pedido inválido')
  gpu,name=p.get('gpu'),p.get('name'); cmd={'gpu0':'gpu.profile.set','gpu1':'gpu1.profile.set','gpu2':'gpu2.profile.set','gpu3':'gpu3.profile.set'}.get(gpu)
  if not cmd or not isinstance(name,str): raise ValueError('GPU ou perfil inválido')
  cfg=self.server.store.current(); profiles=cfg.get('profiles',{}) if gpu=='gpu0' else cfg.get(gpu,{}).get('profiles',{})
  name=name.strip().lower()
  if name not in profiles: raise ValueError(f'Perfil desconhecido para {gpu.upper()}: {name}')
  return self._core_control(cmd,{'name':name})
 def do_GET(self):
  p=self._path()
  if p in ('/','/admin'): return self._asset('index.html')
  if p in ('/app.js','/style.css'): return self._asset(p[1:])
  if p.startswith('/icons/'): return self._asset(p[1:])
  if p=='/health': return self._json(200,{'ok':True,'version':__version__})
  if p=='/api/config': return self._json(200,self.server.store.public())
  if p=='/api/commands':
   try: return self._json(200,self._core_request('/v1/commands'))
   except Exception as e: return self._json(502,{'error':str(e)})
  if p=='/api/status':
   r=subprocess.run(['systemctl','is-active','hipervisor.service'],capture_output=True,text=True,timeout=3); return self._json(200,{'core':r.stdout.strip()})
  if p.startswith('/api/live/'):
   try: return self._json(200,{'result':self._core_value(p.removeprefix('/api/live/'))})
   except Exception as e: return self._json(502,{'error':str(e)})
  if p=='/api/energy':
   try: period=parse_qs(urlparse(self.path).query).get('range',['24h'])[0]; return self._json(200,self._core_value('power.history',{'range':period,'points':240}))
   except Exception as e: return self._json(502,{'error':str(e)})
  if p=='/api/auth': return self._json(200,{'authorized':True}) if self._authorized() else self._json(401,{'error':'unauthorized'})
  self._json(404,{'error':'not_found'})
 def do_POST(self):
  if not self._authorized(): return self._json(401,{'error':'unauthorized'})
  try:
   payload=self._body(); p=self._path()
   if p=='/api/config/validate': self.server.store.prepare(payload); return self._json(200,{'ok':True})
   if p=='/api/config/save': self.server.store.save(payload); subprocess.run(['systemctl','restart','hipervisor.service'],check=True,capture_output=True,text=True,timeout=10); return self._json(200,{'ok':True,'restarted':True})
   if p=='/api/core/restart': subprocess.run(['systemctl','restart','hipervisor.service'],check=True,capture_output=True,text=True,timeout=10); return self._json(200,{'ok':True})
   if p=='/api/profile/apply': return self._json(200,{'ok':True,'result':self._apply_profile(payload)})
   self._json(404,{'error':'not_found'})
  except (ValueError,json.JSONDecodeError) as e: self._json(400,{'error':str(e)})
  except Exception as e: self._json(500,{'error':str(e)})
