from __future__ import annotations

import argparse
import signal
import threading

from hipervisor.core.config import load
from hipervisor_web.server import ManagementServer


def main() -> int:
    parser = argparse.ArgumentParser(description="Hipervisor Gestão Web")
    parser.add_argument("--config", default="/var/lib/hipervisor/system.dat")
    args = parser.parse_args()
    cfg = load(args.config)
    web = cfg.get("web", {"host": "0.0.0.0", "port": 8766})
    server = ManagementServer(
        (str(web["host"]), int(web["port"])),
        args.config,
    )
    def stop(_signum: int, _frame: object) -> None:
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
