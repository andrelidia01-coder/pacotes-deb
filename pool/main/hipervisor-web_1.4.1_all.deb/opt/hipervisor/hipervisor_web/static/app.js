let cfg=null, editable=false, selected='cpu', disks=[], fans={}, available=new Set();
const $=id=>document.getElementById(id), key=()=>sessionStorage.getItem('hipervisorKey')||'';
async function api(path,opt={}){const r=await fetch(path,{...opt,headers:{'X-Hipervisor-Key':key(),...(opt.headers||{})}});const d=await r.json();if(!r.ok)throw Error(d.error||`HTTP ${r.status}`);return d}
async function live(c){return (await api('/api/live/'+c)).result}
const fmt=(v,u='')=>v==null?'--':`${typeof v==='number'&&!Number.isInteger(v)?v.toFixed(1):v}${u}`;
function msg(t,e=false){$('message').textContent=t;$('message').style.color=e?'#ff6680':'#7aa4bd'}
function gpuSpec(n){return n===0?cfg.gpu:cfg['gpu'+n]}
function gpuProfiles(n){return n===0?cfg.profiles:(cfg['gpu'+n]?.profiles||{})}
function gpuPrefix(n){return n===0?'gpu':'gpu'+n}
function gpuEnabled(n){return n===0?cfg.gpu?.enabled!==false:!!cfg['gpu'+n]?.enabled}
function zonePosition(name){const z=cfg.case_fans?.zones?.[name]||{};return String(z.position||name).toLowerCase()}
function findZone(...terms){for(const [name,z] of Object.entries(cfg.case_fans?.zones||{})){if(z.enabled===false)continue;const p=zonePosition(name);if(terms.some(t=>p.includes(t)||name.toLowerCase().includes(t)))return name}return null}
function diskType(d){const p=String(d.path||'');if(p==='/')return'ssd';if(p.includes('ai-models')||p.includes('/mnt/'))return'hdd';return null}
function setVisible(sel,on){const e=document.querySelector(sel);if(e)e.hidden=!on}
async function buildHardware(){
 const stack=$('gpuStack');stack.innerHTML='';
 // A configuração vem do system.dat, exposta pela API do Web.
 // GPU configurada continua visível quando a sua telemetria falha.
 for(let n=0;n<4;n++){
  if(!gpuEnabled(n))continue;
  const top=47.5+n*6;
  const unit=document.createElement('div');unit.className='gpu-unit';unit.style.top=top+'%';
  const label=document.createElement('span');label.textContent='GPU '+n;unit.appendChild(label);stack.appendChild(unit);
  const point=document.createElement('button');point.className='part hotspot gpu-point';
  point.dataset.component='gpu'+n;point.title='GPU '+n;point.setAttribute('aria-label','Telemetria da GPU '+n);
  point.style.left='29%';point.style.top=(top+2.2)+'%';stack.appendChild(point);
 }
 try{const value=await live('storage.list');disks=Array.isArray(value)?value:[]}catch{disks=[]}
 setVisible('.part.ssd',disks.some(d=>diskType(d)==='ssd'));
 setVisible('.part.hdd',disks.some(d=>diskType(d)==='hdd'));
 // RAM é instalada se a capacidade for positiva; falha de leitura não apaga um módulo configurado.
 try{const total=await live('ram.total');setVisible('.part.ram',Number(total)>0)}catch{setVisible('.part.ram',true)}
 const caseEnabled=!!cfg.case_fans?.enabled;
 const rear=findZone('rear','traseira','exhaust'),side=findZone('side','lateral'),front=findZone('front','frontal');
 const rearOn=caseEnabled&&!!rear,frontOn=caseEnabled&&!!front,sideOn=caseEnabled&&!!side;
 setVisible('.casefan.rear',rearOn);setVisible('.casefan.side',sideOn);setVisible('.casefan.front',frontOn);
 $('fanRearAsset').hidden=!rearOn;$('fanFrontAsset').hidden=!frontOn;
 document.querySelector('.casefan.rear').dataset.zone=rear||'';
 document.querySelector('.casefan.side').dataset.zone=side||'';
 document.querySelector('.casefan.front').dataset.zone=front||'';
 document.querySelectorAll('.part').forEach(x=>x.onclick=()=>select(x.dataset.component,x));
 const visible=document.querySelector(`[data-component="${selected}"]:not([hidden])`);
 if(!visible){const first=document.querySelector('.part:not([hidden])');if(first)select(first.dataset.component,first)}else select(selected,visible);
}

function rows(r){$('detailMetrics').innerHTML=r.map(([a,b])=>`<div class="metric"><span>${a}</span><strong>${b}</strong></div>`).join('')}
function select(c,node){selected=c;document.querySelectorAll('.part').forEach(x=>x.classList.toggle('active',x===node));refreshDetail()}
async function refreshDetail(){
 const c=selected;let title=c.toUpperCase(),r=[];
 try{
  if(c.startsWith('gpu')){const n=Number(c.slice(3)),p=gpuPrefix(n);title='GPU'+n;r=[['Modelo',await live(p+'.name')||'--'],['Perfil',String(await live(p+'.profile')||'--').toUpperCase()],['Temperatura',fmt(await live(p+'.temp'),' °C')],['Consumo',fmt(await live(p+'.power'),' W')],['Utilização',fmt(await live(p+'.usage'),' %')],['Core',fmt(await live(p+'.clock'),' MHz')],['Memória',fmt(await live(p+'.memory_clock'),' MHz')],['Ventoinha',fmt(await live(p+'.fan'),n===1?' RPM':' %')]]}
  else if(c==='cpu'){title='CPU';r=[['Temperatura',fmt(await live('cpu.temp'),' °C')],['Consumo',fmt(await live('cpu.power'),' W')],['Utilização',fmt(await live('cpu.usage'),' %')],['Frequência',fmt(await live('cpu.clock'),' MHz')]]}
  else if(c==='ram'){title='Memória RAM';r=[['Uso',fmt(await live('ram.usage'),' %')],['Em uso',fmt(await live('ram.used'),' MB')],['Total',fmt(await live('ram.total'),' MB')]]}
  else if(c==='psu'){title='PSU';r=[['Total DC',fmt(await live('power.total'),' W')],['Tomada',fmt(await live('power.wall'),' W')],['Carga',fmt(await live('power.load'),' %')],['Capacidade',fmt(cfg.power.capacity_w,' W')]]}
  else if(c==='ssd'||c==='hdd'){title=c==='ssd'?'SSD · Sistema':'HDD';const d=disks.find(x=>diskType(x)===c);r=d?[['Montagem',d.path||'--'],['Sistema',d.fstype||'--'],['Uso',fmt(d.usage_pct,' %')],['Usado',fmt(d.used_gb,' GB')],['Total',fmt(d.total_gb,' GB')]]:[['Estado','Não detetado']]}
  else if(c.startsWith('fan-')){const el=document.querySelector(`[data-component="${c}"]`),z=el?.dataset.zone;title=c==='fan-front'?'Ventoinhas frontais':c==='fan-side'?'Ventoinha lateral':'Extração traseira';const v=fans?.zones?.[z]||{};r=[['RPM',fmt(v.rpm)],['PWM',fmt(v.percent,' %')],['Canal',fmt(v.channel)],['Nível',fans.level||'--'],['Temp. controlo',fmt(fans.control_temp_c,' °C')],['Estado',fans.fail_safe?'FAIL-SAFE':'OK']]}
 }catch(e){r=[['Erro',e.message]]}
 $('detailTitle').textContent=title;rows(r)
}
async function refreshState(){try{const [state,p,f]=await Promise.all([live('state'),live('power.total'),live('fans.state').catch(()=>({}))]);fans=f||{};$('systemState').textContent=state;$('instantPower').textContent=fmt(p);$('coreDot').classList.toggle('offline',state==='FAULT');document.querySelector('.case').classList.toggle('fault',state==='FAULT');if(document.querySelector('.page.active')?.dataset.page==='home')refreshDetail();$('pTotal').textContent=fmt(p);$('pWall').textContent=fmt(await live('power.wall'));$('pLoad').textContent=fmt(await live('power.load'))}catch{$('coreDot').classList.add('offline')}}
function fieldsFor(p){return [['Potência W','power_limit_w'],['Clock MHz','clock_mhz'],['Memória MHz','memory_clock_mhz'],['Offset core','clock_offset_mhz'],['Offset memória','memory_offset_mhz']] .filter(([,k])=>k in p||k==='power_limit_w')}
function renderProfiles(){const root=$('profileGroups');root.innerHTML='';for(let n=0;n<4;n++){if(!gpuEnabled(n))continue;const sec=document.createElement('section');sec.className='gpu-profile';const profiles=gpuProfiles(n);sec.innerHTML=`<div class="profile-head"><div><small>GPU${n}</small><h2>${gpuSpec(n)?.name||'GPU'+n}</h2></div><span>Atual <strong id="current${n}">--</strong></span></div><div class="profile-grid">${Object.entries(profiles).map(([name,p])=>`<div class="profile-card"><h3>${name.toUpperCase()}</h3>${fieldsFor(p).map(([lab,k])=>`<label>${lab}<input type="number" data-gpu="${n}" data-profile="${name}" data-field="${k}" value="${p[k]??''}" ${editable?'':'disabled'}></label>`).join('')}<button data-apply="${n}:${name}" ${editable?'':'disabled'}>Aplicar</button></div>`).join('')}</div>`;root.appendChild(sec)}root.querySelectorAll('[data-apply]').forEach(b=>b.onclick=async()=>{if(!editable)return openAuth();const[n,name]=b.dataset.apply.split(':');try{await api('/api/profile/apply',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({gpu:'gpu'+n,name})});msg(`GPU${n}: ${name.toUpperCase()} aplicado.`);refreshProfilesCurrent()}catch(e){msg(e.message,true)}});refreshProfilesCurrent()}
async function refreshProfilesCurrent(){for(let n=0;n<4;n++){if(!gpuEnabled(n))continue;const e=$('current'+n);if(e)try{e.textContent=String(await live(gpuPrefix(n)+'.profile')||'--').toUpperCase()}catch{e.textContent='--'}}}
function fill(){ $('capacity').value=cfg.power.capacity_w;$('efficiency').value=cfg.power.efficiency*100;$('hardLimit').value=cfg.power.hard_limit_w;$('reserve').value=cfg.power.reserve_w;$('gpuTemp').value=cfg.thermal.gpu_limit_c;$('cpuTemp').value=cfg.thermal.cpu_limit_c;$('interval').value=cfg.server.interval_s;$('services').value=(cfg.services.allowed||[]).join('\n');renderProfiles()}
function collect(){cfg.power.capacity_w=+$('capacity').value;cfg.power.efficiency=+$('efficiency').value/100;cfg.power.hard_limit_w=+$('hardLimit').value;cfg.power.reserve_w=+$('reserve').value;cfg.thermal.gpu_limit_c=+$('gpuTemp').value;cfg.thermal.cpu_limit_c=+$('cpuTemp').value;cfg.server.interval_s=+$('interval').value;cfg.services.allowed=$('services').value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);document.querySelectorAll('[data-profile][data-field]').forEach(e=>{const n=+e.dataset.gpu,p=gpuProfiles(n)[e.dataset.profile],v=e.value.trim();p[e.dataset.field]=v===''?null:+v});if($('newKey').value)cfg.server.control_key=$('newKey').value;return cfg}
function setEditable(v){editable=v;$('sessionMode').textContent=v?'Gestão desbloqueada':'Modo leitura';$('authButton').textContent=v?'Bloquear gestão':'Autenticar';document.querySelectorAll('.form input,.form textarea,.actions button').forEach(e=>e.disabled=!v);renderProfiles()}
function openAuth(){$('authModal').hidden=false;$('key').focus()}
$('authButton').onclick=()=>{if(editable){sessionStorage.removeItem('hipervisorKey');setEditable(false)}else openAuth()};$('authClose').onclick=()=>$('authModal').hidden=true;$('connect').onclick=async()=>{sessionStorage.setItem('hipervisorKey',$('key').value);try{await api('/api/auth');$('authModal').hidden=true;setEditable(true);msg('Gestão desbloqueada.')}catch(e){sessionStorage.removeItem('hipervisorKey');$('loginMessage').textContent='Chave inválida'}};
$('validate').onclick=async()=>{try{await api('/api/config/validate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(collect())});msg('Configuração válida.')}catch(e){msg(e.message,true)}};$('save').onclick=async()=>{try{await api('/api/config/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(collect())});msg('Guardado; núcleo reiniciado.');setTimeout(()=>location.reload(),1800)}catch(e){msg(e.message,true)}};$('restart').onclick=async()=>{try{await api('/api/core/restart',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});msg('Núcleo reiniciado.')}catch(e){msg(e.message,true)}};
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.dataset.page===b.dataset.page));if(b.dataset.page==='profiles')refreshProfilesCurrent()});
(async()=>{try{cfg=await api('/api/config');fill();await buildHardware();try{await api('/api/auth');setEditable(true)}catch{setEditable(false)}await refreshState();setInterval(refreshState,2500)}catch(e){msg(e.message,true)}})();
