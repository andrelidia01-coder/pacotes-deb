"""Serviço independente de gestão web do Hipervisor."""

__version__ = "1.4.0"
