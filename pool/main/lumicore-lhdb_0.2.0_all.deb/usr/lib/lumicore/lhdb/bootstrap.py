#!/usr/bin/python3
"""Creates an empty private LHDB and a per-machine local control key.
Does NOT create fake GPU profiles, import legacy history or activate hardware.
"""
import os, secrets, sqlite3
from pathlib import Path
ROOT=Path('/var/lib/lumicore')
DB=ROOT/'lhdb.dat'
KEY=Path('/etc/lumicore/control-key')

def main():
    ROOT.mkdir(mode=0o700,parents=True,exist_ok=True)
    ROOT.chmod(0o700)
    KEY.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    if not KEY.exists():
        fd=os.open(KEY,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as out: out.write(secrets.token_urlsafe(32)+'\n')
    if not DB.exists():
        fd=os.open(DB,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        os.close(fd)
        with sqlite3.connect(DB) as s:
            s.execute('CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
            s.execute('CREATE TABLE sections(name TEXT PRIMARY KEY,document TEXT NOT NULL)')
            s.executemany('INSERT INTO meta VALUES(?,?)',
                          [('schema_version','1'),('name','LumiCore - setup')])
        DB.chmod(0o600)
    print('LHDB inicializada (sem perfis hardware).')

if __name__=='__main__': main()
